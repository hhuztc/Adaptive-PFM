function [udisp,ruu,kuu] = risdual_NR_displacementfield(i,phi,hplus,hminus,udisp,activeDof,bcdof,bcval,iter,TotalDOF)

%--------------------------------------------------------------------------
% solve Phase-field Sub-problem by Newton-Raphson with Active Set method
%--------------------------------------------------------------------------
% initialize:
dUfield  = zeros(length(udisp),1);
%dUBC��ʾ�߽���ϵ�λ������
% dofsUBC  = find( ~isnan(dUBC) );%�ж���nan������  
% dofsFree = find(  isnan(dUBC) );%�жϲ���nan��
dofsFree = activeDof;

% N-R iteration:
conv = 1;  tol = 2e-02;  iter_rs = 0;
while conv > tol

    iter_rs = iter_rs + 1 ;

    % store the fields of previous iteration for convergence check:
    Ufield_prvs = udisp ;
    
    % get Internal Force Vector & Tangent Stiffness Matrix:
    [kuu,ruu] = getElasSol_Parallel_cohesive(phi,i,hplus,hminus,udisp) ;
%       [kuu,ruu,fe] = getElasSol_1(phi);
    % Residual Vector:
       Ru = -ruu;
     % solve Increments, obtain Ufield, calculate Convergence:
     
     if iter_rs == 1 && iter==1 
%         dUfield(activeDof) = kuu(activeDof,activeDof) \ ( Ru(activeDof) - kuu(activeDof,bcdof)*bcval' );
%       dUfield1(dofsFree) =  kuu(dofsFree,dofsFree) \  Ru(dofsFree) ;
        dUfield(activeDof) =  kuu(activeDof,activeDof) \  Ru(activeDof) ;
        dUfield(bcdof)  = bcval';
        
        udisp = udisp + dUfield;
     else
        dUfield(activeDof) = kuu(activeDof,activeDof) \ Ru(activeDof);
        dUfield(bcdof)  = 0;
        
        udisp = udisp + dUfield;
        
        conv = norm(dUfield)/(norm(Ufield_prvs)+0.00001);
    fprintf('NR_U iteration:  %2d     conv   %6f\n',iter_rs,conv);
    end
      
 
end


end