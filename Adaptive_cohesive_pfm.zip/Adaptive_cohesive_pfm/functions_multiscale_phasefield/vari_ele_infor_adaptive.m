function [vari_ele1]=vari_ele_infor_adaptive(lab_ele) 
global node element
 numelem=size(element,1);

 edgeele=[];
 kk=0;
 for ie=1:numelem
  sctr=element(ie,:);
  nn=length(sctr) ;

  lab=0;
  for ij=1:nn  
  for ie1=1:numelem
   if(ie ~= ie1)

    if(ij==nn)
      if(ismember(sctr(ij),element(ie1,:)) & ismember(sctr(1),element(ie1,:)))
      lab=lab+1;
      break;
      end
    elseif(ismember(sctr(ij),element(ie1,:)) & ismember(sctr(ij+1),element(ie1,:)))
     lab=lab+1;
     break;
   end

 end % if

end % ie1

end % ij 
   if((lab~=2 & lab_ele(ie,2)==2) | (lab~=3 & lab_ele(ie,2)==1) | (lab~=4 & lab_ele(ie,2)==0) ) 
     kk=kk+1;
     edgeele(kk)=ie;
   end
end % ie
 
node_all=[];
for ie1=1:size(edgeele,2)
 node_all=[node_all element(edgeele(ie1),:)];
end
 node_all=unique(node_all); 

 jj=0;
 ii=0;
 ele_big=[];
 ele_small=[];
for ie1=1:size(edgeele,2)
 sctr1=element(edgeele(ie1),:) ;
  vv = node(sctr1,:);
  kk=0;
 for i2=1:size(node_all,2) 
     flag1 = inhull(node(node_all(i2),:),vv,[],1e-8);  
      if flag1 == 1  
      kk=kk+1;
      end
 end 
   if kk>4
    ii=ii+1;
   ele_big(ii)=edgeele(ie1);
   else
   jj=jj+1;
   ele_small(jj)=edgeele(ie1);
   end
end  
 
 for i=1:size(ele_big,2)  
   sctr0=element(ele_big(i),:);
   vari_ele0(i,1)=ele_big(i);
   ik=1;
   for j=1:4 

     if(j==4)
     x1=node(element(ele_big(i),j),1);  x2=node(element(ele_big(i),1),1); 
     y1=node(element(ele_big(i),j),2);  y2=node(element(ele_big(i),1),2); 
     else
     x1=node(element(ele_big(i),j),1);  x2=node(element(ele_big(i),j+1),1); 
     y1=node(element(ele_big(i),j),2);  y2=node(element(ele_big(i),j+1),2); 
     end

      a0=sqrt((x1-x2)^2+(y1-y2)^2);
      for j1=1:size(ele_small,2)
       sctr=element(ele_small(j1),:);

         for j2=1:4
     if(ismember(sctr(j2),sctr0)) 
           else
        a1=sqrt((node(sctr(j2),1)-x1)^2+(node(sctr(j2),2)-y1)^2);
        a2=sqrt((node(sctr(j2),1)-x2)^2+(node(sctr(j2),2)-y2)^2);
           if(abs(a1+a2-a0)<1e-9)
              ik=ik+1;  
              vari_ele0(i,ik)=sctr(j2); 
           end
         end
      end %for j2

       end %for j1
end  % for j  

     tmp=unique(vari_ele0(i,:)); 
     vari_ele1(i,1:size(tmp,2))=tmp;
     clear vari_ele0; clear tmp;
end % for i
