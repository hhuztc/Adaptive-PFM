function [Pfield,iter,n_as] = solveActiveSet_NR_Phasefield(node,element,Pfield,DrivForce)

%--------------------------------------------------------------------------
% solve Phase-field Sub-problem by Newton-Raphson with Active Set method
%--------------------------------------------------------------------------

% initialize:
dPfield  = zeros(length(Pfield),1);

n_as=[];

% N-R iteration:
conv = 1;  tol = 1e-02;  iter = 0;
while conv > tol

    iter = iter + 1 ;

    % store the fields of previous iteration for convergence check:
    Pfield_prvs = Pfield ;
    
    % get Internal Force Vector & Tangent Stiffness Matrix:
    [Pp,KTpp] = getFint_TanStiff_Phasefield(node,element,Pfield,DrivForce);
    
    % Residual Vector:
    Rp = - Pp;
    
    % Active Set method:
    dPfield = KTpp\Rp;
    
    setAll    = 1:length(Rp);
    setActive = [];
    
    decreaseP = find( dPfield<0 );

    ias = 1;
    while ~isempty(decreaseP)
        ias = ias + 1;

        setActive = unique([setActive;decreaseP]); % unique() already sorted
        setInact  = setdiff(setAll,setActive);

        dPfield(setInact) = KTpp(setInact,setInact) \ Rp(setInact);
        dPfield(setActive)= 0;

        decreaseP = setdiff( find(dPfield<0), setActive );

    end
    
    % store "ias" in each N-R iteration:
    n_as = [n_as, ias];
    
    % update Pfield:
    Pfield = Pfield + dPfield;
    
    % check and correct if Pfield <0 or >1:
    t1 =  Pfield < 0;  Pfield(t1) = 0;
    t2 =  Pfield > 1;  Pfield(t2) = 1;
   
    % calculate Convergence:
    conv = norm(dPfield)/norm(Pfield_prvs);
    
end


end