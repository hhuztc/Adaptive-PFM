function [phi] = risdual_NR_Phasefield(phi,hplus)
% [phi,iter,n_as] = risdual_NR_Phasefield(node,element,phi,hplus)

%--------------------------------------------------------------------------
% solve Phase-field Sub-problem by Newton-Raphson with Active Set method
%--------------------------------------------------------------------------

% initialize:
dPfield  = zeros(length(phi),1);

% n_as=[];

% N-R iteration:
conv = 1;  tol = 2e-2;  iter = 0;
while conv > tol

    iter = iter + 1 ;

    % store the fields of previous iteration for convergence check:
    Pfield_prvs = phi ;
    
    % get Internal Force Vector & Tangent Stiffness Matrix:
    [kpp,pp] = getPhaseField_Parallel_cohesive(hplus,phi);
    % Residual Vector:
    Rp = -pp;
    
    % Active Set method:
    dPfield = kpp\Rp;
     
    a1 =  dPfield < 0;  dPfield(a1) = 0;
    a2 = dPfield > 1; dPfield(a2) = 0.95;
    % update Pfield:
    phi = phi + dPfield;
    
    % check and correct if Pfield <0 or >1:
    t1 =  phi < 0;  phi(t1) = 0;
    t2 =  phi > 1;  phi(t2) = 0.95;
    
    % calculate Convergence:
    conv = norm(dPfield)/(norm(Pfield_prvs)+0.000010);
     fprintf('NR_P iteration:  %2d     conv   %6f\n',iter,conv);
end


end