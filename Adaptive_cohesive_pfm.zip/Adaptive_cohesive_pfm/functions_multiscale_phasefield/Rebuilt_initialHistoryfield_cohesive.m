function [markedelement_initialHistoryfield] = Rebuilt_initialHistoryfield_cohesive(node,element,x0,x1)
D = 100;
nn = size(node,1);
xx = node(:,1); yy = node(:,2);
% duplicate1 = find(xx<x0 & yy<D/2+1e-6 & yy>D/2-1e-6);
% duplicate2 = find(xx>x1 & yy<D/2+1e-6 & yy>D/2-1e-6);
%  duplicate = [duplicate1 ; duplicate2];
duplicate = find(xx<x1 & xx>x0 & yy<D/2);
%element is a cell,transfer it into a matrix
for i = 1 : size(element,1)
    element_matrix(i,:)=element(i,:);
end

%find the first row of elements above the initial crack.
firstIndex_element=element_matrix(:,1);
first_row_above_element=[];
for i = 1 : length(duplicate)
    for j = 1 : length(firstIndex_element)
        if duplicate(i)==firstIndex_element(j)
            first_row_above_element=[first_row_above_element,j];
        end
    end
end

%find the first row of elements below the initial crack.
fourthIndex_element=element_matrix(:,4);
first_row_below_element=[];
for i = 1 : length(duplicate)
    for j = 1 : length(fourthIndex_element)
        if duplicate(i)==fourthIndex_element(j)
           first_row_below_element=[first_row_below_element,j];
        end
    end
end

% %find the second row of elements above the initial crack.
% second_row_above_element=first_row_above_element+sqrt(size(element,1));
% 
% %find the second row of elements below the initial crack.
% second_row_below_element=first_row_below_element-sqrt(size(element,1));

markedelement_initialHistoryfield=[first_row_above_element,first_row_below_element];
markedelement_initialHistoryfield=unique(sort(markedelement_initialHistoryfield));

end



