function [hplus,points,hminus] = getHistoryInfo_cohesive(udisp,i,hplus,hminus)
global node element vari_ele fac_sub
% filename: getHistoryInfo.m
%
% purpose:
%       to get the history variable at each gauss point (Polygonal)
%       Hirshikesh, IIT Nov 2018
%
% Modifications done by Sundar
%   1. introduced global variable ldType
%   2. defined global variable ndof_u
%   3. Since the history variable and the strain energy is always computed
%   at the center of the element, the loop over the gauss points is
%   suppressed.
%--------------------------------------------------------------------------

global MatData
global ldType TSsplit
global ndof_u
global elemType
% material properties
lam = MatData.lambda ;
mu = MatData.mu ;
C = MatData.matmtx ;
stressState = MatData.stressState ;
E = MatData.E ;
nu = MatData.nu ;
phi = MatData.phi ;
c = MatData.c ;
Gc = MatData.Gc;
ft = MatData.ft;
lo = MatData.lo;
% loading type
ld_type = ldType ;

% tension compression split
tens_com_split = TSsplit ;

% number of dofs per node
dofs_per_node = ndof_u ;

numelem = length(element);
% initialize the variable to store the gauss points and the history
% variable to the stored
points = sparse(numelem,3);

% loop over the elements
for iel = 1:numelem
    
    % get current element connectivity

     sctr = element(iel,:);
    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));
        econ1 = nonzeros([sctr,vari_ele(k,2:end)]);
        econ = econ1';
    else
        econ = sctr;
    end
    
     nodes=node(sctr,:);
    % nodal coordinates
     coord = node(econ,:) ;
    
    % total number of nodes of the current element
    numside = length(econ) ;
    
    % get the geometric centroid
    pt = [0,0];
    
    % get global index
    gindex = reshape([dofs_per_node*econ-1;dofs_per_node*econ],1,[]);
    
    %compute vari_ele

      % quadrature point 
 if(ismember(iel,vari_ele(:,1))) 
      for i=1:size(vari_ele,1)
          if(iel==vari_ele(i,1))
             itmp=i;
          break
          end
      end  
        local_shape=[]; nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       %��������;ֲ������ת��
          [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
          nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
          local_shape=[local_shape; exisp,etasp];  
       end
   end 
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
   J0 = [nodes; nodes0]'*dNdxi;
   invJ0 = inv(J0);
   dNdx = dNdxi*invJ0;
   glpt = N'*coord;
    % strain-displacement matrix
     B = zeros(3,dofs_per_node*numside) ;%4���ڵ����3��8��
     B(1,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
     B(2,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
   
     uele = udisp(gindex,1);
     
    % elemental displacement vector
   
    eps_e = B*uele;
    str_e = C*eps_e;
    

    
    % get the history variable at the current Gauss point from all
    % all the load steps....
    if strcmp(stressState,'PlaneStrain')
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0;...
            0 0 0];
    else
        %str = C*eps_e ;
        epse4 = -nu/E*(str_e(1) + str_e(2));
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0; 0 0 epse4];
    end
    
    if strcmp(tens_com_split,'ambatti')
        
        [~, eig_val] = eig(eps_mat);
        
        
        % Sundar - 2-Jul-2020
        %    the eigen values are stored in the diagonal form, so extract that
        %    and then compute the postive and the negative part
        eig_val = diag(eig_val);
        
        % decompose the strain into positive and negative part
        eig_p = 1/2*(eig_val + abs(eig_val)) ;
        eig_n = 1/2*(eig_val - abs(eig_val)) ;
        
        eig_val = diag(eig_val);
        if strcmp(ld_type,'Tension')
            
            % positive part of the strain
            Psi_p = 0.5*lam*( 0.5*( trace(eig_val) + abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_p(1)*eig_p(1) + eig_p(2)*eig_p(2) + eig_p(3)*eig_p(3) );
            
            % negative part of strain
            Psi_n = 0.5*lam*( 0.5*( trace(eig_val) - abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_n(1)*eig_n(1) + eig_n(2)*eig_n(2) + eig_n(3)*eig_n(3) );
            
        elseif strcmp(ld_type,'Compressive')
            
            term1 = mu*(eig_n(2)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(2) + eig_n(1)))*tand(phi) - c ;
            
            term2 = mu*(eig_n(3)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(1)))*tand(phi) - c ;
            
            term3 = mu*(eig_n(3)-eig_n(2))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(2)))*tand(phi) - c ;
            
            term4 = 1/4*( (term1+abs(term1))^2 + ...
                (term2 + abs(term2))^2 + (term3 + abs(term3))^2) ;
            
            Psi_p = 1/(2*mu)*term4 ;
            Psi_n = 0;
        end
        
    elseif strcmp(tens_com_split,'amor')
        
        Kn = lam + mu ;
        
        trE = trace(eps_mat);
        Edev = eps_mat - 1/3*trE*[1 0 0;0 1 0;0 0 1];
        
        trEp = 1/2*(trE + abs(trE)) ;
        trEn = 1/2*(trE - abs(trE)) ;
        
        
        Psi_p = 1/2*Kn*trEp^2 + mu*trace(Edev*Edev);
        Psi_n = 1/2*Kn*trEn^2 ;
    end
    points(iel,:) = [glpt Psi_p];
    
    % save the history variable
    hplus(iel,1) = Psi_p;
    hminus(iel,1) = Psi_n;
   clear nodes0;
 else
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [N,dNdxi] = lagrange_basis(elemType,pt);
    J0 = node(sctr,:)'*dNdxi;  % element Jacobian matrix
    invJ0 = inv(J0);
    dNdx = dNdxi*invJ0;
    glpt = N'*coord;
    % strain-displacement matrix
     B = zeros(3,dofs_per_node*numside) ;%4���ڵ����3��8��
     B(1,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
     B(2,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
   
     uele = udisp(gindex,1);
     
    % elemental displacement vector
   
    eps_e = B*uele;
    str_e = C*eps_e;
    

    
    % get the history variable at the current Gauss point from all
    % all the load steps....
    if strcmp(stressState,'PlaneStrain')
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0;...
            0 0 0];
    else
        %str = C*eps_e ;
        epse4 = -nu/E*(str_e(1) + str_e(2));
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0; 0 0 epse4];
    end
    
    if strcmp(tens_com_split,'ambatti')
        
        [~, eig_val] = eig(eps_mat);
        
        
        % Sundar - 2-Jul-2020
        %    the eigen values are stored in the diagonal form, so extract that
        %    and then compute the postive and the negative part
        eig_val = diag(eig_val);
        
        % decompose the strain into positive and negative part
        eig_p = 1/2*(eig_val + abs(eig_val)) ;
        eig_n = 1/2*(eig_val - abs(eig_val)) ;
        
        eig_val = diag(eig_val);
        if strcmp(ld_type,'Tension')
            
            % positive part of the strain
            Psi_p = 0.5*lam*( 0.5*( trace(eig_val) + abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_p(1)*eig_p(1) + eig_p(2)*eig_p(2) + eig_p(3)*eig_p(3) );
            
            % negative part of strain
            Psi_n = 0.5*lam*( 0.5*( trace(eig_val) - abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_n(1)*eig_n(1) + eig_n(2)*eig_n(2) + eig_n(3)*eig_n(3) );
            
        elseif strcmp(ld_type,'Compressive')
            
            term1 = mu*(eig_n(2)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(2) + eig_n(1)))*tand(phi) - c ;
            
            term2 = mu*(eig_n(3)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(1)))*tand(phi) - c ;
            
            term3 = mu*(eig_n(3)-eig_n(2))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(2)))*tand(phi) - c ;
            
            term4 = 1/4*( (term1+abs(term1))^2 + ...
                (term2 + abs(term2))^2 + (term3 + abs(term3))^2) ;
            
            Psi_p = 1/(2*mu)*term4 ;
            Psi_n = 0;
        end
        
    elseif strcmp(tens_com_split,'amor')
        
        Kn = lam + mu ;
        
        trE = trace(eps_mat);
        Edev = eps_mat - 1/3*trE*[1 0 0;0 1 0;0 0 1];
        
        trEp = 1/2*(trE + abs(trE)) ;
        trEn = 1/2*(trE - abs(trE)) ;
        
        
        Psi_p = 1/2*Kn*trEp^2 + mu*trace(Edev*Edev);
        Psi_n = 1/2*Kn*trEn^2 ;
    end
    points(iel,:) = [glpt Psi_p];
    
    % save the history variable
    hplus(iel,1) = Psi_p;
    hminus(iel,1) = Psi_n;
end 
end
clear iel

end