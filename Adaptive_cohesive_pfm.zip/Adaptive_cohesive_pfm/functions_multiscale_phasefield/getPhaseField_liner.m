function [kpp,fpp] = getPhaseField_liner(hplus)
% purpose: solve phase-field equation on polygonal������εģ� mesh
% Hirshikesh, IITM Nov 2018
% modified to use in parallel
%                  jan 2019
%
% -
% Sundar modified the following
%   - since the N and dNdx computations at the elemental level are computed
%   in the physical space, the computation of Jacobian is suppressed.
%   - gine variable is not used anywhere. suppressed it.
%
%--------------------------------------------------------------------------

global MatData ndof_p 
global ngp
global node element vari_ele fac_sub
global elemType
% material parameters
Gc = MatData.Gc ;%�ٽ������ͷ���
lo = MatData.lo ;%����ϵ��

% number of gauss points
numgp = ngp;
numnode = length(node);
numelem = length(element);
normal_order = 2;
sdofp = numnode*ndof_p;%���е����ɶȣ�һ���ڵ�����
%create a cell to save vari_ele

% initialize the element stiffness matrix��ʼ���նȾ���
DataK = struct('kcele',{}) ;
Datafp = struct('fpele',{}) ;


for iel = 1:numelem
    
    % get current element connectivity

    sctr=element(iel,:);
    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));
        ginp1 = nonzeros([sctr,vari_ele(k,2:end)]);
        ginp = ginp1';
        
    else
        ginp = sctr;
    end
    % nodal coordinates�ڵ�����
     coord = node(ginp,:);
   
     nodes=node(sctr,:);
    % total number of nodes in the current element 
    nn = length(ginp) ;

    % get the integration points...�õ����ֵ� %ͨ���ڵ�����ж������õĵ�Ԫ����
    %compute stiffiness
    kcele = zeros(size(ginp,2),size(ginp,2));
    fpele = zeros(size(ginp,2),1);
    
    % History variable of the current element
    H = max(hplus(iel,:)) ;%��Ӧ��ʽ��H����������֤����Ĳ�������
   
    %compute vari_ele
    [W,Q] = gauss_rule(iel,normal_order,2);
 if(ismember(iel,vari_ele(:,1))) 
    for kk = 1 : size(W,1)
        B = [];
        pt = Q(kk,:);                             % quadrature point 
       for i=1:size(vari_ele,1)
          if(iel==vari_ele(i,1))
             itmp=i;
          break
          end
        end 
  local_shape=[]; nodes0=[]; 
       for i=1:size(vari_ele(itmp,:),2)-1 
          if(vari_ele(itmp,i+1)>0)       
            [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
            nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
            local_shape=[local_shape; exisp,etasp];  
          end
       end 
    [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
    J0 = [nodes; nodes0]'*dNdxi;
    invJ0 = inv(J0);
    dNdx = dNdxi*invJ0;
   % the forcing term
    fpele = fpele + 2*N*H*W(kk)*det(J0) ;%��ʽ28��F��ext)
    % compute the stiffness matrix
    kcele = kcele + ...
            (dNdx*Gc*lo*dNdx' + N*(Gc/lo + 2*H)*N' )*W(kk)*det(J0);
    clear nodes0;
    end
    DataK(iel).kcele = kcele;
    Datafp(iel).fpele = fpele;
 else
    cntqq = 0;
    [wq,qq]=quadrature(numgp,'GAUSS',2);
    for iigp = 1:size(W,1)
        cntqq = cntqq + 1;
        ptq = qq(iigp,:);
        [ng,dndxig] = lagrange_basis(elemType,ptq);  % element shape functions
        jacq = dndxig'*coord ;
        W1(cntqq,1) = wq(iigp)*det(jacq);
        temp = ng'*coord;
        Q1(cntqq,1) = temp(1); Q1(cntqq,2)=temp(2);
     end
     for igp = 1:size(W1,1)
         pt1 = Q1(igp,:) ;
         J0 = node(sctr,:)'*dndxig;  % element Jacobian matrix
         [N,dNdx]=meanvalue_shapefunction(coord,pt1) ;
     % the forcing term
         fpele = fpele + 2*N*H*W1(igp) ;%��ʽ28��F��ext)
     % compute the stiffness matrix
         kcele = kcele + ...
            (dNdx*Gc*lo*dNdx' + N*(Gc/lo + 2*H)*N' )*W1(igp);
     end
    
    DataK(iel).kcele = kcele;
    Datafp(iel).fpele = fpele;
 end
 end

%==============================
% assembly in row column format
%==============================
NCOEFF_K = 0;
NCOEFF_F = 0;
for iel=1:length(element)
     
%     DOF = element_modified{iel,:};
     sctr = element(iel,:);
    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));
        ginp1 = nonzeros([sctr,vari_ele(k,2:end)]);
        ginp = ginp1';
    else
        ginp = sctr;
    end
    
    DOF = ginp;
    % for stiffness matrix
    iStart = NCOEFF_K+1 ;
    NCOEFF_K = NCOEFF_K + length(DOF)^2 ;
    iEnd = NCOEFF_K ;
    
    % for force vector
    jStart = NCOEFF_F + 1;
    NCOEFF_F = NCOEFF_F + length(DOF) ;
    jEnd = NCOEFF_F ;
    
    [X,Y] = meshgrid(DOF,DOF);
    
    kk = DataK(iel).kcele;
    ff = Datafp(iel).fpele;
    
    rowIdx(iStart:iEnd) = reshape(Y,1,[]);
    colIdx(iStart:iEnd) = reshape(X,1,[]);
    coeffK(iStart:iEnd) = reshape(kk,1,[]);
    
    colJdx(jStart:jEnd) = Y(:,1)';
    coeffF(jStart:jEnd) = reshape(ff,1,[]);
end
kpp = sparse(rowIdx,colIdx,coeffK,sdofp,sdofp,NCOEFF_K);

% force vector
fpp = sparse(colJdx,1,coeffF,sdofp,1,NCOEFF_F);

clear iel

end