function [hplus,points] = getHistoryInfo_2(udisp,hplus,Gc)
global node element vari_ele fac_sub
% filename: getHistoryInfo.m
%
% purpose:
%       to get the history variable at each gauss point (Polygonal)
%       Hirshikesh, IIT Nov 2018
%
% Modifications done by Sundar
%   1. introduced global variable ldType
%   2. defined global variable ndof_u
%   3. Since the history variable and the strain energy is always computed
%   at the center of the element, the loop over the gauss points is
%   suppressed.
%--------------------------------------------------------------------------

global MatData
global ldType TSsplit
global ndof_u
global elemType
% material propertieslam = MatData.lambda ;
mu = MatData.mu ;
matmtx = MatData.matmtx ;
stressState = MatData.stressState ;
E =  MatData.E;
ft = MatData.ft;
% phase field length scale
% Gc = MatData.Gc;
lo = MatData.lo ;
nu = MatData.nu ;
mu = MatData.mu;
phi = MatData.phi ;
c = MatData.c ;
% Gc = MatData.Gc;
% ft = MatData.ft;
% lo = MatData.lo;
% loading type
ld_type = ldType ;

% tension compression split
tens_com_split = TSsplit ;

% number of dofs per node
dofs_per_node = ndof_u ;

numelem = length(element);
% initialize the variable to store the gauss points and the history
% variable to the stored
points = sparse(numelem,3);

% loop over the elements
for iel = 1:numelem
   lch = (E*Gc(iel,:))/ft^2;
    % get current element connectivity

     sctr = element(iel,:);
    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));
        econ1 = nonzeros([sctr,vari_ele(k,2:end)]);
        econ = econ1';
    else
        econ = sctr;
    end
    
     nodes=node(sctr,:);
    % nodal coordinates
     coord = node(econ,:) ;
    
    % total number of nodes of the current element
    numside = length(econ) ;
    
    % get the geometric centroid
    pt = [0,0];
    % get the geometric centroid
%     XX = [mean(coord(:,1)) mean(coord(:,2))];
    % get global index
    gindex = reshape([dofs_per_node*econ-1;dofs_per_node*econ],1,[]);
    
      % quadrature point 
 if(ismember(iel,vari_ele(:,1))) 
      for i=1:size(vari_ele,1)
          if(iel==vari_ele(i,1))
             itmp=i;
          break
          end
      end  
        local_shape=[]; nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       %��������;ֲ������ת��
          [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
          nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
          local_shape=[local_shape; exisp,etasp];  
       end
   end 
   
     for j = 1: size(local_shape(:,1))
       if local_shape(j,1)>0.7
           local_shape(j,1)=1;
       elseif local_shape(j,1)>0 & local_shape(j,1)<0.3
           local_shape(j,1)=0;
       elseif local_shape(j,1)>0.3 & local_shape(j,1)<0.7
           local_shape(j,1)=0.5;
       elseif local_shape(j,1)<0 & local_shape(j,1)>-0.3
           local_shape(j,1)=0;
       elseif local_shape(j,1)<-0.7
           local_shape(j,1)=-1;
       elseif local_shape(j,1)<-0.3 & local_shape(j,1)>-0.7
           local_shape(j,1)=-0.5;  
       end
       if local_shape(j,2)>0.7
           local_shape(j,2)=1;
       elseif local_shape(j,2)>0 & local_shape(j,2)<0.3
           local_shape(j,2)=0;
           elseif local_shape(j,2)>0.3 & local_shape(j,2)<0.7
           local_shape(j,2)=0.5;
       elseif local_shape(j,2)<0 & local_shape(j,2)>-0.3
           local_shape(j,2)=0;
       elseif local_shape(j,2)<-0.7
           local_shape(j,2)=-1; 
       elseif local_shape(j,2)<-0.3 & local_shape(j,2)>-0.7
           local_shape(j,2)=-0.5;
       end    
   end

   for j = 1: size(local_shape(:,1))
       if local_shape(j,1)==1 & local_shape(j,2)==1
           local_shape(j,1)= -0.5;
        elseif local_shape(j,1)==1 & local_shape(j,2)== -1
            local_shape(j,1)= 0;
        elseif local_shape(j,1)== -1 & local_shape(j,2)== 1
            local_shape(j,1)= 0;
       elseif local_shape(j,1)== -1 & local_shape(j,2)== -1
           local_shape(j,1)= 0.5;
       end
   end
   
   [newmat,index]= unique(local_shape,'rows','first');
   repeatedindex = setdiff(1:size(local_shape,1),index);
   if ~isempty(repeatedindex)
   numre = size(repeatedindex,2);
   if numre>1
      local_shape(repeatedindex(:,(numre-1) ),1)= -local_shape(repeatedindex(:,(numre-1) ),1);
      local_shape(repeatedindex(:,(numre) ),2)= -local_shape(repeatedindex(:,(numre) ),2);  
   else
      local_shape(repeatedindex(:,(numre) ),2)= -local_shape(repeatedindex(:,(numre) ),2);  
   end
   end
   
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
   J0 = [nodes; nodes0]'*dNdxi;
   invJ0 = inv(J0);
   dNdx = dNdxi*invJ0;
   glpt = N'*coord;
    % strain-displacement matrix
     B = zeros(3,dofs_per_node*numside) ;%4���ڵ����3��8��
     B(1,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
     B(2,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
   
     uele = udisp(gindex,1);
     
    % elemental displacement vector
    eps_e = B*uele;
    str_e = matmtx*eps_e;
        
    % get the history variable at the current Gauss point from all
    % all the load steps....
    %%%cohesive parameters
         a1 = (4*lch)/(pi*lo);
    a2 = 1.3868;
    a3 = 0.6567;
%       a2 = -0.5;
%       a3 =0;
    %get degradation function
    g = (1-phi)^2;% Fractional molecules
    dg = -2*(1-phi);%derivatives of g
    ddg = 2;%Second derivative of g��
    W22 = g + a1*phi +a1*a2*phi^2 +a1*a2*a3*phi^3; %Denominator of fractions
    dW22 = dg + a1 + 2*a1*a2*phi + 3*a1*a2*a3*phi^2;
    ddW22 = ddg + 2*a1*a2 +6*a1*a2*a3*phi;
    domega = (dg*W22-dW22*g)/(W22)^2;
    %%%%
%     if strcmp(stressState,'PlaneStrain')
%         eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0;...
%             0 0 0];
%     else
%         %str = C*eps_e ;
%         epse4 = -nu/E*(str_e(1) + str_e(2));
% %         epse4 = -1/2*E*(str_e(1) + str_e(2));
%         eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0; 0 0 epse4];
%     end
    
%     if strcmp(tens_com_split,'ambatti')
           % 
          cheta = str_e(3);
          sigma1 = (str_e(1)+str_e(2))/2 + sqrt( ( ( (str_e(1)- str_e(2))/2 )^2 + cheta^2 ) );
          sigma2 = (str_e(1)+str_e(2))/2 - sqrt( ( ( (str_e(1)- str_e(2)/2) )^2 + cheta^2 ) );
          sigma = max(sigma1,0);
               Psi_p = (1/(2*E))*( 0.5*( sigma1 + abs(sigma1) ))^2;
%           Psi_p = (1/(2*E))*(  sigma )^2;
            % negative part of strain
          Psi_n = (1/(2*E))*( 0.5*( sigma2 + abs(sigma2) ))^2;
               
    
    points(iel,:) = [glpt Psi_p];
    
    % save the history variable
    hplus(iel,1) = Psi_p;
%     hminus(iel,1) = Psi_n;
   clear nodes0;
else
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % canonical domain
%     [N,dNdx]=meanvalue_shapefunction1(coord,XX) ;
    
    [N,dNdxi] = lagrange_basis(elemType,pt);
    J0 = node(sctr,:)'*dNdxi;  % element Jacobian matrix
    invJ0 = inv(J0);
    dNdx = dNdxi*invJ0;
    glpt = N'*coord ;
    % strain-displacement matrix
     B = zeros(3,dofs_per_node*numside) ;%4���ڵ����3��8��
     B(1,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
     B(2,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
     B(3,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
%    
     uele = udisp(gindex,1);
     
    % elemental displacement vector
   
    eps_e = B*uele;%[strain_x;strain_y;qie_strain_xy]
    str_e = matmtx*eps_e;%[stress_x;stress_y;qie_stress_xy]
    
      %%%cohesive parameters
         a1 = (4*lch)/(pi*lo);
    a2 = 1.3868;
    a3 = 0.6567;
%       a2 = -0.5;
%       a3 =0;
    %get degradation function
    g = (1-phi)^2;% Fractional molecules
    dg = -2*(1-phi);%derivatives of g
    ddg = 2;%Second derivative of g��
    W22 = g + a1*phi +a1*a2*phi^2 +a1*a2*a3*phi^3; %Denominator of fractions
    dW22 = dg + a1 + 2*a1*a2*phi + 3*a1*a2*a3*phi^2;
    ddW22 = ddg + 2*a1*a2 +6*a1*a2*a3*phi;
    domega = (dg*W22-dW22*g)/(W22)^2;
    %%%%
    
    % get the history variable at the current Gauss point from all
    % all the load steps....
%     if strcmp(stressState,'PlaneStrain')
%         eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0;...
%             0 0 0];
%     else
%         %str = C*eps_e ;
%         epse4 = -nu/E*(str_e(1) + str_e(2));
%         eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0; 0 0 epse4];
%     end
    
          cheta = str_e(3);
          sigma1 = (str_e(1)+str_e(2))/2 + sqrt( ( ( (str_e(1)- str_e(2))/2 )^2 + cheta^2 ) );
          sigma2 = (str_e(1)+str_e(2))/2 - sqrt( ( ( (str_e(1)- str_e(2)/2) )^2 + cheta^2 ) );
             sigma = max(sigma1,0);
             Psi_p = (1/(2*E))*( 0.5*( sigma1 + abs(sigma1) ))^2;
%             Psi_p = (1/(2*E))*(  sigma )^2;
            % negative part of strain
          Psi_n = (1/(2*E))*( 0.5*( sigma2 + abs(sigma2) ))^2;
            

    end
    
    points(iel,:) = [glpt Psi_p];
    
    % save the history variable
    hplus(iel,1) = Psi_p;
%     hminus(iel,1) = Psi_n;
end
 

clear iel

end