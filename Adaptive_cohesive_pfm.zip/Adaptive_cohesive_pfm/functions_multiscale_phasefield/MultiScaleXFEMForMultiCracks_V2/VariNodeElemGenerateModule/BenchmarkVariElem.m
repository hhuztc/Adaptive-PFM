% benchmark of vari_elem_generate
% See also vari_elem_generate

%% MESH 1
clear variables
close all
% mesh generate
pt1 = [0 0];                    % �ı���4���ǵ�����
pt2 = [5 0];
pt3 = [5 6];
pt4 = [0 6];
nnx = 6;
nny = 7;
[node,element] = meshRectangularRegion(pt1,pt2,pt3,pt4,nnx,nny,'Q4');
% nodedata = xlsread('node_data_L.xlsx');
% node = nodedata(:,2:end);
% elementdata = xlsread('element_data_L.xlsx');
% element = elementdata(:,2:end);
figure,
% plot_StdMesh([],element,node)
plot_StdMesh([],element,node,'textelemnum',1,'textnodenum',1);

% ��һ��ϸ��
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
sub_divide = 2;
updElem = [12:14,17:19,22:24];
% updElem=[16,272,513,529,530,545];
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
brush_element([],element,node,updElem)
figure,
% plot_StdMesh([],element2,node2)
plot_StdMesh([],element2,node2,'textelemnum',1,'textnodenum',1);

% �ڶ���ϸ��
updElem2 = [12,31,7,8,9];
% updElem2=[16,513,771,772,775,776,777];
sub_divide2 = 3;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2)
figure,
plot_StdMesh([],element3,node3)
plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);
updElem3 = [12,31,7,8,9];
% updElem3=[16,513,514,789,790,791,792,796];
sub_divide3 = 3;
[vari_ele_node4,element4,node4,ElemSctr4,ValidNodeNum4] = vari_elem_generate(element3,node3,ElemSctr3,ValidNodeNum3,vari_ele_node3,updElem3,sub_divide3);
brush_element([],element3,node3,updElem3)
figure,
plot_StdMesh([],element4,node4)

[Edge1,Edge2,Edge3,Edge4,IA,IB] = GetExtraNodesOnEdge(element3,ElemSctr3,ValidNodeNum3,vari_ele_node3);

plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend
%% MESH 2
clear variables
close all
% mesh generate
pt1 = [0 0];                    % �ı���4���ǵ�����
pt2 = [5 0];
pt3 = [5 6];
pt4 = [0 6];
nnx = 6;
nny = 7;
[node,element] = meshRectangularRegion(pt1,pt2,pt3,pt4,nnx,nny,'Q4');
figure,
% plot_StdMesh([],element,node);
plot_StdMesh([],element,node,'textelemnum',1,'textnodenum',1);

% ��һ��ϸ��
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
sub_divide = 2;
updElem = [12:14,17:19,22:24];
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
brush_element([],element,node,updElem);
figure,
% plot_StdMesh([],element2,node2);
plot_StdMesh([],element2,node2,'textelemnum',1,'textnodenum',1);

% �ڶ���ϸ��
updElem2 = [12,13,14,18,31:39,43:45,7,8,9];
sub_divide2 = 2;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2);
figure,
plot_StdMesh([],element3,node3);
% plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);

[Edge1,Edge2,Edge3,Edge4,IA,IB] = GetExtraNodesOnEdge(element3,ElemSctr3,ValidNodeNum3,vari_ele_node3);

plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend
%% MESH 3 
clear variables
close all
% mesh generate
[node,element] = meshRectangularRegion([0,0], [20,0], [20,20], [0,20], 21,21,'Q4');
figure,
plot_StdMesh([],element,node);
% plot_StdMesh([],element,node,'textelemnum',1,'textnodenum',1);

% ��һ��ϸ��
updElem = [123:137,144:156,165:175,186:194,207:213,228:232,249:251,270];
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
sub_divide = 3;
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
figure,
plot_StdMesh([],element2,node2);
plot_VNMesh([],element2,node2,vari_ele_node2)

% �ڶ���ϸ��
updElem2 = [713,714,748,758,108,110,425,106];
sub_divide2 = 2;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3,refinedArea3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2);
figure,
plot_StdMesh([],element3,node3);
brush_element([],element3,node3,refinedArea3,'Facecolor','r')
% plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);

[Edge1,Edge2,Edge3,Edge4,IA,IB] = GetExtraNodesOnEdge(element3,ElemSctr3,ValidNodeNum3,vari_ele_node3);

plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend
%% MESH 4 �ڽ��Ķ�����ϸ��I
clear variables
close all
% mesh generate
[node,element] = meshRectangularRegion([0,0], [20,0], [20,20], [0,20], 21,21,'Q4');
figure,
plot_StdMesh([],element,node);

% ��һ��ϸ��
updElem = [123:137,144:156,165:175,186:194,207:213,228:232,249:251,270,83:97];
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
sub_divide =3;
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
figure,
plot_StdMesh([],element2,node2,'textelemnum',1)
% plot_StdMesh([],element2,node2)
plot_VNMesh([],element2,node2,vari_ele_node2)

% �ڶ���ϸ��
updElem2 = [83,401:407,84,409:416,85,423,422,103,105,98,188];
sub_divide2 = 2;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2);
figure,
% plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);
plot_StdMesh([],element3,node3)

[Edge1,Edge2,Edge3,Edge4,IA,IB] = GetExtraNodesOnEdge(element3,ElemSctr3,ValidNodeNum3,vari_ele_node3);

plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend

%% MESH 5 ��״��ϸ������II
clear variables
close all
% mesh generate
[node,element] = meshRectangularRegion([0,0], [20,0], [20,20], [0,20], 21,21,'Q4');
figure,
plot_StdMesh([],element,node);

% ��һ��ϸ��
updElem = [123:137,144:156,165:175,186:194,207:213,228:232,249:251,269:271,289,291,309:311,227:20:347,348:352,233:20:353];
sub_divide =3;
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
figure,
% plot_StdMesh([],element2,node2,'textelemnum',1)
plot_StdMesh([],element2,node2)
plot_VNMesh([],element2,node2,vari_ele_node2,'splitnode',{ElemSctr2,ValidNodeNum2})

% �ڶ���ϸ��
updElem2 = [248,268,288,308,328,329:332,312,292,272,252,290];
sub_divide2 = 3;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2,'DisplayName','area to be refined')
legend
figure,
% plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);
plot_StdMesh([],element3,node3)

[Edge1,Edge2,Edge3,Edge4,IA,IB] = GetExtraNodesOnEdge(element3,ElemSctr3,ValidNodeNum3,vari_ele_node3);

plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend

%% MESH 6 �ṹ�߽總����ϸ��
clear variables
close all
% mesh generate
[node,element] = meshRectangularRegion([0,0], [20,0], [20,20], [0,20], 21,21,'Q4');
figure,
plot_StdMesh([],element,node);

% ��һ��ϸ��
updElem = [1:20,21:20:361,381:400,40:20:380];
brush_element([],element,node,'subindex',updElem,'Displayname','area to be refined')
legend
sub_divide =3;
ElemSctr = element;
ValidNodeNum = 4*ones(size(element,1),1);
vari_ele_node = [];
[vari_ele_node2,element2,node2,ElemSctr2,ValidNodeNum2] = vari_elem_generate(element,node,ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
figure,
% plot_StdMesh([],element2,node2,'textelemnum',1)
plot_StdMesh([],element2,node2)
plot_VNMesh([],element2,node2,vari_ele_node2,'splitnode',{ElemSctr2,ValidNodeNum2})

% �ڶ���ϸ��
updElem2 = vari_ele_node2(:,1);
sub_divide2 = 3;
[vari_ele_node3,element3,node3,ElemSctr3,ValidNodeNum3] = vari_elem_generate(element2,node2,ElemSctr2,ValidNodeNum2,vari_ele_node2,updElem2,sub_divide2);
brush_element([],element2,node2,updElem2,'DisplayName','area to be refined')
legend
figure,
% plot_StdMesh([],element3,node3,'textelemnum',1,'textnodenum',1);
plot_StdMesh([],element3,node3)
plot_VNMesh([],element3,node3,vari_ele_node3,'SplitNode',{ElemSctr3,ValidNodeNum3})
legend

% ������ϸ��
updElem3 = vari_ele_node3(:,1);
sub_divide3 = 3;
[vari_ele_node4,element4,node4,ElemSctr4,ValidNodeNum4] = vari_elem_generate(element3,node3,ElemSctr3,ValidNodeNum3,vari_ele_node3,updElem3,sub_divide3);
brush_element([],element3,node3,updElem3,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element4,node4)
plot_VNMesh([],element4,node4,vari_ele_node4,'SplitNode',{ElemSctr4,ValidNodeNum4})
legend;

% ���Ĵ�ϸ��
updElem4 = vari_ele_node4(:,1);
sub_divide4 = 3;
[vari_ele_node5,element5,node5,ElemSctr5,ValidNodeNum5] = vari_elem_generate(element4,node4,ElemSctr4,ValidNodeNum4,vari_ele_node4,updElem4,sub_divide4);
brush_element([],element4,node4,updElem4,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element5,node5)
plot_VNMesh([],element5,node5,vari_ele_node5,'SplitNode',{ElemSctr5,ValidNodeNum5})
legend;

% �����ϸ��
updElem5 = vari_ele_node5(:,1);
sub_divide5 = 3;
[vari_ele_node6,element6,node6,ElemSctr6,ValidNodeNum6] = vari_elem_generate(element5,node5,ElemSctr5,ValidNodeNum5,vari_ele_node5,updElem5,sub_divide5);
brush_element([],element5,node5,updElem5,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element6,node6)
plot_VNMesh([],element6,node6,vari_ele_node6,'SplitNode',{ElemSctr6,ValidNodeNum6})
legend;

% ������ϸ��
updElem6 = vari_ele_node6(:,1);
sub_divide6 = 3;
[vari_ele_node7,element7,node7,ElemSctr7,ValidNodeNum7] = vari_elem_generate(element6,node6,ElemSctr6,ValidNodeNum6,vari_ele_node6,updElem6,sub_divide6);
brush_element([],element6,node6,updElem6,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element7,node7)
plot_VNMesh([],element7,node7,vari_ele_node7,'SplitNode',{ElemSctr7,ValidNodeNum7})
legend;

% ���ߴ�ϸ��
updElem7 = vari_ele_node7(:,1);
sub_divide7 = 3;
[vari_ele_node8,element8,node8,ElemSctr8,ValidNodeNum8] = vari_elem_generate(element7,node7,ElemSctr7,ValidNodeNum7,vari_ele_node7,updElem7,sub_divide7);
brush_element([],element7,node7,updElem7,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element8,node8)
plot_VNMesh([],element8,node8,vari_ele_node8,'SplitNode',{ElemSctr8,ValidNodeNum8})
legend;

% �ڰ˴�ϸ��
updElem8 = vari_ele_node8(:,1);
sub_divide8 = 3;
[vari_ele_node9,element9,node9,ElemSctr9,ValidNodeNum9] = vari_elem_generate(element8,node8,ElemSctr8,ValidNodeNum8,vari_ele_node8,updElem8,sub_divide8);
brush_element([],element8,node8,updElem8,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element9,node9)
plot_VNMesh([],element9,node9,vari_ele_node9,'SplitNode',{ElemSctr9,ValidNodeNum9})
legend;

% �ھŴ�ϸ��
updElem9 = vari_ele_node9(:,1);
sub_divide9 = 3;
[vari_ele_node10,element10,node10,ElemSctr10,ValidNodeNum10] = vari_elem_generate(element9,node9,ElemSctr9,ValidNodeNum9,vari_ele_node9,updElem9,sub_divide9);
brush_element([],element9,node9,updElem9,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element10,node10)
plot_VNMesh([],element10,node10,vari_ele_node10,'SplitNode',{ElemSctr10,ValidNodeNum10})
legend;

% �ھŴ�ϸ��
updElem10 = vari_ele_node10(:,1);
sub_divide10 = 3;
[vari_ele_node11,element11,node11,ElemSctr11,ValidNodeNum11] = vari_elem_generate(element10,node10,ElemSctr10,ValidNodeNum10,vari_ele_node10,updElem10,sub_divide10);
brush_element([],element10,node10,updElem10,'DisplayName','area to be refined')
legend;
figure,
plot_StdMesh([],element11,node11)
plot_VNMesh([],element11,node11,vari_ele_node11,'SplitNode',{ElemSctr11,ValidNodeNum11})
legend;