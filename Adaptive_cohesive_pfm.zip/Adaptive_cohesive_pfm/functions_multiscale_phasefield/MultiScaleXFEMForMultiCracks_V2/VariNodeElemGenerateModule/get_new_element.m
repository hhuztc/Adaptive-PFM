function new_element = get_new_element(num_subelem_tobe_generate,sub_divide,node_num_on_elem_edge,node_num_in_elem)
nn = 4;
num_subelem_per_elem = sub_divide^2;
new_element = zeros(num_subelem_tobe_generate,nn);  % ��ʼ��
small_mesh = zeros(sub_divide+1);   % ��¼��߶ȵ�Ԫ�ڲ�����С�߶ȵ�Ԫ�Ľڵ�ľֲ���ţ��ֱ��Ϻ��ڲ��������ֲ���
flag_mesh = small_mesh;

flag_mesh([1,end],:) = 1;
flag_mesh(:,[1,end]) = 1;
flag_mesh = logical(flag_mesh);

local_num_on_edge = 1:nn*sub_divide;
small_mesh(1,1:end-1) = local_num_on_edge(1:sub_divide);
small_mesh(end,end:-1:2) = local_num_on_edge(2*sub_divide+1:3*sub_divide);
small_mesh(end:-1:2,1) = local_num_on_edge(3*sub_divide+1:4*sub_divide)';
small_mesh(1:end-1,end) = local_num_on_edge(sub_divide+1:2*sub_divide)';

second_layer = sub_divide-2+1;
small_mesh(2:end-1,2:end-1) = reshape(1:second_layer^2,[],second_layer);

num_mesh = zeros(sub_divide);
rounddd = ceil(sub_divide/2);
c = 0;
for i = 1:rounddd
    num_mesh(i,i:sub_divide-i) = c+(1:sub_divide-2*i+1);%�ϱ�
    num_mesh(i:sub_divide-i,sub_divide-i+1) = c+(1:sub_divide-2*i+1)'+(sub_divide-2*i+1)*1;%�ұ�
    num_mesh(sub_divide-i+1,sub_divide-i+1:-1:i+1) = c+(1:sub_divide-2*i+1)+(sub_divide-2*i+1)*2;%�±�
    num_mesh(sub_divide-i+1:-1:i+1,i) = c+(1:sub_divide-2*i+1)+(sub_divide-2*i+1)*3;%���
    c = c+(sub_divide-2*i+1)*4;%�±�
end
if rem(sub_divide,2)~=0
    num_mesh(rounddd,rounddd) = c+1;
end

ind_i = [0,0,1,1];
ind_j = [0,1,1,0];
for e = 1:num_subelem_per_elem
    [i,j] = find(num_mesh==e,1);
    for n = 1:nn
        if flag_mesh(i+ind_i(n),j+ind_j(n))
            new_element(e:num_subelem_per_elem:end,n) = node_num_on_elem_edge(:,small_mesh(i+ind_i(n),j+ind_j(n)));
        else
            new_element(e:num_subelem_per_elem:end,n) = node_num_in_elem(:,small_mesh(i+ind_i(n),j+ind_j(n)));
        end
    end
end