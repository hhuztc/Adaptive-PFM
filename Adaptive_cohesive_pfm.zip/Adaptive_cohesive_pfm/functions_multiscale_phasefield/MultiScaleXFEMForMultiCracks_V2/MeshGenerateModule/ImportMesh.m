function [element,node] = ImportMesh(filename,elemType)
%ImportMesh ��abaqus�����ļ�inp�е���ƽ������
%   [element,node] = ImportMesh(filename,elemType)ͨ�������ļ����/����·��+
%       �ļ�����filename,��ָ����ȡ�������������ı��ε�Ԫ��Q4'������ȡ����������
%       ��д��element��node��

%% check file extension type
[~,~,ext] = fileparts(filename);
if ~strcmp(ext,'.inp')
    error('Only accept jpg files')
end
%% open file
fileID = fopen(filename,'rt');
%% get node data
NodeFlag = false;
PartFlag = false;
while ~NodeFlag
    tline = fgetl(fileID);
    if ~ischar(tline)
        fclose(fileID);
        error('Cannot find *Node data in ''.inp'' file.');
    end
    % �ڵ�������PARTS�ڲ�
    ind_1 = regexp(tline,'\*\*\s\w+','once');
    if ~isempty(ind_1)
        ind_2 = regexp(tline,'\*\* PARTS','once');
        if ~isempty(ind_2)
            PartFlag = true;
        else
            PartFlag = false;
        end
    end
    
    if PartFlag
        ind = regexp(tline,'\*Node','once');
        if ~isempty(ind)
            NodeFlag = true;
        end
    end
end
formatSpec = ['%d',char(44),'%f',char(44),'%f'];
size_node = [3,Inf];
node = fscanf(fileID,formatSpec,size_node);
node = node(2:end,:)';
%% get element data
switch elemType
    case 'Q4'
        nn = 4+1;
        formatSpec = ['%d',char(44),'%d',char(44),'%d',char(44),'%d',char(44),'%d'];
    otherwise
        error(['Unexpected elem type',num2str(elemType)])
end
ElementFlag = false;
while ~ElementFlag
    tline = fgetl(fileID);
    if ~ischar(tline)
        fclose(fileID);
        error('Cannot find *Element data in ''.inp'' file.');
    end
    % ��Ԫ������PARTS�ڲ�
    ind_1 = regexp(tline,'\*\*\s\w+','once');
    if ~isempty(ind_1)
        ind_2 = regexp(tline,'\*\* PARTS','once');
        if ~isempty(ind_2)
            PartFlag = true;
        else
            PartFlag = false;
        end
    end
    
    if PartFlag
        ind = regexp(tline,'\*Element','once');
        if ~isempty(ind)
            ElementFlag = true;
        end
    end
end
size_element = [nn,Inf];
element = fscanf(fileID,formatSpec,size_element);
element = element(2:end,:)';
%% close file
fclose(fileID);
end















