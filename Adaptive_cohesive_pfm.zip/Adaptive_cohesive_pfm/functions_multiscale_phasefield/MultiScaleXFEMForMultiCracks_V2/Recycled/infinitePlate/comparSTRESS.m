%% plot xfem vonStress vs exact vonStress
Xtemp = node(:,1);
Ytemp = node(:,2);
X = Xtemp(element)';
Y = Ytemp(element)';
    
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

% [sigmax,sigmay,sigmaxy] = exactStressModeI(node,1e4,[5,5],[1,0],100);
[sigmax,sigmay,sigmaxy] = exactStressModeII(node,1e4,[5,5],[1,0],100);
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
Svon_exact_elem = Svon_exact(element);

max_Svon = max([max(max(Svon_xfem)),max(Svon_exact)]);
min_Svon = min([min(min(Svon_xfem)),min(Svon_exact)]);

figure
subplot(1,2,1)
patch(X,Y,Svon_xfem','FaceColor','interp','LineStyle','none')
title('XFEM VON MISES STRESS')
axis image
colorbar
caxis([min_Svon,max_Svon])

subplot(1,2,2)
patch(X,Y,Svon_exact_elem','FaceColor','interp','LineStyle','none')
title('EXACT VON MISES STRESS')
axis image
colorbar
caxis([min_Svon,max_Svon])
%% sigma x
max_Sx = max([max(max(Sx_xfem)),max(sigmax)]);
min_Sx = min([min(min(Sx_xfem)),min(sigmax)]);

Sx_exact_elem = sigmax(element);

figure
subplot(1,2,1)
patch(X,Y,Sx_xfem','FaceColor','interp','LineStyle','none')
title('XFEM X COMPONENT')
axis image
colorbar
caxis([min_Sx,max_Sx])

subplot(1,2,2)
patch(X,Y,Sx_exact_elem','FaceColor','interp','LineStyle','none')
title('EXACT X COMPONENT')
axis image
colorbar
caxis([min_Sx,max_Sx])
%% sigma y
max_Sy = max([max(max(Sy_xfem)),max(sigmay)]);
min_Sy = min([min(min(Sy_xfem)),min(sigmay)]);

Sy_exact_elem = sigmay(element);

figure
subplot(1,2,1)
patch(X,Y,Sy_xfem','FaceColor','interp','LineStyle','none')
title('XFEM Y COMPONENT')
axis image
colorbar
caxis([min_Sy,max_Sy])

subplot(1,2,2)
patch(X,Y,Sy_exact_elem','FaceColor','interp','LineStyle','none')
title('EXACT Y COMPONENT')
axis image
colorbar
caxis([min_Sy,max_Sy])
%% sigma xy
max_Sxy = max([max(max(Sxy_xfem)),max(sigmaxy)]);
min_Sxy = min([min(min(Sxy_xfem)),min(sigmaxy)]);

Sxy_exact_elem = sigmay(element);

figure
subplot(1,2,1)
patch(X,Y,Sy_xfem','FaceColor','interp','LineStyle','none')
title('XFEM XY COMPONENT')
axis image
colorbar
caxis([min_Sxy,max_Sxy])

subplot(1,2,2)
patch(X,Y,Sy_exact_elem','FaceColor','interp','LineStyle','none')
title('EXACT XY COMPONENT')
axis image
colorbar
caxis([min_Sxy,max_Sxy])


%% average nodal stress
nodal_Sx = zeros(size(node));
nodal_Sy = nodal_Sx;
nodal_Sxy = nodal_Sx;
nodal_Svon = nodal_Sx;

for e = 1:numelem
    node_num = element(e,:);
    for i = 1:numel(node_num)
        nodal_Sx(node_num(i),:) = nodal_Sx(node_num(i),:)+[Sx_xfem(e,i),1];
        nodal_Sy(node_num(i),:) = nodal_Sy(node_num(i),:)+[Sy_xfem(e,i),1];
        nodal_Sxy(node_num(i),:) = nodal_Sxy(node_num(i),:)+[Sxy_xfem(e,i),1];
        nodal_Svon(node_num(i),:) = nodal_Svon(node_num(i),:)+[Svon_xfem(e,i),1];
    end
end
nodal_Sx(:,1) = nodal_Sx(:,1)./nodal_Sx(:,2);
nodal_Sy(:,1) = nodal_Sy(:,1)./nodal_Sy(:,2);
nodal_Sxy(:,1) = nodal_Sxy(:,1)./nodal_Sxy(:,2);
nodal_Svon(:,1) = nodal_Svon(:,1)./nodal_Svon(:,2);
nodal_Sx(:,2) = [];
nodal_Sy(:,2) = [];
nodal_Sxy(:,2) = [];
nodal_Svon(:,2) = [];
%% contour sigma x
[X,Y] = meshgrid(linspace(0,10,20));

err_x = (sigmax-nodal_Sx')./sigmax*100;
err_y = (sigmay-nodal_Sy')./sigmay*100;
err_xy = (sigmaxy-nodal_Sxy')./sigmaxy*100;
err_von = (Svon_exact-nodal_Svon')./Svon_exact*100;

Z_Sx_xfem = reshape(nodal_Sx,size(X))';
Z_Sy_xfem = reshape(nodal_Sy,size(X))';
Z_Sxy_xfem = reshape(nodal_Sxy,size(X))';
Z_Svon_xfem = reshape(nodal_Svon,size(X))';

Z_Sx_exact = reshape(sigmax,size(X))';
Z_Sy_exact = reshape(sigmay,size(X))';
Z_Sxy_exact = reshape(sigmaxy,size(X))';
Z_Svon_exact = reshape(Svon_exact,size(X))';

Z_err_x = reshape(err_x,size(X))';
Z_err_y = reshape(err_y,size(X))';
Z_err_xy = reshape(err_xy,size(X))';
Z_err_von = reshape(err_von,size(X))';

min_Sx = min([min(nodal_Sx),min(sigmax)]);
max_Sx = max([max(nodal_Sx),max(sigmax)]);
min_Sy = min([min(nodal_Sy),min(sigmay)]);
max_Sy = max([max(nodal_Sy),max(sigmay)]);
min_Sxy = min([min(nodal_Sxy),min(sigmaxy)]);
max_Sxy = max([max(nodal_Sxy),max(sigmaxy)]);
min_Svon = min([min(nodal_Svon),min(Svon_exact)]);
max_Svon = max([max(nodal_Svon),max(Svon_exact)]);

figure
subplot(1,3,1)
contourf(X,Y,Z_Sx_xfem)
title('XFEM X COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sx,max_Sx])

subplot(1,3,2)
contourf(X,Y,Z_Sx_exact)
title('EXACT X COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sx,max_Sx])

subplot(1,3,3)
contourf(X,Y,Z_err_x)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar
%% contour sigma y
figure
subplot(1,3,1)
contourf(X,Y,Z_Sy_xfem)
title('XFEM Y COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sy,max_Sy])

subplot(1,3,2)
contourf(X,Y,Z_Sy_exact)
title('EXACT Y COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sy,max_Sy])

subplot(1,3,3)
contourf(X,Y,Z_err_y)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar
%% contour sigma xy
figure
subplot(1,3,1)
contourf(X,Y,Z_Sxy_xfem)
title('XFEM XY COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sxy,max_Sxy])

subplot(1,3,2)
contourf(X,Y,Z_Sxy_exact)
title('EXACT XY COMPONENT')
view(2)
axis image
colorbar
caxis([min_Sxy,max_Sxy])

subplot(1,3,3)
contourf(X,Y,Z_err_xy)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar
%% contour sigma von mises
figure
subplot(1,3,1)
contourf(X,Y,Z_Svon_xfem)
title('XFEM VON MISES')
view(2)
axis image
colorbar
caxis([min_Svon,max_Svon])

subplot(1,3,2)
contourf(X,Y,Z_Svon_exact)
title('EXACT VON MISES')
view(2)
axis image
colorbar
caxis([min_Svon,max_Svon])

subplot(1,3,3)
contourf(X,Y,Z_err_von)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar













