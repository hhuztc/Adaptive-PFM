%% plot xfem disp vs exact disp
% ����������������
Xtemp = node(:,1);
Ytemp = node(:,2);
X = Xtemp(element)';
Y = Ytemp(element)';

u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_sctr = u_xfem(element);
u_x_xfem_sctr = u_x(element);
u_y_xfem_sctr = u_y(element);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
% [ux,uy] = exactDispModeII(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);
u_exact_sctr = u_exact(element);
ux_exact_sctr = ux(element);
uy_exact_sctr = uy(element);

u_error = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
u_x_error = (ux(:)-u_x(:))./ux(:)*100;
u_y_error = (uy(:)-u_y(:))./uy(:)*100;
u_error_sctr = u_error(element);
u_x_eroor_sctr = u_x_error(element);
u_y_error_sctr = u_y_error(element);

max_u = max([max(u_exact),max(u_xfem)]);
min_u = min([min(u_exact),min(u_xfem)]);
max_u_x = max([max(ux),max(u_x)]);
min_u_x = min([min(ux),min(u_x)]);
max_u_y = max([max(uy),max(u_y)]);
min_u_y = min([min(uy),min(u_y)]);

%% �ȽϺ�λ��
figure
subplot(1,3,1)
patch(X,Y,u_xfem_sctr','LineStyle','none')
title('XFEM RESULTANT DISPLACEMENT 10\times10 MESH','interpreter','tex')
axis image
colorbar
caxis([min_u,max_u])

subplot(1,3,2)
patch(X,Y,u_exact_sctr','LineStyle','none')
title('EXACT RESULTANT DISPLACEMENT 10\times10 MESH','interpreter','tex')
axis image
colorbar
caxis([min_u,max_u])

subplot(1,3,3)
patch(X,Y,u_error_sctr','LineStyle','none')
title('RELATIVE ERROR(%)')
axis image
colorbar

%% �Ƚ�x����λ��
figure
subplot(1,3,1)
patch(X,Y,u_x_xfem_sctr','LineStyle','none')
title('XFEM X DISPLACEMENT 10\times10 MESH','interpreter','tex')
axis image
colorbar
caxis([min_u_x,max_u_x])

subplot(1,3,2)
patch(X,Y,ux_exact_sctr','LineStyle','none')
title('EXACT X DISPLACEMENT 10\times10 MESH','interpreter','tex')
axis image
colorbar
caxis([min_u_x,max_u_x])

subplot(1,3,3)
patch(X,Y,u_x_eroor_sctr','LineStyle','none')
title('RELATIVE ERROR(%)')
axis image
colorbar