function uv = getDispBC(dispNodes,whichTip,stress_state)

global node

if nargin < 3
    stress_state = 'tension';
end

xcoor = node(dispNodes,:);
switch whichTip
    case 2
        % ���Ѽ�
        switch stress_state
            case 'tension'
                [ux,uy] = exactDispModeI(xcoor,1e4,[5,5],[1,0],100);
            case 'shear'
                [ux,uy] = exactDispModeII(xcoor,1e4,[5,5],[1,0],100);
            otherwise
                error('Unexpected stress_state.')
        end
    case 1
        % ���Ѽ�
        [ux,uy] = exactDispModeI(xcoor,1e4,[5,5],[-1,0],100);
        ux = -ux;
        uy = -uy;
end
uv = zeros(2*length(dispNodes),1);
uv(1:2:end) = ux;
uv(2:2:end) = uy;
end