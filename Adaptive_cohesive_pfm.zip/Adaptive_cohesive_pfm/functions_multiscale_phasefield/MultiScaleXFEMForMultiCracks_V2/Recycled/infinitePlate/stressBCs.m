function f0 = stressBCs(f0,BCEdge,l,m,whichTip,stress_state)
global node
if nargin < 6
    stress_state = 'tension';
end
[W,Q]=quadrature(2,'GAUSS',1);
for e = 1:size(BCEdge,1)
    sctr = BCEdge(e,:);
    sctrx = 2*sctr-1;
    sctry = 2*sctr;
    for q = 1:size(W,1)
        gausspt = Q(q,:);
        N  = lagrange_basis('L2',gausspt);
        gpt = N'*node(sctr,:);
        switch whichTip
            case 2
                % ���Ѽ�
                switch stress_state
                    case 'tension'
                        [sigmax,sigmay,sigmaxy] = exactStressModeI(gpt,1e4,[5,5],[1,0],100);
                    case 'shear'
                        [sigmax,sigmay,sigmaxy] = exactStressModeII(gpt,1e4,[5,5],[1,0],100);
                    otherwise
                        error('Unexpected stress_state.')
                end
            case 1
                % ���Ѽ�
                [sigmax,sigmay,sigmaxy] = exactStressModeI(gpt,1e4,[5,5],[-1,0],100);
        end
        fx = l*sigmax+m*sigmaxy;
        fy = m*sigmay+l*sigmaxy;
        J0 = sqrt(sum((node(sctr(1),:)-node(sctr(2),:)).^2))/2;
        f0(sctrx)=f0(sctrx)+N*fx*det(J0)*W(q);
        f0(sctry)=f0(sctry)+N*fy*det(J0)*W(q);
    end
end
end