%% plot xfem disp vs exact disp
% �������ڳ�����չ����Ԫ
[X,Y] = meshgrid(linspace(0,10,12));        % ��������������

u_xfem = sqrt(u_x.^2+u_y.^2);
Z_xfem = reshape(u_xfem,size(X))';

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
% [ux,uy] = exactDispModeII(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);
Z_exact = reshape(u_exact,size(X))';

err_u = (u_exact-u_xfem')./u_exact*100;
Z_err_u = reshape(err_u,size(X))';

max_u = max([max(u_exact),max(u_xfem)]);
min_u = min([min(u_exact),min(u_xfem)]);

figure
subplot(1,3,1)
contourf(X,Y,Z_xfem)
title('XFEM RESULTANT DISP')
view(2)
axis image
colorbar
caxis([min_u,max_u])

subplot(1,3,2)
contourf(X,Y,Z_exact)
title('EXACT RESULTANT DISP')
view(2)
axis image
colorbar
caxis([min_u,max_u])

subplot(1,3,3)
contourf(X,Y,Z_err_u)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar

%% x component
max_u_x = max([max(ux),max(u_x)]);
min_u_x = min([min(ux),min(u_x)]);

Z_ux_xfem = reshape(u_x,size(X))';
Z_ux_exact = reshape(ux,size(X))';

err_ux = (ux-u_x')./ux*100;
Z_err_ux = reshape(err_ux,size(X))';

figure
subplot(1,3,1)
contourf(X,Y,Z_ux_xfem)
title('XFEM X COMPONENT')
view(2)
axis image
colorbar
caxis([min_u_x,max_u_x])

subplot(1,3,2)
contourf(X,Y,Z_ux_exact)
title('EXACT X COMPONENT')
view(2)
axis image
colorbar
caxis([min_u_x,max_u_x])

subplot(1,3,3)
contourf(X,Y,Z_err_ux)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar

%% y component
max_u_y = max([max(uy),max(u_y)]);
min_u_y = min([min(uy),min(u_y)]);

Z_uy_xfem = reshape(u_y,size(X))';
Z_uy_exact = reshape(uy,size(X))';

err_uy = (uy-u_y')./uy*100;
Z_err_uy = reshape(err_uy,size(X))';

figure
subplot(1,3,1)
contourf(X,Y,Z_uy_xfem)
title('XFEM Y COMPONENT')
view(2)
axis image
colorbar
caxis([min_u_y,max_u_y])

subplot(1,3,2)
contourf(X,Y,Z_uy_exact)
title('EXACT Y COMPONENT')
view(2)
axis image
colorbar
caxis([min_u_y,max_u_y])

subplot(1,3,3)
contourf(X,Y,Z_err_uy)
title('RELATIVE ERROR(%)')
view(2)
axis image
colorbar