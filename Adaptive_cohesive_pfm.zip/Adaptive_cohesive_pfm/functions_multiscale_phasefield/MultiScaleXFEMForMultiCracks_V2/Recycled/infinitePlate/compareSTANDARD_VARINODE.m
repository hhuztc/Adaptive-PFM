%% ���޴�壬��I�ͣ��Ƚ���ͨ�Ľڵ�����������������Ĳ���
%% 11*11 mesh
global element vari_ele_node
load Standard_XFEM_11_11_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_1 = Xtemp(element)';
Y_1 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_1 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

u_xfem = sqrt(u_x.^2+u_y.^2);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);

u_error_1 = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
u_error_1_sctr = u_error_1(element);

%% 11*11 mesh, sub_divide=3
load TEMPvari_node_XFEM_11_11_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_2 = Xtemp(element)';
Y_2 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_2 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

u_xfem = sqrt(u_x.^2+u_y.^2);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);

u_error_2 = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
% ���ǵ��ͼ
u_error_2_sctr = u_error_2(element);

% ȫ����ͼ���������λ��ֵҲҪ����
load TEMPvari_node_XFEM_11_11_mesh_by_all_node
Xtemp = node(:,1);
Ytemp = node(:,2);
[ElemSctr,num_not_nan] = NodeConnectQuadrangle_inOrder(1:length(element));
unique_num_not_nan = unique(num_not_nan);
% Ԥ����
elem_sctr{numel(unique_num_not_nan)} = [];  
X_vari = elem_sctr;
Y_vari = elem_sctr;
u_error_sctr_vari = elem_sctr;
Svon_sctr_vari = elem_sctr;

for i = 1:numel(unique_num_not_nan)
    ind = num_not_nan==unique_num_not_nan(i);
    elem_sctr{i} = ElemSctr(ind,1:unique_num_not_nan(i));
    X_vari{i} = Xtemp(elem_sctr{i})';
    Y_vari{i} = Ytemp(elem_sctr{i})';
    u_error_sctr_vari{i} = u_error_2(elem_sctr{i});
    stress_x_temp = stress(ind,1:unique_num_not_nan(i),1);
    stress_y_temp = stress(ind,1:unique_num_not_nan(i),2);
    stress_xy_temp = stress(ind,1:unique_num_not_nan(i),3);
    Svon_sctr_vari{i} = sqrt(stress_x_temp.^2+stress_y_temp.^2-stress_x_temp.*stress_y_temp+3*stress_xy_temp.^2);
end

% ȫ����ͼ��ʹ�ý�����
[sigmax,sigmay,sigmaxy] = exactStressModeII(node,1e4,[5,5],[1,0],100);
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
Svon_exact_sctr_vari = elem_sctr;
for i = 1:numel(unique_num_not_nan)
    Svon_exact_sctr_vari{i} = Svon_exact(elem_sctr{i});
end

%% subplot von Mises stress ���ǵ��ͼ
min_Svon = min([Svon_xfem_1(:);Svon_xfem_2(:);Svon_exact(:)]);
max_Svon = max([Svon_xfem_1(:);Svon_xfem_2(:);Svon_exact(:)]);

figure
ha = tight_subplot(1,3,[.01 .03],[.1 .01],[.01 .01]);
patch(ha(1),X_1,Y_1,Svon_xfem_1','LineStyle','none')
title(ha(1),'von Mises stress of 11\times11 mesh','interpreter','tex')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_Svon,max_Svon])

% ���ǵ��ͼ
patch(ha(2),X_2,Y_2,Svon_xfem_2','LineStyle','none','Marker','none')
title(ha(2),'von Mises stress of 11\times11 vari-node mesh','interpreter','tex')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_Svon,max_Svon])

% ȫ����ͼ
for i = 1:numel(Svon_sctr_vari)
    patch(ha(3),X_vari{i},Y_vari{i},Svon_sctr_vari{i}','LineStyle','none','Marker','none')
end
title(ha(3),'von Mises stress of 11\times11 vari-node mesh','interpreter','tex')
axis(ha(3),'image')
colorbar(ha(3))
caxis(ha(3),[min_Svon,max_Svon])

%% exact von Mises stress ���ǵ��ͼ
figure
for i = 1:numel(Svon_exact_sctr_vari)
    patch(X_vari{i},Y_vari{i},Svon_exact_sctr_vari{i}','LineStyle','none','Marker','*')
end
title('exact von Mises stress of 11\times11 vari-node mesh','interpreter','tex')
axis('image')
colorbar
caxis([min_Svon,max_Svon])

%% subplot disp relative error
min_error = min([u_error_1;u_error_2]);
max_error = max([u_error_1;u_error_2]);

figure
ha = tight_subplot(1,3,[.01 .03],[.1 .01],[.01 .01]);

patch(ha(1),X_1,Y_1,u_error_1_sctr','LineStyle','none')
title(ha(1),{'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF 11\times11 MESH'},'interpreter','tex')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_error,max_error])

% ���ǵ��ͼ
patch(ha(2),X_2,Y_2,u_error_2_sctr','LineStyle','none')
title(ha(2),{'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF 11\times11 VARI-NODE MESH'},'interpreter','tex')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_error,max_error])

% ȫ����ͼ
for i = 1:numel(u_error_sctr_vari)
    patch(ha(3),X_vari{i},Y_vari{i},u_error_sctr_vari{i}','LineStyle','none')
end
title(ha(3),{'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF 11\times11 VARI-NODE MESH'},'interpreter','tex')
axis(ha(3),'image')
colorbar(ha(3))
caxis(ha(3),[min_error,max_error])