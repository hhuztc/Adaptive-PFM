%% ���޴�壬��I�ͣ��Ƚ����ֲ�ͬ�ߴ������£���λ��������
%% 11*11 mesh
load Standard_XFEM_11_11_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_1 = Xtemp(element)';
Y_1 = Ytemp(element)';

u_xfem = sqrt(u_x.^2+u_y.^2);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);

u_error_1 = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
u_error_1_sctr = u_error_1(element);

%% 33*33 mesh
load Standard_XFEM_33_33_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_2 = Xtemp(element)';
Y_2 = Ytemp(element)';

u_xfem = sqrt(u_x.^2+u_y.^2);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);

u_error_2 = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
u_error_2_sctr = u_error_2(element);

%% multi-scale mesh
% load Multi-scale_XFEM_11_11_mesh_3_divide
load Multi-scale_XFEM_11_11_mesh_3_divide_New.mat   % �����㣨С�߶ȵ�Ԫ�ϵĵ㣩Ҳ�����߽�����
Xtemp = node(:,1);
Ytemp = node(:,2);
X_3 = Xtemp(element)';
Y_3 = Ytemp(element)';

u_xfem = sqrt(u_x.^2+u_y.^2);

[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);

u_error_3 = (u_exact(:)-u_xfem(:))./u_exact(:)*100;
u_error_3_sctr = u_error_3(element);

min_error = min([u_error_1;u_error_2;u_error_3]);
max_error = max([u_error_1;u_error_2;u_error_3]);
%% plot
figure
subplot(1,3,1)
patch(X_1,Y_1,u_error_1_sctr','LineStyle','none')
title({'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF 11\times11 MESH'},'interpreter','tex')
axis image
colorbar
caxis([min_error,max_error])

subplot(1,3,2)
patch(X_2,Y_2,u_error_2_sctr','LineStyle','none')
title({'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF 33\times33 MESH'},'interpreter','tex')
axis image
colorbar
caxis([min_error,max_error])

subplot(1,3,3)
patch(X_3,Y_3,u_error_3_sctr','LineStyle','none')
title({'RELATIVE ERROR';'OF RESULTANT DISPLACEMENT OF MULTI-SCALE MESH'},'interpreter','tex')
axis image
colorbar
caxis([min_error,max_error])