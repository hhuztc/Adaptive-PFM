function [node,element,...
    xyz1,xyz2,...
    topEdge1,botEdge1,leftEdge1,rightEdge1,...
    topEdge2,botEdge2,leftEdge2,rightEdge2] = infinitePlateWith2Tips(L,D,nnx,nny,cracklength)
global elemType
% ���Ѽ�
pt1 = [0 0];
pt2 = [D 0];
pt3 = [D L];
pt4 = [0 L];
[node1,element1] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);

num = size(node1,1);

uln1 = nnx*(nny-1)+1;       % upper left node number
urn1 = nnx*nny;             % upper right node number
lrn1 = nnx;                 % lower right node number
lln1 = 1;                   % lower left node number

topEdge1 = [uln1:1:(urn1-1);(uln1+1):1:urn1]';
botEdge1 = [lln1:1:(lrn1-1);(lln1+1):1:lrn1]';
leftEdge1 = [lln1:nnx:(uln1-nnx);(lln1+nnx):nnx:uln1]';
rightEdge1 = [lrn1:nnx:(urn1-nnx);(lrn1+nnx):nnx:urn1]';

% ���Ѽ�
pt1 = [cracklength 0];
pt2 = [cracklength+D 0];
pt3 = [cracklength+D L];
pt4 = [cracklength L];
[node2,element2] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);
uln2 = nnx*(nny-1)+1+num;       % upper left node number
urn2 = nnx*nny+num;             % upper right node number
lrn2 = nnx+num;                 % lower right node number
lln2 = 1+num;                   % lower left node number

topEdge2 = [uln2:1:(urn2-1);(uln2+1):1:urn2]';
botEdge2 = [lln2:1:(lrn2-1);(lln2+1):1:lrn2]';
leftEdge2 = [lln2:nnx:(uln2-nnx);(lln2+nnx):nnx:uln2]';
rightEdge2 = [lrn2:nnx:(urn2-nnx);(lrn2+nnx):nnx:urn2]';

node = [node1;node2];
element = [element1;element2+num];

xyz1 = node([lln1,lrn1,urn1,uln1],:);        % �����򶥵�����
xyz2 = node([lln2,lrn2,urn2,uln2],:);        % �����򶥵�����
