%% ���޴�壬��I�ͣ��Ƚ����ֲ�ͬ�ߴ������£���Ԫ��ЧӦ��
%% 11*11 mesh
load Standard_XFEM_11_11_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_1 = Xtemp(element)';
Y_1 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_1 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

%% 33*33 mesh
load Standard_XFEM_33_33_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_2 = Xtemp(element)';
Y_2 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_2 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

%% multi-scale mesh
% load Multi-scale_XFEM_11_11_mesh_3_divide
load Multi-scale_XFEM_11_11_mesh_3_divide_New.mat   % �����㣨С�߶ȵ�Ԫ�ϵĵ㣩Ҳ�����߽�����
Xtemp = node(:,1);
Ytemp = node(:,2);
X_3 = Xtemp(element)';
Y_3 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_3 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);

%% exact solution
load Standard_XFEM_33_33_mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
X_2 = Xtemp(element)';
Y_2 = Ytemp(element)';

[sigmax,sigmay,sigmaxy] = exactStressModeI(node,1e4,[5,5],[1,0],100);
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
Svon_exact_elem = Svon_exact(element);

%% subplot
min_Svon = min(min([Svon_xfem_1;Svon_xfem_2;Svon_xfem_3;Svon_exact_elem]));
max_Svon = max(max([Svon_xfem_1;Svon_xfem_2;Svon_xfem_3;Svon_exact_elem]));

figure
subplot(1,3,1)
patch(X_1,Y_1,Svon_xfem_1','LineStyle','none')
title('von Mises stress of 11\times11 mesh','interpreter','tex')
axis image
colorbar
caxis([min_Svon,max_Svon])

subplot(1,3,2)
patch(X_2,Y_2,Svon_xfem_2','LineStyle','none')
title('von Mises stress of 33\times33 mesh','interpreter','tex')
axis image
colorbar
caxis([min_Svon,max_Svon])

subplot(1,3,3)
patch(X_3,Y_3,Svon_xfem_3','LineStyle','none')
title('von Mises stress of multi-scale mesh','interpreter','tex')
axis image
colorbar
caxis([min_Svon,max_Svon])

%% plot exact solution
figure
patch(X_2,Y_2,Svon_exact_elem','LineStyle','none')
title('exact distribution of von Mises stress','interpreter','tex')
axis image
colorbar
caxis([min_Svon,max_Svon])