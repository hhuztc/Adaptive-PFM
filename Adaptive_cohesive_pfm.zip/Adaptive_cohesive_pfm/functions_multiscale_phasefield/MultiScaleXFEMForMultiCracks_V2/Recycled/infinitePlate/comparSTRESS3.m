%% ���޴�壬��I�ͣ����߽��ϵĶ����㸳�߽�����ǰ��ıȽ�
%% multi-scale mesh �����㸳ֵǰ
load Multi-scale_XFEM_11_11_mesh_3_divide
Xtemp = node(:,1);
Ytemp = node(:,2);
X_1 = Xtemp(element)';
Y_1 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_1 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);%% multi-scale mesh
%% �����㸳ֵ��
load Multi-scale_XFEM_11_11_mesh_3_divide_New.mat   % �����㣨С�߶ȵ�Ԫ�ϵĵ㣩Ҳ�����߽�����
Xtemp = node(:,1);
Ytemp = node(:,2);
X_2 = Xtemp(element)';
Y_2 = Ytemp(element)';

Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_2 = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2);
%% subplot
min_Svon = min(min([Svon_xfem_1;Svon_xfem_2]));
max_Svon = max(max([Svon_xfem_1;Svon_xfem_2]));

figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
patch(ha(1),X_1,Y_1,Svon_xfem_1','LineStyle','none')
title(ha(1),'von Mises stress of multi-scale mesh(extra nodes not assigned)')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_Svon,max_Svon])

patch(ha(2),X_2,Y_2,Svon_xfem_2','LineStyle','none')
title(ha(2),'von Mises stress of multi-scale mesh(extra nodes assigned)')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_Svon,max_Svon])