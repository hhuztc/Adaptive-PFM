%% CompareCenterCrackedPlateInTension
close all
%% 1. CenterCrackedPlateInTension7_49Mesh
load CenterCrackedPlateInTension7_49Mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_7_49_mesh = Xtemp(element)';
Y_7_49_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_7_49_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_7_49_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 2. CenterCrackedPlateInTension21_147Mesh
load CenterCrackedPlateInTension21_147Mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_21_147_mesh = Xtemp(element)';
Y_21_147_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_21_147_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_21_147_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 3. CenterCrackedPlateInTensionMultiScaleMeshRefineCrack
load CenterCrackedPlateInTensionMultiScaleMeshRefineCrack
Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
% Resultant displacement
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_refine_crack = u_xfem(:);
% Ԥ�����ڴ�
X_refine_crack{numel(valid_node_type)} = [];
Y_refine_crack{numel(valid_node_type)} = [];
U_refine_crack{numel(valid_node_type)} = [];
Svon_refine_crack{numel(valid_node_type)} = [];
Svon_refine_crack_max = zeros(1,numel(valid_node_type));
Svon_refine_crack_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X_refine_crack{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y_refine_crack{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_refine_crack{i} = u_xfem_refine_crack(ElemSctr(ind,1:valid_node_type(i)))';    % Resultant displacement
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_refine_crack{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_refine_crack{i};
    Svon_refine_crack_max(i) = max(temp(:));
    Svon_refine_crack_min(i) = min(temp(:));
end
%% 4. CenterCrackedPlateInTensionMultiScaleMeshRefineTip
load CenterCrackedPlateInTensionMultiScaleMeshRefineTip
Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
% Resultant displacement
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_refine_tip = u_xfem(:);
% Ԥ�����ڴ�
X_refine_tip{numel(valid_node_type)} = [];
Y_refine_tip{numel(valid_node_type)} = [];
U_refine_tip{numel(valid_node_type)} = [];
Svon_refine_tip{numel(valid_node_type)} = [];
Svon_refine_tip_max = zeros(1,numel(valid_node_type));
Svon_refine_tip_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X_refine_tip{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y_refine_tip{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_refine_tip{i} = u_xfem_refine_tip(ElemSctr(ind,1:valid_node_type(i)))';    % Resultant displacement
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_refine_tip{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_refine_tip{i};
    Svon_refine_tip_max(i) = max(temp(:));
    Svon_refine_tip_min(i) = min(temp(:));
end
%% subplot Resultant displacement
min_u = min([U_xfem_7_49_mesh(:);U_xfem_21_147_mesh(:);u_xfem_refine_crack(:);u_xfem_refine_tip(:)]);
max_u = max([U_xfem_7_49_mesh(:);U_xfem_21_147_mesh(:);u_xfem_refine_crack(:);u_xfem_refine_tip(:)]);
figure 
ha = tight_subplot(1,4,[.1 .01],0.05,0.05);
patch(ha(1),X_7_49_mesh,Y_7_49_mesh,U_xfem_7_49_mesh,'EdgeColor','interp')
patch(ha(2),X_21_147_mesh,Y_21_147_mesh,U_xfem_21_147_mesh,'EdgeColor','interp')
for i = 1:numel(X_refine_crack)
    patch(ha(3),X_refine_crack{i},Y_refine_crack{i},U_refine_crack{i},'EdgeColor','interp')
end
for i = 1:numel(X_refine_tip)
    patch(ha(4),X_refine_tip{i},Y_refine_tip{i},U_refine_tip{i},'EdgeColor','interp')
end
title(ha(1),{'resultant displacement of infinite plate','in shear with 7*49 XFEM'})
title(ha(2),{'resultant displacement of infinite plate','in shear with 21*147 XFEM'})
title(ha(3),{'resultant displacement of infinite plate','in shear with multi-scale XFEM refine crack'})
title(ha(4),{'resultant displacement of infinite plate','in shear with multi-scale XFEM refine tip'})
for i = 1:4
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_u,max_u])
end
%% subplot element von Mises stress
min_s = min([Svon_xfem_21_147_mesh(:);Svon_xfem_7_49_mesh(:);Svon_refine_crack_min(:);Svon_refine_tip_min(:);]);
max_s = max([Svon_xfem_21_147_mesh(:);Svon_xfem_7_49_mesh(:);Svon_refine_crack_min(:);Svon_refine_tip_min(:);]);
figure 
ha = tight_subplot(1,4,[.1 .01],0.05,0.05);
patch(ha(1),X_7_49_mesh,Y_7_49_mesh,Svon_xfem_7_49_mesh,'EdgeColor','interp')
patch(ha(2),X_21_147_mesh,Y_21_147_mesh,Svon_xfem_21_147_mesh,'EdgeColor','interp')
for i = 1:numel(X_refine_crack)
    patch(ha(3),X_refine_crack{i},Y_refine_crack{i},Svon_refine_crack{i},'EdgeColor','interp')
end
for i = 1:numel(X_refine_tip)
    patch(ha(4),X_refine_tip{i},Y_refine_tip{i},Svon_refine_tip{i},'EdgeColor','interp')
end
title(ha(1),{'element von Mises stress of infinite plate','in shear with 7*49 XFEM'})
title(ha(2),{'element von Mises stress of infinite plate','in shear with 21*147 XFEM'})
title(ha(3),{'element von Mises stress of infinite plate','in shear with multi-scale XFEM refine crack'})
title(ha(4),{'element von Mises stress of infinite plate','in shear with multi-scale XFEM refine tip'})
for i = 1:4
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_s,max_s])
end