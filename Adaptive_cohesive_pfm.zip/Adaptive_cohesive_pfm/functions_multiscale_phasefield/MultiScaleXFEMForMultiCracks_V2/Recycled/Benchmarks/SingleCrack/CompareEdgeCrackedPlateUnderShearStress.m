%% CompareEdgeCrackedPlateUnderShearStress
close all
%% 1. EdgeCrackedPlateUnderShearStress9_19
load EdgeCrackedPlateUnderShearStress9_19
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_9_19_mesh = Xtemp(element)';
Y_9_19_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_9_19_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_9_19_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 2. EdgeCrackedPlateUnderShearStress45_95Mesh
load EdgeCrackedPlateUnderShearStress45_95Mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_45_95_mesh = Xtemp(element)';
Y_45_95_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_45_95_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_45_95_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 3. EdgeCrackedPlateUnderShearStressMultiScaleMeshSpecifiedDomain
load EdgeCrackedPlateUnderShearStressMultiScaleMeshSpecifiedDomain
Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
% Resultant displacement
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_specified_domain = u_xfem(:);
% Ԥ�����ڴ�
X_specified_domain{numel(valid_node_type)} = [];
Y_specified_domain{numel(valid_node_type)} = [];
U_specified_domain{numel(valid_node_type)} = [];
Svon_specified_domain{numel(valid_node_type)} = [];
Svon_specified_domain_max = zeros(1,numel(valid_node_type));
Svon_specified_domain_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X_specified_domain{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y_specified_domain{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_specified_domain{i} = u_xfem_specified_domain(ElemSctr(ind,1:valid_node_type(i)))';    % Resultant displacement
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_specified_domain{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_specified_domain{i};
    Svon_specified_domain_max(i) = max(temp(:));
    Svon_specified_domain_min(i) = min(temp(:));
end
%% subplot Resultant displacement
min_u = min([U_xfem_9_19_mesh(:);U_xfem_45_95_mesh(:);u_xfem_specified_domain(:)]);
max_u = max([U_xfem_9_19_mesh(:);U_xfem_45_95_mesh(:);u_xfem_specified_domain(:)]);
figure 
ha = tight_subplot(1,3,[.1 .01],0.05,0.05);
patch(ha(1),X_9_19_mesh,Y_9_19_mesh,U_xfem_9_19_mesh,'EdgeColor','interp')
patch(ha(2),X_45_95_mesh,Y_45_95_mesh,U_xfem_45_95_mesh,'EdgeColor','interp')
for i = 1:numel(X_specified_domain)
    patch(ha(3),X_specified_domain{i},Y_specified_domain{i},U_specified_domain{i},'EdgeColor','interp')
end
title(ha(1),{'resultant displacement of infinite plate','in shear with 9*19 XFEM'})
title(ha(2),{'resultant displacement of infinite plate','in shear with 45*95 XFEM'})
title(ha(3),{'resultant displacement of infinite plate','in shear with multi-scale XFEM(specified domain)'})
for i = 1:3
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_u,max_u])
end
%% subplot element von Mises stress
min_s = min([Svon_xfem_45_95_mesh(:);Svon_xfem_9_19_mesh(:);Svon_specified_domain_min(:)]);
max_s = max([Svon_xfem_45_95_mesh(:);Svon_xfem_9_19_mesh(:);Svon_specified_domain_min(:)]);
figure 
ha = tight_subplot(1,3,[.1 .01],0.05,0.05);
patch(ha(1),X_9_19_mesh,Y_9_19_mesh,Svon_xfem_9_19_mesh,'EdgeColor','interp')
patch(ha(2),X_45_95_mesh,Y_45_95_mesh,Svon_xfem_45_95_mesh,'EdgeColor','interp')
for i = 1:numel(X_specified_domain)
    patch(ha(3),X_specified_domain{i},Y_specified_domain{i},Svon_specified_domain{i},'EdgeColor','interp')
end
title(ha(1),{'element von Mises stress of infinite plate','in shear with 9*19 XFEM'})
title(ha(2),{'element von Mises stress of infinite plate','in shear with 45*95 XFEM'})
title(ha(3),{'element von Mises stress of infinite plate','in shear with multi-scale XFEM(specified domain)'})
for i = 1:3
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_s,max_s])
end