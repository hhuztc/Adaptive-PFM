%% Compare InfinitePlateInTensionMultiScaleMeshRefineCrack with Exact Value
close all
% load InfinitePlateInTensionMultiScaleMeshRefineCrack
% load InfinitePlateInTensionMultiScaleMeshRefineCrack2
load InfinitePlateInTensionMultiScaleMeshRefineCrack3

Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
%% Resultant displacement
% XFEM
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
% EXACT
[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);
u_exact = u_exact(:);
% Ԥ�����ڴ�
clear X Y U_xfem U_exact
X{numel(valid_node_type)} = [];
Y{numel(valid_node_type)} = [];
U_xfem{numel(valid_node_type)} = [];
U_exact{numel(valid_node_type)} = [];
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_xfem{i} = u_xfem(ElemSctr(ind,1:valid_node_type(i)))';    % XFEM
    U_exact{i} = u_exact(ElemSctr(ind,1:valid_node_type(i)))';  % EXACT
end

min_u = min([u_xfem(:);u_exact(:)]);
max_u = max([u_xfem(:);u_exact(:)]);
%% plot Resultant displacement
figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
for i = 1:numel(valid_node_type)
    patch(ha(1),X{i},Y{i},U_xfem{i},'LineStyle','none','EdgeColor','interp') % XFEM
    patch(ha(2),X{i},Y{i},U_exact{i},'LineStyle','none','EdgeColor','interp')    % EXACT
end
% XFEM
title(ha(1),'resultant displacement of infinite plate in tension with multi scale XFEM')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_u,max_u])
% EXACT
title(ha(2),'exact resultant displacement of infinite plate in tension')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_u,max_u])

%% element von Mises stress
[sigmax,sigmay,sigmaxy] = exactStressModeI(node,1e4,[5,5],[1,0],100);   % EXACT
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
% Ԥ�����ڴ�
clear Svon_xfem Svon_exact_elem
Svon_xfem{numel(valid_node_type)} = [];
Svon_exact_elem{numel(valid_node_type)} = [];
Svon_xfem_max = zeros(1,numel(valid_node_type));
Svon_xfem_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    % XFEM
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_xfem{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_xfem{i};
    Svon_xfem_max(i) = max(temp(:));
    Svon_xfem_min(i) = min(temp(:));
    % EXACT
    Svon_exact_elem{i} = Svon_exact(ElemSctr(ind,1:valid_node_type(i)))';
end

min_s = min([Svon_xfem_max(:);Svon_exact(:)]);
max_s = max([Svon_xfem_min(:);Svon_exact(:)]);
%% plot element von Mises stress
figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
for i = 1:numel(valid_node_type)
    patch(ha(1),X{i},Y{i},Svon_xfem{i},'EdgeColor','interp')  % XFEM
    patch(ha(2),X{i},Y{i},Svon_exact_elem{i},'EdgeColor','interp')    % EXACT
end
% XFEM
title(ha(1),'element von Mises stress of infinite plate in tension with multi scale XFEM')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_s,max_s])
% EXACT
title(ha(2),'exact element von Mises stress of infinite plate in tension')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_s,max_s])