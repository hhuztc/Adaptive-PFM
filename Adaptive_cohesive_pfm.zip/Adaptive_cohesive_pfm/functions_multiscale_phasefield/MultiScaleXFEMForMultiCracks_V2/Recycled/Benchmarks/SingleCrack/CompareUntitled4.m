%% Compare InfinitePlateInShear11_11Mesh with ExactValue with RefinCrack with RefineTip with 33_33Mesh
close all
clear global
figure
ha = tight_subplot(2,2,[.1 .01],0.05,0.05);
figure
hb = tight_subplot(2,2,[.1 .01],0.05,0.05);
global node ElemSctr num_not_nan
%% 1. InfinitePlateInTension11_11Mesh
load InfinitePlateInShear11_11Mesh
disp1 = sqrt(u_x.^2+u_y.^2);
vonStress1 = sqrt(stress(:,:,1).^2+stress(:,:,2).^2-...
             stress(:,:,1).*stress(:,:,2)+3*stress(:,:,3).^2);
a1 = plot_field(ha(1),'RDisp',{u_x,u_y},...
                      'Title','resultant displacement of infinite plate in shear with 11*11 XFEM',...
                      'Colormap','jet',...
                      'Colorbar',1);

b1 = plot_field(hb(1),'VonStress',stress,...
                      'Title','element von Mises stress of infinite plate in shear with 11*11 XFEM',...
                      'Colormap','jet',...
                      'Colorbar',1);
%% 2. InfinitePlateInShear33_33Mesh
load InfinitePlateInShear33_33Mesh
disp2 = sqrt(u_x.^2+u_y.^2);
vonStress2 = sqrt(stress(:,:,1).^2+stress(:,:,2).^2-...
             stress(:,:,1).*stress(:,:,2)+3*stress(:,:,3).^2);
a2 = plot_field(ha(2),'RDisp',{u_x,u_y},...
                      'Title','resultant displacement of infinite plate in shear with 33*33 XFEM',...
                      'Colormap','jet',...
                      'Colorbar',1);

b2 = plot_field(hb(2),'VonStress',stress,...
                      'Title','element von Mises stress of infinite plate in shear with 33*33 XFEM',...
                      'Colormap','jet',...
                      'Colorbar',1);
%% 3. InfinitePlateInShearMultiScaleMeshRefineCrack
load InfinitePlateInShearMultiScaleMeshRefineCrack
disp3 = sqrt(u_x.^2+u_y.^2);
vonStress3 = sqrt(stress(:,:,1).^2+stress(:,:,2).^2-...
             stress(:,:,1).*stress(:,:,2)+3*stress(:,:,3).^2);
a3 = plot_field(ha(3),'RDisp',{u_x,u_y},...
                      'Title','resultant displacement of infinite plate in shear with multi-scale XFEM refine crack',...
                      'Colormap','jet',...
                      'Colorbar',1);

b3 = plot_field(hb(3),'VonStress',stress,...
                      'Title','element von Mises stress of infinite plate in shear with multi-scale XFEM refine crack',...
                      'Colormap','jet',...
                      'Colorbar',1);
%% 4. InfinitePlateInShearMultiScaleMeshRefineTip
load InfinitePlateInShearMultiScaleMeshRefineTip
disp4 = sqrt(u_x.^2+u_y.^2);
vonStress4 = sqrt(stress(:,:,1).^2+stress(:,:,2).^2-...
             stress(:,:,1).*stress(:,:,2)+3*stress(:,:,3).^2);
a4 = plot_field(ha(4),'RDisp',{u_x,u_y},...
                      'Title','resultant displacement of infinite plate in shear with multi-scale XFEM refine tip',...
                      'Colormap','jet',...
                      'Colorbar',1);

b4 = plot_field(hb(4),'VonStress',stress,...
                      'Title','element von Mises stress of infinite plate in shear with multi-scale XFEM refine tip',...
                      'Colormap','jet',...
                      'Colorbar',1);
%% 5. EXACT
load InfinitePlateInShear33_33Mesh
[ux,uy] = exactDispModeII(node,1e4,[5,5],[1,0],100);
disp5 = sqrt(ux.^2+uy.^2);
[sigmax,sigmay,sigmaxy] = exactStressModeII(node,1e4,[5,5],[1,0],100);
vonStress5 = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
a5 = plot_field([],'RDisp',{u_x,u_y},...
                   'Title','exact resultant displacement of infinite plate in tension',...
                   'Colormap','jet',...
                   'Colorbar',1);

b5 = plot_field([],'VonStress',[sigmax(:),sigmay(:),sigmaxy(:)],...
                   'Title','exact element von Mises stress of infinite plate in tension',...
                   'Colormap','jet',...
                   'Colorbar',1,...
                   'NodalAverageStress',1);
climit_disp = [min([disp1(:);disp2(:);disp3(:);disp4(:);disp5(:)]),max([disp1(:);disp2(:);disp3(:);disp4(:);disp5(:)])];
climit_stress = [min([vonStress1(:);vonStress2(:);vonStress3(:);vonStress4(:);vonStress5(:)]),max([vonStress1(:);vonStress2(:);vonStress3(:);vonStress4(:);vonStress5(:)])];
a1.CLim = climit_disp;
a2.CLim = climit_disp;
a3.CLim = climit_disp;
a4.CLim = climit_disp;
b1.CLim = climit_stress;
b2.CLim = climit_stress;
b3.CLim = climit_stress;
b4.CLim = climit_stress;

%% �ɰ汾
%{
%% Compare InfinitePlateInShear11_11Mesh with ExactValue with RefinCrack with RefineTip with 33_33Mesh
close all
%% 1. InfinitePlateInTension11_11Mesh
load InfinitePlateInShear11_11Mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_11_11_mesh = Xtemp(element)';
Y_11_11_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_11_11_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_11_11_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 2. InfinitePlateInShear33_33Mesh
load InfinitePlateInShear33_33Mesh
Xtemp = node(:,1);
Ytemp = node(:,2);
% Resultant displacement
X_33_33_mesh = Xtemp(element)';
Y_33_33_mesh = Ytemp(element)';
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem_33_33_mesh = u_xfem(element)';   % ��
% element von Mises stress
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem_33_33_mesh = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)'; % ��
%% 3. EXACT
% Resultant displacement
[ux,uy] = exactDispModeII(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);
u_exact = u_exact(:);
U_exact_33_33_mesh = u_exact(element)'; % ��
% element von Mises stress
[sigmax,sigmay,sigmaxy] = exactStressModeII(node,1e4,[5,5],[1,0],100);
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
Svon_exact_elem_33_33_mesh = Svon_exact(element)';
%% 4. InfinitePlateInShearMultiScaleMeshRefineCrack
load InfinitePlateInShearMultiScaleMeshRefineCrack
Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
% Resultant displacement
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_refine_crack = u_xfem(:);
% Ԥ�����ڴ�
X_refine_crack{numel(valid_node_type)} = [];
Y_refine_crack{numel(valid_node_type)} = [];
U_refine_crack{numel(valid_node_type)} = [];
Svon_refine_crack{numel(valid_node_type)} = [];
Svon_refine_crack_max = zeros(1,numel(valid_node_type));
Svon_refine_crack_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X_refine_crack{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y_refine_crack{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_refine_crack{i} = u_xfem_refine_crack(ElemSctr(ind,1:valid_node_type(i)))';    % Resultant displacement
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_refine_crack{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_refine_crack{i};
    Svon_refine_crack_max(i) = max(temp(:));
    Svon_refine_crack_min(i) = min(temp(:));
end
%% 5. InfinitePlateInShearMultiScaleMeshRefineTip
load InfinitePlateInShearMultiScaleMeshRefineTip
Xtemp = node(:,1);
Ytemp = node(:,2);
valid_node_type = unique(num_not_nan);
% Resultant displacement
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem_refine_tip = u_xfem(:);
% Ԥ�����ڴ�
X_refine_tip{numel(valid_node_type)} = [];
Y_refine_tip{numel(valid_node_type)} = [];
U_refine_tip{numel(valid_node_type)} = [];
Svon_refine_tip{numel(valid_node_type)} = [];
Svon_refine_tip_max = zeros(1,numel(valid_node_type));
Svon_refine_tip_min = zeros(1,numel(valid_node_type));
for i = 1:numel(valid_node_type)
    ind = num_not_nan==valid_node_type(i);
    X_refine_tip{i} = Xtemp(ElemSctr(ind,1:valid_node_type(i)))';
    Y_refine_tip{i} = Ytemp(ElemSctr(ind,1:valid_node_type(i)))';
    U_refine_tip{i} = u_xfem_refine_tip(ElemSctr(ind,1:valid_node_type(i)))';    % Resultant displacement
    Sx_xfem = stress(ind,1:valid_node_type(i),1);
    Sy_xfem = stress(ind,1:valid_node_type(i),2);
    Sxy_xfem = stress(ind,1:valid_node_type(i),3);
    Svon_refine_tip{i} = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
    temp = Svon_refine_tip{i};
    Svon_refine_tip_max(i) = max(temp(:));
    Svon_refine_tip_min(i) = min(temp(:));
end
%% subplot Resultant displacement
min_u = min([U_xfem_11_11_mesh(:);U_xfem_33_33_mesh(:);U_exact_33_33_mesh(:);u_xfem_refine_crack(:);u_xfem_refine_tip(:)]);
max_u = max([U_xfem_11_11_mesh(:);U_xfem_33_33_mesh(:);U_exact_33_33_mesh(:);u_xfem_refine_crack(:);u_xfem_refine_tip(:)]);
figure 
ha = tight_subplot(2,2,[.1 .01],0.05,0.05);
% InfinitePlateInTension11_11Mesh
patch(ha(1),X_11_11_mesh,Y_11_11_mesh,U_xfem_11_11_mesh,'EdgeColor','interp')
% InfinitePlateInShear33_33Mesh
patch(ha(2),X_33_33_mesh,Y_33_33_mesh,U_xfem_33_33_mesh,'EdgeColor','interp')
% InfinitePlateInShearMultiScaleMeshRefineCrack
for i = 1:numel(X_refine_crack)
    patch(ha(3),X_refine_crack{i},Y_refine_crack{i},U_refine_crack{i},'EdgeColor','interp')
end
% InfinitePlateInShearMultiScaleMeshRefineTip
for i = 1:numel(X_refine_tip)
    patch(ha(4),X_refine_tip{i},Y_refine_tip{i},U_refine_tip{i},'EdgeColor','interp')
end
title(ha(1),{'resultant displacement of infinite plate','in shear with 11*11 XFEM'})
title(ha(2),{'resultant displacement of infinite plate','in shear with 33*33 XFEM'})
title(ha(3),{'resultant displacement of infinite plate','in shear with multi-scale XFEM refine crack'})
title(ha(4),{'resultant displacement of infinite plate','in shear with multi-scale XFEM refine tip'})
for i = 1:4
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_u,max_u])
end
%% subplot element von Mises stress
min_s = min([Svon_exact_elem_33_33_mesh(:);Svon_xfem_33_33_mesh(:);Svon_xfem_11_11_mesh(:);Svon_refine_crack_min(:);Svon_refine_tip_min(:);]);
max_s = max([Svon_exact_elem_33_33_mesh(:);Svon_xfem_33_33_mesh(:);Svon_xfem_11_11_mesh(:);Svon_refine_crack_max(:);Svon_refine_tip_max(:);]);
figure 
ha = tight_subplot(2,2,[.1 .01],0.05,0.05);
% InfinitePlateInTension11_11Mesh
patch(ha(1),X_11_11_mesh,Y_11_11_mesh,Svon_xfem_11_11_mesh,'EdgeColor','interp')
% InfinitePlateInShear33_33Mesh
patch(ha(2),X_33_33_mesh,Y_33_33_mesh,Svon_xfem_33_33_mesh,'EdgeColor','interp')
% InfinitePlateInShearMultiScaleMeshRefineCrack
for i = 1:numel(X_refine_crack)
    patch(ha(3),X_refine_crack{i},Y_refine_crack{i},Svon_refine_crack{i},'EdgeColor','interp')
end
% InfinitePlateInShearMultiScaleMeshRefineTip
for i = 1:numel(X_refine_tip)
    patch(ha(4),X_refine_tip{i},Y_refine_tip{i},Svon_refine_tip{i},'EdgeColor','interp')
end
title(ha(1),{'element von Mises stress of infinite plate','in shear with 11*11 XFEM'})
title(ha(2),{'element von Mises stress of infinite plate','in shear with 33*33 XFEM'})
title(ha(3),{'element von Mises stress of infinite plate','in shear with multi-scale XFEM refine crack'})
title(ha(4),{'element von Mises stress of infinite plate','in shear with multi-scale XFEM refine tip'})
for i = 1:4
    axis(ha(i),'image')
    colormap(ha(i),'jet')
    colorbar(ha(i))
    caxis(ha(i),[min_s,max_s])
end
%% subplot exact resultant displacement & von Mises stress
figure 
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.05 .01]);
patch(ha(1),X_33_33_mesh,Y_33_33_mesh,U_exact_33_33_mesh,'EdgeColor','interp')
title(ha(1),'exact resultant displacement of infinite plate in tension')
axis(ha(1),'image')
colormap(ha(1),'jet')
colorbar(ha(1))
caxis(ha(1),[min_u,max_u])
patch(ha(2),X_33_33_mesh,Y_33_33_mesh,Svon_exact_elem_33_33_mesh,'EdgeColor','interp')
title(ha(2),'exact element von Mises stress of infinite plate in tension')
axis(ha(2),'image')
colormap(ha(2),'jet')
colorbar(ha(2))
caxis(ha(2),[min_s,max_s])
%}