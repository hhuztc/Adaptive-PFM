%% Compare InfinitePlateInTension11_11Mesh with Exact Value
close all
load InfinitePlateInTension11_11Mesh

Xtemp = node(:,1);
Ytemp = node(:,2);
%% Resultant displacement
X = Xtemp(element)';
Y = Ytemp(element)';
% XFEM
u_xfem = sqrt(u_x.^2+u_y.^2);
u_xfem = u_xfem(:);
U_xfem = u_xfem(element)';
% EXACT
[ux,uy] = exactDispModeI(node,1e4,[5,5],[1,0],100);
u_exact = sqrt(ux.^2+uy.^2);
u_exact = u_exact(:);
U_exact = u_exact(element)';

min_u = min([u_xfem(:);u_exact(:)]);
max_u = max([u_xfem(:);u_exact(:)]);
%% plot Resultant displacement
figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
% XFEM
patch(ha(1),X,Y,U_xfem,'LineStyle','none')
title(ha(1),'resultant displacement of infinite plate in tension with 11*11 XFEM')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_u,max_u])
% EXACT
patch(ha(2),X,Y,U_exact,'LineStyle','none')
title(ha(2),'exact resultant displacement of infinite plate in tension')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_u,max_u])

%% element von Mises stress
% XFEM
Sx_xfem = stress(:,:,1);
Sy_xfem = stress(:,:,2);
Sxy_xfem = stress(:,:,3);
Svon_xfem = sqrt(Sx_xfem.^2+Sy_xfem.^2-Sx_xfem.*Sy_xfem+3*Sxy_xfem.^2)';
% EXACT
[sigmax,sigmay,sigmaxy] = exactStressModeI(node,1e4,[5,5],[1,0],100);
Svon_exact = sqrt(sigmax.^2+sigmay.^2-sigmax.*sigmay+3*sigmaxy.^2);
Svon_exact_elem = Svon_exact(element)';

min_s = min([Svon_xfem(:);Svon_exact(:)]);
max_s = max([Svon_xfem(:);Svon_exact(:)]);
%% plot element von Mises stress
figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
% XFEM
patch(ha(1),X,Y,Svon_xfem,'LineStyle','none')
title(ha(1),'element von Mises stress of infinite plate in tension with 11*11 XFEM')
axis(ha(1),'image')
colorbar(ha(1))
caxis(ha(1),[min_s,max_s])
% EXACT
patch(ha(2),X,Y,Svon_exact_elem,'LineStyle','none')
title(ha(2),'exact element von Mises stress of infinite plate in tension')
axis(ha(2),'image')
colorbar(ha(2))
caxis(ha(2),[min_s,max_s])