function tf = iseven(x)

validateattributes(x,{'numeric'},{'scalar','integer'})

y = mod(abs(x),2);

if y == 0
    tf = true;
elseif y == 1
    tf = false;
end