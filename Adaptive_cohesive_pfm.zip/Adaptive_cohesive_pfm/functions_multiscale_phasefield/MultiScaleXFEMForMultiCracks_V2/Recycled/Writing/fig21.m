clear variables
clear global
L=5;
D=5;
nnx=6;
nny=6;
pt1 = [0 0];
pt2 = [D 0];
pt3 = [D L];
pt4 = [0 L];
global node element sub_divide vari_ele_node elemType
elemType='Q4';
[node,element] = meshRectangularRegion(pt1,pt2,pt3,pt4,nnx,nny,elemType);
[vari_sctr,ind_iel,ind_vari_ele,x,y] = append_vari_sctr([13,14],'tight',node(:,1),node(:,2))

updElem = [12,13];
sub_divide=3;
[vari_ele_node,~,~] = vari_elem_generate(updElem,sub_divide);
[vari_sctr,ind_iel,ind_vari_ele,x,y] = append_vari_sctr([13,14],'tight',node(:,1),node(:,2))

[vari_sctr,ind_iel,ind_vari_ele,x,y] = append_vari_sctr([13,14],'full',node(:,1),node(:,2))