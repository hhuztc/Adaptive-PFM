figure
ha = tight_subplot(1,2,[.01 .03],[.1 .01],[.01 .01]);
%% single crack, large scale mesh
clear global
load SingleCrackLargeMesh.mat
plot_m(ha(1),'PlotCrack',xCr)
hold on
updElem=[34,35,36,37,38,39,40,41,45,46,47,48,49,50,51,52,56,57,58,59,60,61,62,63,67,68,69,70,71,72,73,74,78,79,80,81,82,83,84,85];
x=node(:,1);
y=node(:,2);
xx=x(element(updElem,:));
yy=y(element(updElem,:));
patch(xx',yy','r')
tt = findobj(ha(1),'-property','Children');
set(ha(1),'Children',[tt(3),tt(2),tt(4)])
axis off

%% single crack, small scale mesh
clear global
load SingleCrackMultiScaleMesh.mat
plot_m(ha(2),'PlotCrack',xCr,'PlotVariNodeMesh','on')
axis off