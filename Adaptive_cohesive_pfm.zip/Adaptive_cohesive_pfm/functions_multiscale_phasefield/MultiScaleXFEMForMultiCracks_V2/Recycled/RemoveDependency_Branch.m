function dofs = RemoveDependency_Branch(xCr,enrich_node,type_elem,pos)

global ElemSctr element num_not_nan node elemType

cracknum = numel(xCr);
crack(cracknum).NB_matrix = [];
crack(cracknum).tip_elem = [];

elemnum = size(ElemSctr,1);
for kk = 1:cracknum
    % Ѱ��ȫ���ڵ㱻�Ѽ��֧������ǿ�ĵ�Ԫ
    enrich_node_kk = enrich_node(:,kk);
    [~,~,~,en_node_kk] = append_vari_sctr(1:elemnum,'full',enrich_node_kk);
    en_node_kk_str = [enrich_node_kk(element),en_node_kk];
    ind = en_node_kk_str==1 | en_node_kk_str==11 | en_node_kk_str==21;
    all_tip_enrich_elem_ind = all(ind,2);
    all_tip_enrich_elem_num = find(all_tip_enrich_elem_ind);
    
    % ������Щ��Ԫ���Ѽ��ǿ�������κ����ĳ˻���ɵļ�ǿϵ��
    for ei = 1:numel(all_tip_enrich_elem_num)
        e = all_tip_enrich_elem_num(ei);
        sctr_all = ElemSctr(e,1:num_not_nan(e));
        sctr_inherent = element(e,:);
        nn = numel(sctr_all);
        NB_Mat_e = zeros(4*nn);
        [~,Q] = gauss_rule(e,enrich_node,xCr,type_elem,0,sctr_all);
        if size(Q,1) < 4*nn
            error('Not enough test points')
        end
        random_sub = randperm(size(Q,1),4*nn);  % ���ȡ�������ֵ�
        for i = 1:4*nn
            pt = Q(random_sub(i),:);
            % �����κ���
            if nn > 4
                [~,~,~,x_extra_node,y_extra_node] = append_vari_sctr(e,'tight',node(:,1),node(:,2));
                extra_node_coor = [x_extra_node',y_extra_node'];
                extra_node_local_coor = G_L_coor(extra_node_coor(:,1),extra_node_coor(:,2),node(sctr_inherent,:));
                all_node_local_coor = G_L_coor(node(sctr_all,1),node(sctr_all,2),node(sctr_inherent,:));
                [N,dNdxi] = shape_function_vari_ele(extra_node_local_coor,pt,all_node_local_coor);
            else
                [N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
            end
            
            % �����֧����
            % �õ��Ѽ�����
            tip_coor = xCr(kk).xTip(e,:);
            if any(isnan(tip_coor))
                warning(['Branch enriched element at no.',num2str(e),' don''t have xTip data.'])
                for in = 1:nn
                    [nearby_elem,~] = find(element==sctr_all(in));
                    ind = find(~isnan(xCr(kk).xTip(nearby_elem,1)),1);
                    if ~isempty(ind)
                        tip_coor = 
                    end
                end
                [nearby_elem,~] = find(element==sctr_all(in));
                ind = find(~isnan(xCr(kk).xTip(nearby_elem,1)),1);
                if isempty(ind)
                    error(['Cant find xTip data for branched enriched element no.',num2str(e)])
                else
                    tip_coor = xCr(cont).xTip(nearby_elem(ind),:);
                end
            end
        end

        
    end
end













