ratio = [2	1.555209953	1.272264631	1.076426265	0.932835821	0.823045267	0.736377025	0.666222518	0.608272506	0.55959709	0.518134715	0.482392668	0.451263538	0.423908436	0.399680256];
ratio_ref = [2.0,1.5,1.0,0.8,0.6,0.4];
ka1_xfem = [1.135,1.103,1.066,1.053,1.038,1.028];
kb1_xfem = [0.282,0.283,0.281,0.281,0.284,0.295];
kb2_xfem = [0.562,0.568,0.576,0.573,0.567,0.546];
ka1_chen = [1.069,1.053,1.039,1.028];
kb1_chen = [0.281,0.281,0.284,0.295];
kb2_chen = [0.577,0.567,0.568,0.546];
% ka1_multi = [1.136482832	1.109607794	1.088657568	1.074887723	1.063486112	1.056475906	1.049735398	1.044375446	1.042092826	1.038738848	1.037695517	1.035402245	1.035193348	1.033642347	1.0338346];
% kb1_multi = [0.285361817	0.283770178	0.28229292	0.281457697	0.280967003	0.281194002	0.281655643	0.282777863	0.284010619	0.285731664	0.287567833	0.289693367	0.291935863	0.294322895	0.296815065];
% kb2_multi = [0.564114757	0.571089787	0.574985602	0.577181641	0.577366124	0.576761843	0.574810528	0.572684173	0.569761691	0.566829921	0.563539346	0.56026505	0.55689712	0.553545354	0.55022105];
ka1_multi = [1.137495768	1.110821511	1.090084191	1.076550056	1.065397706	1.058664153	1.052215499	1.047166499	1.04522065	1.042221848	1.041560646	1.039664234	1.039879279	1.038764336	1.039425233];
kb1_multi = [0.285096325	0.283477115	0.281976243	0.281120146	0.280611699	0.280824563	0.281274721	0.282382947	0.283619675	0.28533926	0.287184431	0.289320532	0.29158076	0.293990423	0.296510977];
kb2_multi = [0.564852042	0.571997598	0.576067069	0.578446614	0.578817631	0.578411881	0.576662489	0.574759181	0.572044464	0.569349479	0.566291742	0.563263842	0.560147015	0.557057068	0.554002911];

figure
plot(ratio,ka1_multi,'-ok',ratio_ref,ka1_xfem,'-sb',ratio_ref(3:end),ka1_chen,'--^r');
xlim([0,2.2])
g = legend('Multi-scale XFEM','Standard XFEM[4]','Analytical results[17]');
set(g,'FontName','Times New Roman');
xlabel('\fontname{Times New Roman} \it b/\ita')
ylabel('\fontname{Times New Roman} \it F^{\rmA}_{\rmI}')
set(gca,'FontName','Times New Roman');

figure
plot(ratio,kb1_multi,'-ok',ratio_ref,kb1_xfem,'-sb',ratio_ref(3:end),kb1_chen,'--^r')
xlim([0,2.2])
g = legend('Multi-scale XFEM','Standard XFEM[4]','Analytical results[17]');
set(g,'FontName','Times New Roman');
xlabel('\fontname{Times New Roman} \it b/\ita')
ylabel('\fontname{Times New Roman} \it F^{\rmB}_{\rmI}')
set(gca,'FontName','Times New Roman');

figure
plot(ratio,kb2_multi,'-ok',ratio_ref,kb2_xfem,'-sb',ratio_ref(3:end),kb2_chen,'--^r')
xlim([0,2.2])
g = legend('Multi-scale XFEM','Standard XFEM[4]','Analytical results[17]');
set(g,'FontName','Times New Roman');
xlabel('\fontname{Times New Roman} \it b/\ita')
ylabel('\fontname{Times New Roman} \it F^{\rmB}_{\rmII}')
set(gca,'FontName','Times New Roman');