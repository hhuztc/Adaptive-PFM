function [k,dgda] = TadaEdgeCrackTension(a,b,sigma)
global E nu StressState
if strcmp(StressState,'PLANE_STRESS')
    E0 = E;
else
    E0 = E/(1-nu^2);
end
f = sqrt(2*b/pi./a.*tan(pi*a/2/b)).*(0.752+2.02*(a/b)+0.37*(1-sin(pi*a/2/b)).^3)./(cos(pi*a/2/b));
k = sigma*sqrt(pi*a).*f;

dfda = 0.0289829*sec(pi*a/2/b).^3.*(87.3514*a.^2-11.5417*b^2*sin(pi*a/b)+1.90986*b^2*sin(2*pi*a/b)+4.45634*b^2*cos(pi*a/2/b)-4.77465*b^2*cos(3*pi*a/2/b)+0.31831*b^2*cos(5*pi*a/2/b)+90.5189*a*b+13.9024*a*b.*sin(pi*a/b)-94*a*b.*sin(pi*a/2/b)+4*a*b.*sin(3*pi*a/2/b)+2*a*b.*sin(5*pi*a/2/b)+a.*(-43.6757*a-60.2595*b).*cos(pi*a/b)-6*a*b.*cos(2*pi*a/b))./(a.^2*b.*sqrt(b*tan(pi*a/2/b)./a));
dkda = sigma*pi*f/2./sqrt(pi*a)+sigma*sqrt(pi*a).*dfda;
dgda = 2*k/E0.*dkda;