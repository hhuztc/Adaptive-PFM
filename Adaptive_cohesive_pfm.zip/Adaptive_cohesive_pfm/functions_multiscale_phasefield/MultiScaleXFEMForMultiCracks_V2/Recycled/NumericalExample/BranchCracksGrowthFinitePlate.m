load BranchedCrackFinitePlateLoadCurve.mat
figure
plot(Nominal_Strain,Nominal_Stress,'-or',Nominal_Strain2,Nominal_Stress2,'--sb');
g = legend('with stability analysis','without stability analysis');
% set(g,'FontName','Times New Roman');
xlabel('\fontname{Times New Roman} \it\epsilon^{\rmnom}')
ylabel('\fontname{Times New Roman} \it \sigma^{\rmnom}')
set(gca,'FontName','Times New Roman');