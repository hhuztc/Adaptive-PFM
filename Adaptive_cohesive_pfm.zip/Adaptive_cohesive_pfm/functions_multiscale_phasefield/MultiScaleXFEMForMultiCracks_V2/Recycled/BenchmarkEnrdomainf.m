% benchmark of ENRdomainf
%% mesh generate
clear variables
[node,element] = meshRectangularRegion([0,0], [20,0], [20,20], [0,20], 21,21,'Q4');
ElemSctr = element;
%% 1��Բ����Ѱ��1
X0 = [10,10];
r = 5;
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,'radius',r);
xr = @(t)pos(1,1)+radius*cos(t);
yr = @(t)pos(1,2)+radius*sin(t);

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, fplot(xr,yr,[-pi,pi])

%% 1��Բ����Ѱ��2
X0 = [10,10];
X1 = [18,15];
r = 10;
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1,'radius',r);
% [enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1);
xr = @(t)pos(1,1)+radius*cos(t);
yr = @(t)pos(1,2)+radius*sin(t);

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, fplot(xr,yr,[-pi,pi])

%% 2��Բ����Ѱ��
X0 = [10,10];
X1 = [18,15];
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1,'method','two');
xr = @(t)pos(1,1)+radius*cos(t);
yr = @(t)pos(1,2)+radius*sin(t);
xr2 = @(t)pos(2,1)+radius*cos(t);
yr2 = @(t)pos(2,2)+radius*sin(t);

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, 
fplot(xr,yr,[-pi,pi])
fplot(xr2,yr2,[-pi,pi])

%% 1����������Ѱ��1
X0 = [10,10];
r = 9;
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,'radius',r,'shape','square');

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, 
plot([pos(:,1)';pos(:,1)'+pos(:,3)';pos(:,1)'+pos(:,3)';pos(:,1)';pos(:,1)'],[pos(:,2)';pos(:,2)';pos(:,2)'+pos(:,4)';pos(:,2)'+pos(:,4)';pos(:,2)'])

%% 1����������Ѱ��2
X0 = [10,10];
X1 = [18,15];
r = 15;
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1,'radius',r,'shape','square');
% [enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1,'shape','square');

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, 
plot([pos(:,1)';pos(:,1)'+pos(:,3)';pos(:,1)'+pos(:,3)';pos(:,1)';pos(:,1)'],[pos(:,2)';pos(:,2)';pos(:,2)'+pos(:,4)';pos(:,2)'+pos(:,4)';pos(:,2)'])

%% 2����������Ѱ��
X0 = [10,10];
X1 = [15,15];
[enrdomain,radius,pos] = ENRdomainf(ElemSctr,node,X0,X1,'method','two','shape','square');

close all
figure,
plot_StdMesh([],element,node);
brush_element([],element,node,enrdomain)
hold on, 
plot([pos(:,1)';pos(:,1)'+pos(:,3)';pos(:,1)'+pos(:,3)';pos(:,1)';pos(:,1)'],[pos(:,2)';pos(:,2)';pos(:,2)'+pos(:,4)';pos(:,2)'+pos(:,4)';pos(:,2)'])