
id = 2:18;
im{9} = [];
for i = 1:numel(id)
    im{i} = frame2im(getframe(figure(id(i))));
end
for i = 1:numel(id)
    [A,map] = rgb2ind(im{i},256);
    if i == 1
        imwrite(A,map,'branchCrackGrowthWithNoStabilityAna.gif','gif','LoopCount',Inf,'DelayTime',0.3,'TransparentColor',double(A(1)));
    else
        imwrite(A,map,'branchCrackGrowthWithNoStabilityAna.gif','gif','WriteMode','append','DelayTime',0.3,'TransparentColor',double(A(1)));
    end
end