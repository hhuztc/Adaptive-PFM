function K = Plan4NodeElemKmatrix(a,b)
global E nu StressState Thickness
ab = a/b;
ba = b/a;
switch StressState
    case 'PLANE_STRESS'
        c0 = E*Thickness/(1-nu^2);
        c1 = 1/3*ba+(1-nu)/6*ab;
        c2 = (1+nu)/8;
        c3 = -1/3*ba+(1-nu)/12*ab;
        c4 = -(1-3*nu)/8;
        c5 = -1/6*ba-(1-nu)/12*ab;
        c6 = -(1+nu)/8;
        c7 = 1/6*ba-(1-nu)/6*ab;
        c8 = (1-3*nu)/8;
        c9 = 1/3*ab+(1-nu)/6*ba;
        c10 = 1/6*ab-(1-nu)/6*ba;
        c11 = -1/6*ab-(1-nu)/12*ba;
        c12 = -1/3*ab+(1-nu)/12*ba;
    case 'PLANE_STRAIN'
        E_temp = E/(1-nu^2);
        nu_temp = nu/(1-nu);
        c0 = E_temp/(1-nu_temp^2);
        c1 = 1/3*ba+(1-nu_temp)/6*ab;
        c2 = (1+nu_temp)/8;
        c3 = -1/3*ba+(1-nu_temp)/12*ab;
        c4 = -(1-3*nu_temp)/8;
        c5 = -1/6*ba-(1-nu_temp)/12*ab;
        c6 = -(1+nu_temp)/8;
        c7 = 1/6*ba-(1-nu_temp)/6*ab;
        c8 = (1-3*nu_temp)/8;
        c9 = 1/3*ab+(1-nu_temp)/6*ba;
        c10 = 1/6*ab-(1-nu_temp)/6*ba;
        c11 = -1/6*ab-(1-nu_temp)/12*ba;
        c12 = -1/3*ab+(1-nu_temp)/12*ba;
    otherwise
        error('Unexpected StressState.')
end
K = c0*[c1  c2  c3  c4  c5  c6  c7  c8;...
        c2  c9  c8  c10 c6  c11 c4  c12;...
        c3  c8  c1  c6  c7  c4  c5  c2;...
        c4  c10 c6  c9  c8  c12 c2  c11;...
        c5  c6  c7  c8  c1  c2  c3  c4;...
        c6  c11 c4  c12 c2  c9  c8  c10;...
        c7  c4  c5  c2  c3  c8  c1  c6;...
        c8  c12 c2  c11 c4  c10 c6  c9;];
end













