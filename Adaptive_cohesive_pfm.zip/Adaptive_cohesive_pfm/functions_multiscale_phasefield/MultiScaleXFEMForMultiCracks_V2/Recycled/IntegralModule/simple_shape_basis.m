function [N,dNdxi] = simple_shape_basis(xi_eta,elem_type)
%Example:
%   xi_eta = [-0.5;0;0.5];
%   [N,dNdxi] = simple_shape_basis(xi_eta,'L2')
%   xi_eta = 0;
%   [N,dNdxi] = simple_shape_basis(xi_eta,'L2')
%   xi_eta = [0.5,0.5];
%   [N,dNdxi] = simple_shape_basis(xi_eta,'Q4')
%   xi_eta = [0,0;0.5,0.5;1,-1];
%   [N,dNdxi] = simple_shape_basis(xi_eta,'Q4')
switch elem_type
    case 'L2'
        ind_1 = size(xi_eta)==1;
        if any(ind_1)   % ����������һ��������һά���飩
            xi = xi_eta(:)';
        end
        N = [1-xi;1+xi]/2;
        dNdxi = repmat([-1;1]/2,1,numel(xi));
    case 'Q4'
        ind_2 = size(xi_eta)==2;
        if nnz(ind_2)==1 && find(ind_2)==1
            xi_eta = xi_eta';
        end
        xi = xi_eta(:,1)';
        eta = xi_eta(:,2)';
        N = 1/4*[(1-xi).*(1-eta);
                 (1+xi).*(1-eta);
                 (1+xi).*(1+eta);
                 (1-xi).*(1+eta)];
        temp = 1/4*[-(1-eta); 
                      1-eta;    
                      1+eta;    
                    -(1+eta); 
                    -(1-xi);
                    -(1+xi);
                      1+xi;
                      1-xi];
        dNdxi = reshape(temp,4,[]);
    otherwise
        error(['Unexpected element type: ',num2str(elem_type)])
end

end