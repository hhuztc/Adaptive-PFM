
id = 2:24;
im{9} = [];
for i = 1:numel(id)
    fig = figure(id(i));
    axis equal
    axis off
    im{i} = frame2im(getframe(fig));
end
for i = 1:numel(id)
    [A,map] = rgb2ind(im{i},256);
    if i == 1
        imwrite(A,map,'randomlyDistriCrack4_1.gif','gif','LoopCount',Inf,'DelayTime',0.3,'TransparentColor',double(A(1)));
    else
        imwrite(A,map,'randomlyDistriCrack4_1.gif','gif','WriteMode','append','DelayTime',0.3,'TransparentColor',double(A(1)));
    end
end