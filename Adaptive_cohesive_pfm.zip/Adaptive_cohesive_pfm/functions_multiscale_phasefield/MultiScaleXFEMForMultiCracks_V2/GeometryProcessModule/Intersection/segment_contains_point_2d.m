function [u,v] = segment_contains_point_2d(p1,p2,p)
% SEGMENT_CONTAINS_POINT_2D reports if a line segment contains a point in 2D.
% ���� p ���Ƿ����߶� p1 p2 �ϣ�p�����Ƕ���㣬����������ڿ���ʵ�ֶ���ж���
%  Discussion:
%
%    A line segment is the finite portion of a line that lies between
%    two points.
%
%    In exact arithmetic, point P is on the line segment between
%    P1 and P2 if and only if 0 <= U <= 1 and V = 0.
%
%    Thanks to Lars Cremean for corecting a MATLAB error in which
%    elementwise multiplication was needed.
%
%  Modified:
%
%    12 May 2005
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, real P1(2), P2(2), the endpoints of the line segment.
%
%    Input, real P(2), a point to be tested.
%
%    Output, real U, the coordinate of P3 along the axis from
%    with origin at P1 and unit at P2.
%
%    Output, real V, the magnitude of the off-axis portion of the
%    vector P3-P1, measured in units of (P2-P1).
%
%{
p1 = [1,1];
p2 = [4,2];
p = [0,0.6666666667;1,1;1.831496437,1.277165479;2.927569817,1.642523272;4,2;5.294178086,2.431392695;0.1399748507,-0.8922149442;0.5398226735,2.380531980;2.744255317,0.3593567362;4.433621843,0.6991344704;4.552081078,3.406112039];
%}
global tol
if isempty(tol)
    tol_loc = 1e-8;
else
    tol_loc = tol;
end

normsq = sum((p2-p1).^2);    % �߶�p1 p2�����ƽ��

if sqrt(normsq) < tol_loc  % ��� p1 p2 �غ�
    dist_p_p1 = sqrt(sum((p-p1).^2,2));
    ind = dist_p_p1>=tol_loc;
    v = zeros(size(p,1),1);
    v(ind) = Inf;
    u = 0.5*ones(size(p,1),1);
    %{
    if sqrt(sum((p-p1).^2)) < tol_loc  % ��� p ���� p1 �غ�
        u = 0.5;
        v = 0.0;
    else
        u = 0.5;
        v = Inf;
    end
    %}
else
    u = ((p-p1)*(p2-p1)')/normsq;
    v = sqrt(((u-1)*p1(1)-u*p2(1)+p(:,1)).^2+((u -1)*p1(2)-u*p2(2)+p(:,2)).^2)/sqrt(normsq);
end

