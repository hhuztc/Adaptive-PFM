function flag = segments_int_2d (p1,p2,q1,q2)
% SEGMENTS_INT_2D computes the intersection of two line segments in 2D.
%
%  Discussion:
%
%    A line segment is the finite portion of a line that lies between
%    two points.
%
%    In 2D, two line segments might not intersect, even though the
%    lines, of which they are portions, intersect.
%
%  Modified:
%
%    12 May 2005
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, real P1(2), P2(2), the endpoints of the first
%    segment.
%
%    Input, real Q1(2), Q2(2), the endpoints of the second
%    segment.
%
%    Output, integer FLAG, records the results.
%    0, the line segments do not intersect.
%    1, the line segments intersect.
%    2, �����߶��غ�,��ʱ����غϲ��ֵ������˵㣨�� �����߶���β������һ��ֱ�ߣ���ʱֻ��1���غϵ㣩
%
%    Output, real R(2), an intersection point, if there is one.
%See also lines_exp_int_2d, segment_contains_point_2d
global tol
if isempty(tol)
    tol_loc = 1e-8;	%ATTENTION A LA TOLERANCE ORI 0.001
else
    tol_loc = tol;
end

%
%  Find the intersection of the two lines of which
%  [P1,P2] and [Q1,Q2] are segments.
%
[ival,r] = lines_exp_int_2d(p1,p2,q1,q2);   % �жϵ�p1,p2��q1,q2����ֱ��֮��Ĺ�ϵ
if ival == 0      % �������ֱ��ƽ��
    flag = 0;
    return
elseif ival == 2    % �������ֱ���غ�
    IsQ1onSegment = true;
    IsQ2onSegment = true;
    IsP1onSegment = true;
    IsP2onSegment = true;
    [u1,v1] = segment_contains_point_2d(p1,p2,q1);  % �ж�q1���߶�p1,p2�Ĺ�ϵ
    if u1 < 0.0-tol_loc || 1.0+tol_loc < u1 % || tol_loc < v1
        IsQ1onSegment = false;
    end
    [u2,v2] = segment_contains_point_2d(p1,p2,q2);  % �ж�q2���߶�p1,p2�Ĺ�ϵ
    if u2 < 0.0-tol_loc || 1.0+tol_loc < u2 % || tol_loc < v2
        IsQ2onSegment = false;
    end
    [u3,v3] = segment_contains_point_2d(q1,q2,p1);
    if u3 < 0.0-tol_loc || 1.0+tol_loc < u3 % || tol_loc < v3
        IsP1onSegment = false;
    end
    [u4,v4] = segment_contains_point_2d(q1,q2,p2);
    if u4 < 0.0-tol_loc || 1.0+tol_loc < u4 % || tol_loc < v4
        IsP2onSegment = false;
    end
    if ~IsQ1onSegment && ~IsQ2onSegment && ~IsP1onSegment && ~IsP2onSegment
        flag = 0;
        return
    end
    if IsQ1onSegment && u1 > tol_loc && u1 < 1-tol_loc  % ���q1����һ���߶εĶ˵��ϣ��򲻼��룬��Ϊ����ῼ��p1��p2�ġ�
        flag(1) = ival;
        flag(end+1:end+2) = q1;
    end
    if IsQ2onSegment && u2 > tol_loc && u2 < 1-tol_loc
        flag(1) = ival;
        flag(end+1:end+2) = q2;
    end
    if IsP1onSegment
        flag(1) = ival;
        flag(end+1:end+2) = p1;
    end
    if IsP2onSegment
        flag(1) = ival;
        flag(end+1:end+2) = p2;
    end
elseif ival == 1    % �������ֱ���ཻ
    %  Is the point on the first segment?
    [u,v] = segment_contains_point_2d(p1,p2,r);   % �жϽ��� r �Ƿ������߶����˵�֮��
    if u < 0.0-tol_loc || 1.0+tol_loc < u % || tol_loc < v  %%%%%ATTENTION A LA TOLERANCE
        flag = 0;
        return
    end
    %  Is the point on the second segment?
    [ u, v ] = segment_contains_point_2d(q1,q2,r);
    if u < 0.0-tol_loc || 1.0+tol_loc < u % || tol_loc < v %%%%%ATTENTION A LA TOLERANCE
        flag = 0;
        return
    end
    
    % ����߶ζ˵��뽻����ڽӽ����ɴ��ý�������߶ζ˵�
    err(1) = sqrt(sum((r-p1).^2));
    err(2) = sqrt(sum((r-p2).^2));
    err(3) = sqrt(sum((r-q1).^2));
    err(4) = sqrt(sum((r-q2).^2));
    ind = find(err<tol_loc,1);
    if ~isempty(ind)    % �ǿ�
        switch ind
            case 1
                r = p1;
            case 2
                r = p2;
            case 3
                r = q1;
            case 4
                r = q2;
        end
    end
    flag = [ival r];
end


