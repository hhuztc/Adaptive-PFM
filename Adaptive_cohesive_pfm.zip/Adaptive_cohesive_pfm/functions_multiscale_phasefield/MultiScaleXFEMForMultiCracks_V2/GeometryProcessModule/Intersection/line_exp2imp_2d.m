function [a,b,c] = line_exp2imp_2d(p1,p2)
% LINE_EXP2IMP_2D converts an explicit line to implicit form in 2D.
% ������ p1, p2 Ϊ�˵���߶ε�һ�㷽�̵�ϵ�� a, b, c
%
%  Discussion:
%
%    The explicit form of a line in 2D is:
%
%      ( P1, P2 ) = ( (X1,Y1), (X2,Y2) ).
%
%    The implicit form of a line in 2D is:
%
%      A * X + B * Y + C = 0
%
%  Modified:
%
%    28 February 2005
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, real P1(2), P2(2), two points on the line.
%
%    Output, real A, B, C, the implicit form of the line.
%
global tol
if isempty(tol)
    tol_loc = 1e-8;
else
    tol_loc = tol;
end

dim_num = 2;
%
%  Take care of degenerate cases.
%
if sqrt(sum((p1-p2).^2)) < tol_loc
    fprintf ( 1, '\n' );
    fprintf ( 1,  'LINE_EXP2IMP_2D - Fatal error!\n' );
    fprintf ( 1,  '  P1 = P2\n' );
    fprintf ( 1,  '  P1 = %f  %f\n', p1(1:dim_num) );
    fprintf ( 1,  '  P2 = %f  %f\n', p2(1:dim_num) );
    error ( 'LINE_EXP2IMP_2D - Fatal error!' );
end
% ֱ�ߵ�һ�㷽�̵�����ϵ����������ⷽ���ο���https://baike.baidu.com/item/%E7%9B%B4%E7%BA%BF%E7%9A%84%E4%B8%80%E8%88%AC%E5%BC%8F%E6%96%B9%E7%A8%8B
a = p2(2)-p1(2);
b = p1(1)-p2(1);
c = p2(1)*p1(2)-p1(1)*p2(2);

NORM = sqrt(a*a+b*b+c*c);
% ��λ��
if ( 0.0 < NORM )
    a = a / NORM;
    b = b / NORM;
    c = c / NORM;
end
% ȷ��ϵ��aΪ����
if ( a < 0.0 )
    a = -a;
    b = -b;
    c = -c;
end

