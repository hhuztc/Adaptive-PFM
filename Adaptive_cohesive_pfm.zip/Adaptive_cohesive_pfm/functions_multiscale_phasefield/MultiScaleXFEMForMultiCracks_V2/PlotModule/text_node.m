function hobj2 = text_node(hobj,node,varargin)
%text_node ��ʾָ�����ı��
%   text_node(hobj,node) ��ʾ node ��������н��ı��
%
%   text_node(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       subindex ��Ԫ/����Ż��߼�����, subtype �� subindex �ǵ�Ԫ����ʱ, 
%       subtype ��Ҫ������Ԫ������Ϣ element,  Color
%
%   hobj = text_node(...) ����ͼ�ξ��
%
%   See also brush_node, brush_element, text_element, plot_VNMesh,
%   plot_StdMesh. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultsubindex = true(size(node,1),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultsubtype = [];
addParameter(p,'subtype',defaultsubtype,@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));

defaultColor = 'b';
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    if isempty(ip.subtype)
        validateattributes(ip.subindex,{'logical'},{'numel',size(ip.node,1),'vector'})
    else
        validateattributes(ip.subindex,{'logical'},{'numel',size(ip.element,1),'vector'})
    end
else
    ip.subindex = unique(ip.subindex);
end

nodenum = size(ip.node,1);
NodeCount = (1:nodenum)';
X = ip.node(:,1);
Y = ip.node(:,2);

if ~isempty(ip.subtype)
    indNode = unique(ip.subtype(ip.subindex,:));
else
    indNode = ip.subindex;
end

%% text
text(X(indNode),Y(indNode),num2str(NodeCount(indNode)),...
    'VerticalAlignment','bottom',...
    'Color',ip.Color,...
    'UserData',10);

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end
