function hobj2 = show_enrichnode(hobj,node,enrich_node,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));
addRequired(p,'enrich_node',@(x) validateattributes(x,{'numeric'},{'2d','integer'}));

defaultsubindex = true(size(enrich_node,2),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultMarker_tip = 'o';
defaultMarker_split = 's';
defaultMarker_junction = 'd';
defaultMarker_blend = 'x';
addParameter(p,'Marker_tip',defaultMarker_tip,@(x) ischar(x));
addParameter(p,'Marker_split',defaultMarker_split,@(x) ischar(x));
addParameter(p,'Marker_junction',defaultMarker_junction,@(x) ischar(x));
addParameter(p,'Marker_blend',defaultMarker_blend,@(x) ischar(x));

defaultColor = {[192,0,0]./255,[255,192,0]./255,[146,208,80]./255,[0,176,240]./255,[0,32,96]./255,'r','y',[0,176,80]./255,[0,112,192]./255,[112,48,160]./255};
addParameter(p,'Color',defaultColor,@(x) iscell(x)); % Ĭ���� 10 ����ɫ

defaultMarkerSize = 8;
addParameter(p,'MarkerSize',defaultMarkerSize,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultLineWidth = 1.2;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));

parse(p,hobj,node,enrich_node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',size(ip.enrich_node,2),'vector'})
else
    ip.subindex = unique(ip.subindex);
end

seriesCrack = 1:size(ip.enrich_node,2);

% extract crack enrich_node
selectedEnrichNode = ip.enrich_node(:,ip.subindex);
numCrack = size(selectedEnrichNode,2);
selectedSeriesCrack = seriesCrack(ip.subindex);

indSplitNode = selectedEnrichNode==2 | selectedEnrichNode==21;
indTipNode = selectedEnrichNode==1; % | selectedEnrichNode==21;
indJunctionNode = selectedEnrichNode==4;
indBlendNode = selectedEnrichNode==11 | selectedEnrichNode==21;

%% plot
iColor = 1;
for i = 1:numCrack
    brush_node(ip.hobj,ip.node,indSplitNode(:,i),...
        'Marker',ip.Marker_split,...
        'MarkerEdgeColor',ip.Color{iColor},...
        'LineWidth',ip.LineWidth,...
        'MarkerSize',ip.MarkerSize,...
        'DisplayName',['heaviside enriched node of crack ',num2str(selectedSeriesCrack(i))]);
    brush_node(ip.hobj,ip.node,indTipNode(:,i),...
        'Marker',ip.Marker_tip,...
        'MarkerEdgeColor',ip.Color{iColor},...
        'LineWidth',ip.LineWidth,...
        'MarkerSize',ip.MarkerSize,...
        'DisplayName',['branch fun enriched node of crack ',num2str(selectedSeriesCrack(i))]);
    brush_node(ip.hobj,ip.node,indJunctionNode(:,i),...
        'Marker',ip.Marker_junction,...
        'MarkerEdgeColor',ip.Color{iColor},...
        'LineWidth',ip.LineWidth,...
        'MarkerSize',ip.MarkerSize,...
        'DisplayName',['junction fun enriched node of crack ',num2str(selectedSeriesCrack(i))]);
    brush_node(ip.hobj,ip.node,indBlendNode(:,i),...
        'Marker',ip.Marker_blend,...
        'MarkerEdgeColor',ip.Color{iColor},...
        'LineWidth',ip.LineWidth,...
        'MarkerSize',ip.MarkerSize,...
        'DisplayName',['corrected branch fun enriched node of crack ',num2str(selectedSeriesCrack(i))]);
    iColor = iColor+1;
    if iColor > numel(ip.Color)
        iColor = 1;
    end
end

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end