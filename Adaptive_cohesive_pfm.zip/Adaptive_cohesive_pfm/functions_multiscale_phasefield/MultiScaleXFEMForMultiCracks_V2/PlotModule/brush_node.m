function hobj2 = brush_node(hobj,node,varargin)
%brush_node ˢ��ָ�����
%   brush_node(hobj,node) ˢ�� node ��������н��, hobj ָ����ͼ��ͼ�ξ��, 
%   �վ�����ڵ�ǰͼ���ϻ���
%
%   brush_node(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       subindex ��Ԫ��Ż��߼�����, MarkerEdgeColor, MarkerFaceColor,
%       LineWidth, Marker, DisplayName
%
%   hobj = brush_node(...) ����ͼ�ξ��
%
%   See also brush_element, text_element, text_node, plot_VNMesh,
%   plot_StdMesh. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultsubindex = true(size(node,1),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultMarkerEdgeColor = 'MATLABauto';
addParameter(p,'MarkerEdgeColor',defaultMarkerEdgeColor,@(x) isnumeric(x)||ischar(x));
defaultMarkerFaceColor = 'none';
addParameter(p,'MarkerFaceColor',defaultMarkerFaceColor,@(x) isnumeric(x)||ischar(x));
defaultMarkerSize = 6;
addParameter(p,'MarkerSize',defaultMarkerSize,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultLineWidth = 0.72;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultMarker = 'o';
addParameter(p,'Marker',defaultMarker,@(x) ischar(x));

defaultDisplayName = 'highlighted nodes';
addParameter(p,'DisplayName',defaultDisplayName,@(x) ischar(x)||isstring(x));

parse(p,hobj,node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',size(ip.node,1),'vector'})
else
    ip.subindex = unique(ip.subindex);
end
xnode = ip.node(:,1);
ynode = ip.node(:,2);

%% scatter plot
h = plot(xnode(ip.subindex),ynode(ip.subindex),...
    'LineStyle','none',...
    'Marker',ip.Marker,...
    'MarkerFaceColor',ip.MarkerFaceColor,...
    'MarkerSize',ip.MarkerSize,...
    'LineWidth',ip.LineWidth,...
    'DisplayName',ip.DisplayName,...
    'UserData',12);
try
    validatestring(ip.MarkerEdgeColor,{'MATLABauto'});
catch
    set(h,'MarkerEdgeColor',ip.MarkerEdgeColor);
end
                                                           
%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end