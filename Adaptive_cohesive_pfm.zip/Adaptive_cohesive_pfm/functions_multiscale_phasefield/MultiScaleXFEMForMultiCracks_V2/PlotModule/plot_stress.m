function hobj2 = plot_stress(hobj,node,ElemSctr,ValidNodeNum,stress,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));
addRequired(p,'ElemSctr',@(x) validateattributes(x,{'numeric'},{'2d','integer'}));
addRequired(p,'ValidNodeNum',@(x) validateattributes(x,{'numeric'},{'column'}));
addRequired(p,'stress',@(x) validateattributes(x,{'numeric'},{'ndims',3,'size',[NaN,NaN,3]}));

defaultDisplacement = zeros(size(node));
addOptional(p,'Displacement',defaultDisplacement,@(x) validateattributes(x,{'numeric'},{'ncols',2}));

defaultStressType = 'VonStress';
addParameter(p,'StressType',defaultStressType,@(x) any(validatestring(x,{'VonStress','XStress','YStress','XYStress'})));
defaultAverageNodalStress = false;
addParameter(p,'AverageNodalStress',defaultAverageNodalStress,@(x) isnumeric(x)&&isscalar(x)||islogical(x));
defaultFactor = 0.01;
addParameter(p,'Factor',defaultFactor,@(x) validateattributes(x,{'numeric'},{'positive','scalar'}));

defaultColorMap = 'jet';
defaultEdgeColor = 'interp';
addParameter(p,'ColorMap',defaultColorMap,@(x) ischar(x));
addParameter(p,'EdgeColor',defaultEdgeColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,node,ElemSctr,ValidNodeNum,stress,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if any(ip.Displacement(:))
    % �������
    if ip.Factor==0.01
        % �Զ�����λ�ƷŴ���
        dispMax = max(ip.Displacement(:));
        dispMin = min(ip.Displacement(:));
        globMax = max(abs([dispMax,dispMin]));
        exp = abs(fix(log10(globMax)))-0.5;
        ip.Factor = 10^exp;
    end
    newNode = ip.node+ip.Factor*ip.Displacement;
    X = newNode(:,1);
    Y = newNode(:,2);
else
    % �����Ǳ���
    X = ip.node(:,1);
    Y = ip.node(:,2);
end

validNodeType = unique(ip.ValidNodeNum);    % ��Ч�������
sumValidNodeType = numel(validNodeType);
connec = cell(1,sumValidNodeType);
xConnec = connec;
yConnec = connec;
stressConnec = connec;
for i = 1:sumValidNodeType
    ind = ip.ValidNodeNum==validNodeType(i);
    connec{i} = ip.ElemSctr(ind,1:validNodeType(i));
    xConnec{i} = X(connec{i});
    yConnec{i} = Y(connec{i});
end

if ip.AverageNodalStress
    [nodeNum,I] = sort(ip.ElemSctr(:));   % ����ȫ�ֽ���ţ����ܺ�0������Ч���)
    indZero = nodeNum==0;
    nodeNum(indZero) = [];    % ȥ0����Ч���
    I(indZero) = [];
    unique_ind = diff([nodeNum;NaN])~=0;  % ȥ�ؽ���߼�����
    sub = find(unique_ind); % ȥ�ؽ���±�/ȥ�ؽ���� nodeNum �е�λ��
    countSingleNode = diff(find([1;unique_ind])); % ͳ�Ƹ�������ظ��Ĵ���
    typeCoincide = unique(countSingleNode);
    max_count = max(typeCoincide);
    
    Sx_temp = ip.stress(:,:,1);
    Sy_temp = ip.stress(:,:,2);
    Sxy_temp = ip.stress(:,:,3);
    Sx_temp = Sx_temp(:);
    Sy_temp = Sy_temp(:);
    Sxy_temp = Sxy_temp(:);
    Sx = Sx_temp(I);
    Sy = Sy_temp(I);
    Sxy = Sxy_temp(I);
    S = zeros(numel(sub),max_count,3);    % �洢����ϵ�Ӧ��ֵ
    for k = 1:numel(typeCoincide)
        ind = countSingleNode==typeCoincide(k);  % ����ظ�����Ϊunique_count_type(k)�Ľ���߼�������ֻ��ӳunique�������
        temp = sub(ind);    % ���� ������ͬ�ظ������Ľ���� nodeNum �е�λ��
        temp2 = -(0:typeCoincide(k)-1); % �� nodeNum ����ǰƫ�� �ظ����� ��λ�ã��õ��ظ�������ͬ�����н��λ������
        ha = temp+temp2;    % �õ��ظ��ڵ�������������൱������ind
        Sx_temp = Sx(ha);
        Sy_temp = Sy(ha);
        Sxy_temp = Sxy(ha);
        S(ind,1:typeCoincide(k),1) = Sx_temp;
        S(ind,1:typeCoincide(k),2) = Sy_temp;
        S(ind,1:typeCoincide(k),3) = Sxy_temp;
    end
    S2 = sum(S,2);
    average_nodal_stress = S2./countSingleNode;  % ����ϵ�ƽ��Ӧ��
    
    STRESS = average_nodal_stress;  % 3 ά�����м�һά��ά���� 1
else 
    STRESS = ip.stress;
end


if strcmpi(ip.StressType,'VonStress')
    sX = STRESS(:,:,1);
    sY = STRESS(:,:,2);
    sXY = STRESS(:,:,3);
    newStress = sqrt(sX.^2+sY.^2-sX.*sY+3*sXY.^2);
elseif strcmpi(ip.StressType,'XStress')
    newStress = STRESS(:,:,1);
elseif strcmpi(ip.StressType,'YStress')
    newStress = STRESS(:,:,2);
elseif strcmpi(ip.StressType,'XYStress')
    newStress = STRESS(:,:,3);
end

% ת���� ��Ԫ���������ʽ
if ip.AverageNodalStress
    for i = 1:sumValidNodeType
        stressConnec{i} = newStress(connec{i});
    end
else
    for i = 1:sumValidNodeType
        ind = ip.ValidNodeNum==validNodeType(i);
        stressConnec{i} = newStress(ind,1:validNodeType(i));
    end
end

%% plot
for i = 1:sumValidNodeType
    patch(xConnec{i}',yConnec{i}',stressConnec{i}',...
        'EdgeColor',ip.EdgeColor)
end

colormap(ip.ColorMap)

title(ip.StressType)
if any(ip.Displacement(:))
    annotation('textbox',[0.7,0.889,0.1,0.1],'FitBoxToText','on','String',['Factor: ',num2str(ip.Factor)])
%     text(0.8,0.8,['Factor: ',num2str(ip.Factor)],'Units','normalized')
end

axis equal

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end