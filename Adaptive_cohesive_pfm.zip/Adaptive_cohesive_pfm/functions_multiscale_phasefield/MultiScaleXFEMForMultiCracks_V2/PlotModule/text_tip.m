function hobj2 = text_tip(hobj,xCr,varargin)


%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'xCr',@(x) isempty(x) || isstruct(x)&&isfield(x,'coor'));

defaultsubindex = true(numel(xCr),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultDomain = 'Local';
addParameter(p,'Domain',defaultDomain,@(x) any(validatestring(x,{'Global','Local'})));
defaultIgnoreInvalidTip = false;
addParameter(p,'IgnoreInvalidTip',defaultIgnoreInvalidTip,@(x) isnumeric(x)&&isscalar(x)||islogical(x));

defaultColor = 'b';
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,xCr,varargin{:});
ip = p.Results;

oldhold = ishold;
hold on

%% Data process
cracknum = numel(ip.xCr);
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',cracknum,'vector'})
else
    ip.subindex = unique(ip.subindex);
end

crackCount = (1:cracknum)';
selectedCrackCount = crackCount(ip.subindex);

if ~isfield(ip.xCr,'tip')
    warning('missing tip field of struct array xCr, all tips will be considered valid.')
    ip.IgnoreInvalidTip = true;
end

if ip.IgnoreInvalidTip
    for i = 1:cracknum
        ip.xCr(i).tip(1,1:2) = ip.xCr(i).coor(1,:);
        ip.xCr(i).tip(2,1:2) = ip.xCr(i).coor(end,:);
    end
end

if strcmpi(ip.Domain,'Global')
    [Index,~] = GetTipIndex(ip.xCr);
    textPt1 = NaN(numel(selectedCrackCount),2); % ��¼��ע������
    textPt2 = textPt1;
    textNum1 = zeros(numel(selectedCrackCount),1);
    textNum2 = textNum1;
    for i = 1:numel(selectedCrackCount)
        c = selectedCrackCount(i);
        textPt1(i,1:2) = ip.xCr(c).tip(1,:);
        textPt2(i,1:2) = ip.xCr(c).tip(2,:);
        textNum1(i) = Index(1,c);
        textNum2(i) = Index(2,c);
    end
else
    textPt1 = NaN(numel(selectedCrackCount),2);
    textPt2 = textPt1;
    for i = 1:numel(selectedCrackCount)
        c = selectedCrackCount(i);
        textPt1(i,1:2) = ip.xCr(c).tip(1,:);
        textPt2(i,1:2) = ip.xCr(c).tip(2,:);
    end
    textNum1 = 1;
    textNum2 = 2;
end
strTextNum1 = strcat(repmat("t",size(textNum1,1),1),string(textNum1));
strTextNum2 = strcat(repmat("t",size(textNum2,1),1),string(textNum2));
%% text
text(textPt1(:,1),textPt1(:,2),strTextNum1,...
     'VerticalAlignment','bottom',...
     'Color',ip.Color,...
     'UserData',10);
text(textPt2(:,1),textPt2(:,2),strTextNum2,...
     'VerticalAlignment','bottom',...
     'Color',ip.Color,...
     'UserData',10);
 
 %% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end
