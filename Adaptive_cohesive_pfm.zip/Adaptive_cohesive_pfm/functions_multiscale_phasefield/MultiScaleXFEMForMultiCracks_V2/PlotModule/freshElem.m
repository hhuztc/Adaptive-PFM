function freshElem(elems)
global node element
X = node(:,1);
Y = node(:,2);
CONNEC = element(elems,:);
Xsctr = X(CONNEC)';
Ysctr = Y(CONNEC)';
patch(X,Y,[1,1,1])
% patch(X,Y,[0.8,0.8,0.8],'FaceAlpha',0.5)