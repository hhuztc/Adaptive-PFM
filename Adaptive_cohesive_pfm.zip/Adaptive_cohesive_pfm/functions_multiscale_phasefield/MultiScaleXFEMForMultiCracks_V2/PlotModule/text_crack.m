function hobj2 = text_crack(hobj,xCr,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'xCr',@(x) isempty(x) || isstruct(x)&&isfield(x,'coor'));

defaultsubindex = true(numel(xCr),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultColor = 'r';
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,xCr,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
cracknum = numel(ip.xCr);
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',cracknum,'vector'})
else
    ip.subindex = unique(ip.subindex);
end

crackCount = (1:cracknum)';
textCount = crackCount(ip.subindex);
textPt = zeros(numel(textCount),2);
for i = 1:numel(textCount)
    numPts = size(ip.xCr(textCount(i)).coor,1);
    if iseven(numPts)
        loc = numPts/2;
        textPt(i,:) = mean(ip.xCr(textCount(i)).coor([loc,loc+1],:));
    else
        loc = (numPts+1)/2;
        textPt(i,:) = ip.xCr(textCount(i)).coor(loc,:);
    end
end
strText = strcat(repmat("c",numel(textCount),1),string(textCount));
%% text
text(textPt(:,1),textPt(:,2),strText,...
    'VerticalAlignment','bottom',...
    'Color',ip.Color,...
    'UserData',10);
 
 %% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end