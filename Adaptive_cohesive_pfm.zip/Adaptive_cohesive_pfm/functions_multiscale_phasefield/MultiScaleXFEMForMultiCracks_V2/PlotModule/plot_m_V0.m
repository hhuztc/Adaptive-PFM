function hobj = plot_m_V0(hobj,varargin)
% plot_m plot mesh,cracks,enrich node,etc. in pre processing.
%Syntax
%   * fighandle_new = plot_m(fighandle_old) creats a new figure window 
%     if fighandle_old is empty, otherwise makes the figure specified by 
%     fighandle_old the current figure, and plot the traditional mesh on
%     the current axes.
%   * ax_new = plot_m(ax_old) updates the plot in the axes specified by
%     ax_old, then return the same axes handle in ax_new.
%   * plot_m(___,Name,Value) specifies the ohter plots such as cracks and
%     their properties by using one or more Name,Value pair arguments. 
%       * Name,Value pair arguments:
%           'TraditionalMeshColor'--face color of traditional mesh
%               'white'(default)|RGB triplet|...
%           'PlotVariNodeMesh'--plot vari-node elements
%               'off'(default)|'on'
%           'VariNodeMeshColor'--face color of vari-node elements
%               [0.8,0.8,0.8](default)|RGB triplet|...
%           'VariNodeMeshMarker'--marker symbol of nodes on vari-node
%           elements
%               '.'(default)|'o'|'*'|...
%           'VariNodeMeshMarkerSize'--marker size of nodes on vari-node
%           elements
%               8(default)|positive value
%           'PlotCrack'--plot cracks
%               xCr struct data
%           'CrackWidth'--crack line width
%               1(default)|positive value
%           'ShowEnrichNode'--mark enriched nodes
%               enrich_node
%           'PlotDelaunay'--plot delaunay triangles
%               two-element cell with first array give TRI, and second
%               array give vertexes' coordinates
%           'DelaunayColor'--line color of delaunay triangles
%               'blue'(default)|RGB triplet|...
%           'DelaunayLineStyle'--line style of delaunay triangles
%               '--'(default)|':'|...
%           'ShowIntegralPoints'--Plot integral points
%               two-dimensional array with second dimension equal 2
%           'IntegralPtMarker'--marker of integral points
%               '.'(default)|'o'|'*'|...
%           'IntegralPtColor'--marker color of integral points
%               'blue'(default)|RGB triplet|...
%           'ShowInteractionDomain'--plot weight coefficient of integral
%           domain
%                two-element cell with first array give elements num in
%                integral domain, and second array give coefficient of
%                nodes.
%           'QEQ1Marker'|'QEQ0Marker'--marker of coefficient equal 1 and
%           0,respectively.
%               '*'|'o'(default)
%           'QEQ1Color'|'QEQ0Color'--marker of coefficient equal 1 and
%           0,respectively.
%               [128/255,0,1](default)|RGB triplet|...
%           'TextNodeNum'--text node number
%               'off'(default)|'on'
%           'TextElemNum'--text element number
%               'off'(default)|'on'
%           'TextEnrichDomain'--restrict node number and element number in
%           enriched elements
%               type_elem
%           'PlotLevelSetFunction'--plot level set function of one crack
%               xCr(one crack)
%           'ShowBoundary'--plot struct boundary
%               boundary node num,
%               bondaryNodes|{botNodes(:),rightNodes(:),topNodes(:),leftNodes(:)}
%           'Title'--add title to the figure
%               string|character vector|character array|cell array
%           'Legend'--add legend to axes
%               'off'(default)|'on'
%           'Save'--save figure to specific path.
%               cell array, {ipas,step_required,path}
%           'MakeGif'--write figure of specified steps to gif file.
%               cell array, {ipas,step_required,path}
%See also plot_def,plot_field

global node element ElemSctr num_not_nan
%% ��ͼǰ��׼��
% ���h�����ڣ����½�ͼ�Σ�������ԭ��ͼ���ϼ�����ͼ
if isempty(hobj)
    h = figure;
    hobj = h;
else
    if isa(hobj,'matlab.ui.Figure')
        h = figure(hobj);
        p = gca;
        delete(p)
    elseif isa(hobj,'matlab.graphics.axis.Axes')
        p = findobj(hobj,'Type','patch',...
				   '-or','Type','line',...
				   '-or','Type','text');
        if ~isempty(p)
            delete(p);
        end
        axes(hobj)
        h = hobj.Parent;
    end
end
name_arg = string(varargin(1:2:end));
value_arg = varargin(2:2:end);
name_visited_flag = false(size(name_arg));
X = node(:,1);
Y = node(:,2);
valid_node_type = unique(num_not_nan);
typenum = numel(valid_node_type);
hold on
%% ���Ƽ���������
if typenum == 0
    typenum = 1;
    valid_node_type = size(element,2);
    ElemSctr = element;
    num_not_nan = repmat(valid_node_type,size(element,1),1);
end
XSctr{typenum} = [];
YSctr{typenum} = [];
CONNEC{typenum} = [];
for i = 1:typenum
    ind = num_not_nan==valid_node_type(i);
    CONNEC{i} = ElemSctr(ind,1:valid_node_type(i));
    XSctr{i} = X(CONNEC{i})';
    YSctr{i} = Y(CONNEC{i})';
    patch(XSctr{i},YSctr{i},[1 1 1],'Tag','o','DisplayName','TraditionalMesh');
end
%% ��ͼ
for i = 1:numel(name_arg)
    if name_visited_flag(i)
        continue;
    end
    switch name_arg(i)
        case 'PlotVariNodeMesh'
            if strcmp(value_arg{i},'on')
                nn_inherent = size(element,2);  % ��Ԫ���н����Ŀ��4
                ind = ~(valid_node_type==nn_inherent);
                sub = find(ind);
                for j = 1:nnz(ind)
                    patch(XSctr{sub(j)},YSctr{sub(j)},[0.8,0.8,0.8],'Marker','.',...
                        'MarkerSize',8,...
                        'Tag','n','DisplayName','VariNodeMesh');
                end
            end
            name_visited_flag(i) = true;
        case 'PlotCrack'
            xCr = value_arg{i};
            for j = 1:size(xCr,2)
                plot(xCr(j).coor(:,1),xCr(j).coor(:,2),'LineWidth',1,...
                    'LineStyle','-',...
                    'Marker','o',...
                    'Tag','l','DisplayName',['Crack No.',num2str(j)]);
            end
            name_visited_flag(i) = true;
        case 'ShowEnrichNode'
            enrich_node = value_arg{i};
            marker = ['^','s','d','v','>','<','p','h','x','*','.','+'];
            k = 1;
            for j = 1:size(enrich_node,2)
                if k > numel(marker)
                    k = 1;
                end
                ind_split_nodes = enrich_node(:,j)==2 | enrich_node(:,j)==21;
                ind_tip_nodes = enrich_node(:,j)==1 | enrich_node(:,j)==21;
                ind_junction_nodes = enrich_node(:,j)==4;
                ind_blend_nodes = enrich_node(:,j)==11 | enrich_node(:,j)==21;
                plot(node(ind_split_nodes,1),node(ind_split_nodes,2),'LineStyle','none',...
                    'Marker',marker(k),...
                    'MarkerSize',10,...
                    'Tag','k','DisplayName',['HeavisideEnrichNodes of crack ',num2str(j)]);
                plot(node(ind_tip_nodes,1),node(ind_tip_nodes,2),'LineStyle','none',...
                    'Marker',marker(k),...
                    'MarkerSize',5,...
                    'Tag','j','DisplayName',['TipEnrichNodes of crack ',num2str(j)]);
                plot(node(ind_junction_nodes,1),node(ind_junction_nodes,2),'LineStyle','none',...
                    'Marker',marker(k),...
                    'MarkerSize',15,...
                    'Tag','i','DisplayName',['JunctionEnrichNodes of crack ',num2str(j)]);
                plot(node(ind_blend_nodes,1),node(ind_blend_nodes,2),'LineStyle','none',...
                    'Marker','*',...
                    'MarkerSize',8,...
                    'Tag','h','DisplayName',['BlendEnrichNodes of crack ',num2str(j)]);
                k = k+1;
            end
            name_visited_flag(i) = true;
        case 'PlotDelaunay'
            temp = value_arg{i};
            TRI = temp{1};
            XY = temp{2};
            triplot(TRI,XY(:,1),XY(:,2),'b--','Tag','e','DisplayName','Delaunays');
            name_visited_flag(i) = true;
        case 'ShowIntegralPoints'
            gausspt = value_arg{i};
            plot(gausspt(:,1),gausspt(:,2),'LineStyle','none',...
                'Color','blue',...
                'Marker','.',...
                'Tag','f','DisplayName','IntegralPts');
            name_visited_flag(i) = true;
        case 'ShowInteractionDomain'
            temp = value_arg{i};
            Jdomain = temp{1};
            qnode = temp{2};
            node_num_Jdomain = ElemSctr(Jdomain,:); % �����û������ڵĵ�Ԫ�ϵĽ���ţ���Ч�����0���
            node_num_q_eq_1 = node_num_Jdomain(qnode==1);  % �����û������ڵĵ�Ԫ�ϵĽ��Ȩϵ��=1�Ľ���ţ�������
            node_num_q_eq_0 = node_num_Jdomain(qnode==0);
            plot(node(node_num_q_eq_1,1),node(node_num_q_eq_1,2),...
                'Marker','*',...
                'Color',[128/255,0,1],...
                'MarkerSize',8,...
                'LineStyle','none',...
                'Tag','c','DisplayName','q = 1');
            plot(node(node_num_q_eq_0,1),node(node_num_q_eq_0,2),...
                'Marker','o',...
                'Color',[128/255,0,1],...
                'MarkerSize',8,...
                'LineStyle','none',...
                'Tag','d','DisplayName','q = 0');
            name_visited_flag(i) = true;
        case 'TextNodeNum'
            if strcmp(value_arg{i},'on')
                NodeCount = (1:size(node,1))';
                ind = true(size(NodeCount));
                flag = name_arg=="TextEnrichDomain";
                if any(flag)
                    type_elem = value_arg{flag};
                    ind = sum(type_elem,2)~=0;  % ��Ԫ���Ͳ���0��������ind �߼�����
                    ind = setdiff(unique(ElemSctr(ind,:)),0);   % ȥ����Ч�����(0)��ind �±�����
                    name_visited_flag(flag) = true;
                end
                text(X(ind),Y(ind),num2str(NodeCount(ind)),'Color','b','Tag','b');
            end
            name_visited_flag(i) = true;
        case 'TextElemNum'
            if strcmp(value_arg{i},'on')
                Average_of_X_of_Elem = mean(X(element),2);
                Average_of_Y_of_Elem = mean(Y(element),2);
                ElemCount = (1:size(element,1))';
                ind = true(size(ElemCount));
                flag = name_arg=="TextEnrichDomain";
                if any(flag)
                    type_elem = value_arg{flag};
                    ind = sum(type_elem,2)~=0;  % ��Ԫ���Ͳ���0������
                    name_visited_flag(flag) = true;
                end
                text(Average_of_X_of_Elem(ind),Average_of_Y_of_Elem(ind),num2str(ElemCount(ind)),...
                    'Color','r','Tag','a');
            end
            name_visited_flag(i) = true;
        case 'PlotLevelSetFunction'
            xCr = value_arg{i};
            NodeLevelSetValue = zeros(size(node,1),1);
            for j = 1:size(node,1)
                [~,NodeLevelSetValue(j),~] = signed_distance(xCr(1).coor,node(j,:),0);
            end
            for j = 1:typenum
                patch(XSctr{j},YSctr{j},NodeLevelSetValue(CONNEC{j})','EdgeColor','interp','Tag','m','DisplayName','LevelSetFunction');
            end
            colormap winter
            colorbar
            name_visited_flag(i) = true;
        case 'ShowBoundary'
            temp = value_arg{i};
            [~,I] = min(size(temp));
            if I == 1
                temp = temp';
            end
            for j = 1:size(temp,2)
                plot(node(temp(:,j),1),node(temp(:,j),2),'Marker','s','LineStyle','none','Tag','g','DisplayName','Boundary')
            end
            name_visited_flag(i) = true;
    end
end
%% ͼ��˳������
obj = findobj(gca,'-regexp','Tag','[^'']');
TagValue = get(obj,'Tag');
if ~isa(TagValue,'cell')
    TagValue = mat2cell(TagValue,ones(length(TagValue),1));
end
ind_TagValue = cellfun(@(x) numel(x)==1,TagValue);
TagValue = cell2mat(TagValue(ind_TagValue));    % TagValue, obj����Ҫ�õ�
obj = obj(ind_TagValue);
[~,I] = sort(TagValue);
set(gca,'Children',obj(I))
%% property����
for i = 1:numel(name_arg)
    if name_visited_flag(i)
        continue;
    end
    switch name_arg(i)
        case 'TraditionalMeshColor'
            set(findobj(gca,'Tag','o'),'FaceColor',value_arg{i});
            name_visited_flag(i) = true;
        case 'VariNodeMeshColor'
            set(findobj(gca,'Tag','n'),'FaceColor',value_arg{i});
            name_visited_flag(i) = true;
        case 'VariNodeMeshMarker'
            set(findobj(gca,'Tag','n'),'Marker',value_arg{i});
            name_visited_flag(i) = true;
        case 'VariNodeMeshMarkerSize'
            set(findobj(gca,'Tag','n'),'MarkerSize',value_arg{i});
            name_visited_flag(i) = true;
        case 'CrackWidth'
            set(findobj(gca,'Tag','l'),'LineWidth',value_arg{i});
            name_visited_flag(i) = true;
        case 'DelaunayColor'
            set(findobj(gca,'Tag','e'),'Color',value_arg{i});
            name_visited_flag(i) = true;
        case 'DelaunayLineStyle'
            set(findobj(gca,'Tag','e'),'LineStyle',value_arg{i});
            name_visited_flag(i) = true;
        case 'IntegralPtMarker'
            set(findobj(gca,'Tag','f'),'Marker',value_arg{i});
            name_visited_flag(i) = true;
        case 'IntegralPtColor'
            set(findobj(gca,'Tag','f'),'Color',value_arg{i});
            name_visited_flag(i) = true;
        case 'QEQ1Marker'
            set(findobj(gca,'Tag','c'),'Marker',value_arg{i});
            name_visited_flag(i) = true;
        case 'QEQ1Color'
            set(findobj(gca,'Tag','c'),'Color',value_arg{i});
            name_visited_flag(i) = true;
        case 'QEQ0Marker'
            set(findobj(gca,'Tag','d'),'Marker',value_arg{i});
            name_visited_flag(i) = true;
        case 'QEQ0Color'
            set(findobj(gca,'Tag','d'),'Color',value_arg{i});
            name_visited_flag(i) = true;
        case 'Title'
            title(value_arg{i});
            name_visited_flag(i) = true;
        case 'Legend'
            if strcmp(value_arg{i},'on')
                ind_TagValue = TagValue=='b' | TagValue=='a';
                TagValue(ind_TagValue) = [];
                obj(ind_TagValue) = [];
                
                ind_TagValue = TagValue=='g';
                sub1 = [];
                if nnz(ind_TagValue) > 1
                    sub1 = find(ind_TagValue,nnz(ind_TagValue)-1);
                end
                
                ind_TagValue = TagValue=='m';
                sub2 = [];
                if nnz(ind_TagValue) > 1
                    sub2 = find(ind_TagValue,nnz(ind_TagValue)-1);
                end
                
                ind_TagValue = TagValue=='n';
                sub3 = [];
                if nnz(ind_TagValue) > 1
                    sub3 = find(ind_TagValue,nnz(ind_TagValue)-1);
                end
                
                ind_TagValue = TagValue=='o';
                sub4 = [];
                if nnz(ind_TagValue) > 1
                    sub4 = find(ind_TagValue,nnz(ind_TagValue)-1);
                end
                obj([sub1(:);sub2(:);sub3(:);sub4(:)]) = [];
                TagValue([sub1(:);sub2(:);sub3(:);sub4(:)]) = [];
                [~,I] = sort(TagValue,'descend');
                legend(obj(I));
            end
            name_visited_flag(i) = true;
    end
end
axis image
if all(name_visited_flag)
    return
end
%% ����ͼƬ������gif
for i = 1:numel(name_arg)
    if name_visited_flag(i)
        continue;
    end
    switch name_arg(i)
        case 'Save'
            temp = value_arg{i};
            ipas = temp{1};
            step_required = temp{2};
            path = temp{3};
            if any(step_required==ipas)
                h.Position = get(0,'ScreenSize');
                print(h,[path,'PlotMesh_',num2str(ipas)],'-dpng','-r0');
            end
            name_visited_flag(i) = true;
        case 'MakeGif'
            temp = value_arg{i};
            ipas = temp{1};
            step_required = temp{2};
            first_step = min(step_required);
            path = temp{3};
            if any(step_required==ipas)
                h.Position = get(0,'ScreenSize');
                frame = getframe(h);
                im = frame2im(frame);
                [A,map] = rgb2ind(im,256);
                if ipas == first_step
                    imwrite(A,map,[path,'Animate.gif'],'gif','LoopCount',Inf,'DelayTime',0.5);
                else
                    imwrite(A,map,[path,'Animate.gif'],'gif','WriteMode','append','DelayTime',0.5);
                end
            end
            name_visited_flag(i) = true;
    end
end
if ~all(name_visited_flag)
    warning('Unexpected Name Value pair argument %s.\n',name_arg{~name_visited_flag});
end

end









%% old version
%{
function h = plot_m(h,xCr,type_elem,enrich_node,plot_elem_num,plot_node_num,... % 6
    plot_J_radius,plot_legend,save_pic,...
    plot_delaunay,plot_gausspt,plot_vari_elem,Heaviside_value,show_boundary)
% PLOT_M Plot mesh and enriched nodes to check 
% Format: h = plot_m(h,xCr,enrich_node,plot_elem_num,plot_node_num,plot_legend,save_pic)
% h �������վ������½�ͼ�Σ����hʱ�ṹ�壬����ԭͼ�ϼ������ơ�
% xCr ��������
% type_elem ��type_elem�ǿգ���������ʱ��ֻ������Ԫ���Է���ĵ�Ԫ������ı��
% enrich_node ��ͬ���������£��ڵ��ǿ״̬���վ����򲻻��Ƽ�ǿ״̬
% plot_elem_num �Ƿ��ע��Ԫ���
% plot_node_num �Ƿ��ע�ڵ���
% plot_J_radius �Ƿ����J����������ֵ0��վ����򲻻��ƣ�
%               1x1 ����ÿ���Ѽ��J���ְ뾶����ֵΪJ���ֵİ뾶����
%               1xn or nx1
%               ����ָ���Ѽ��ŵ�J���ְ뾶����һ����ֵΪJ���ְ뾶��������ֵΪ��ǰʱ�䲽ȫ���Ѽ��ţ������⣺ÿһ�θ��£������Ѽ�ۺϵ���ȫ���Ѽ��Ÿı䣩
% plot_legend �Ƿ����ͼ��
% save_pic �Ƿ񱣴�ͼƬ����ʽ��
%          save_pic={'File_Path','File_Name','File_Format'} ��ѡͼƬ·�������ơ���ʽ
%                  ={'File_Path','File_Name',ipas,spesific_step,'File_Format'} ��ѡͼƬ·������ʽ�������ض�ʱ�䲽��ͼ��
%                  =0 �������κ�ͼ��
% �Ľ����� ����ͼ��ʱ������ȫ��ɾ��J����ͼ�Σ����Ǹ�����չ�Ѽ��Ÿ���
if nargin == 9
    plot_delaunay = [];
    plot_gausspt = [];
    plot_vari_elem = false;
    Heaviside_value = [];
    show_boundary = [];
end
%% ��ͼǰ��׼��
global node element vari_ele_node ElemSctr num_not_nan
if isempty(vari_ele_node)
    IsVariNodeElem = false;
else
    IsVariNodeElem = true;
end
% ���h�����ڣ����½�ͼ�Σ�������ԭ��ͼ���ϼ�����ͼ
if isempty(h)
    h.fig_handle = figure;
    NEW = true; % ������ͼ���
else
    figure(h.fig_handle);
    NEW = false;
end
hold on
legend off
%% ���Ƽ���������
% ���»��������������������ͼ���ߴ��ڱ��㵥Ԫ
if NEW || plot_vari_elem
    if ~NEW
        delete(h.mesh)
    end
    Xtemp = node(:,1);
    Ytemp = node(:,2);
    X = Xtemp(element)';
    Y = Ytemp(element)';
    h.mesh = patch(X,Y,[0.6 0.6 0.6],'DisplayName','Mesh');
end
%% ���Ʊ��㵥Ԫ
if plot_vari_elem && IsVariNodeElem
    vari_elem = vari_ele_node(:,1);    % ���㵥Ԫ���
    node_on_varielem_edge = vari_ele_node(:,2:end);    % �ڱ��㵥Ԫ�߽��ϵĽ����
    node_on_varielem_edge = node_on_varielem_edge(node_on_varielem_edge~=0);   % ת��Ϊ����
    if ~NEW && isfield(h,'vari_elem')
        delete(h.vari_elem)
        delete(h.vari_elem_node)
    end
    X2 = Xtemp(element(vari_elem,:))';
    Y2 = Ytemp(element(vari_elem,:))';
    h.vari_elem = patch(X2,Y2,[0.8,0.8,0.8],'DisplayName','Variable-node elements');
    h.vari_elem_node = plot(node(node_on_varielem_edge,1),node(node_on_varielem_edge,2),...
        'Color','k',...
        'LineStyle','none',...
        'Marker','.',...
        'MarkerSize',8);
end
%% ���Ƽ�����߽�
if ~isempty(show_boundary) && isa(show_boundary,'cell')
    % ���»��Ƶ���������Ԫ����������仯
    if ~NEW && isfield(h,'boundarynodes') && numel(unique(num_not_nan))==1
        delete(h.boundarynodes)
    end
    botNodes = show_boundary{1};
    rightNodes = show_boundary{2};
    topNodes = show_boundary{3};
    leftNodes = show_boundary{4};
    boundary_nodes = [botNodes(:);rightNodes(:);topNodes(:);leftNodes(:)];
    h.boundarynodes = plot(node(boundary_nodes,1),node(boundary_nodes,2),...
        'Color',[1,128/255,64/255],...
        'Marker','s',...
        'LineStyle','none',...
        'DisplayName','BoundaryNodes');
end
%% ���ƽ���Ծ������ǿֵ
if ~isempty(Heaviside_value)
    if isempty(type_elem)
        error('type_elem should be assigned.')
    end
    if ~NEW && isfield(h,'heaviside')
        delete(h.heaviside)
    end
    Xtemp = node(:,1);
    Ytemp = node(:,2);
    crack_num = size(type_elem,2);
    valid_nodes_num_type = unique(num_not_nan);
    k = 1;
    for i = 1:crack_num
        for j = 1:numel(valid_nodes_num_type)
            ind_valid_nodes_num_eq_j = num_not_nan==valid_nodes_num_type(j);
            sctr_all_nodes = ElemSctr(ind_valid_nodes_num_eq_j,1:valid_nodes_num_type(j));
            X_for_H = Xtemp(sctr_all_nodes)';
            Y_for_H = Ytemp(sctr_all_nodes)';
            H_value = Heaviside_value(:,i);
            H_value = H_value(sctr_all_nodes)';
            h.heaviside(k) = patch(X_for_H,Y_for_H,H_value,...
                'LineStyle','none',...
                'DisplayName','Heaviside value');
            k = k+1;
        end
    end
    colormap summer
    colorbar
end
%% �������ơ���ǿ�ڵ�
% ����������ɫ����ǿ�ڵ��Ƿ���
color = [255,0,0;
    255,255,0;
    128,64,64;
    128,0,0;
    255,128,128;
    255,128,64;
    128,255,0;
    0,128,0;
    0,128,128;
    0,255,255;
    0,64,128;
    0,0,255;
    128,128,255;
    255,128,192;
    128,0,128;
    255,0,255;
    255,0,128]/255;
marker = {'^','s','d','v','>','<','p','h','x','*','.','+'};
if ~NEW     % ɾ��ԭ�е�ͼ��
   for k = 1:size(xCr,2)
      delete(h.crack_handle(k));    % ɾ������
      try  % ɾ���Ѽ��ǿ���������ƿ������˶������Ѽ⣬���Ի������������������ά��
          delete(h.tip_handle(k));
      catch ME
          if ~(strcmp(ME.identifier,'MATLAB:badsubscript') || strcmp(ME.identifier,'MATLAB:nonExistentField'))
              throw(ME);
          end
      end
      try
          delete(h.split_handle(k));    % ɾ���ᴩ��ǿ
      catch ME
          if ~(strcmp(ME.identifier,'MATLAB:badsubscript') || strcmp(ME.identifier,'MATLAB:nonExistentField'))
              throw(ME);
          end
      end
      try % ɾ�����Ӽ�ǿ���������Ʋ������Ӽ�ǿ�����Ի������������������ά�� �� �����˲����ڵ��ֶ�
          delete(h.junction_handle(k));
      catch ME
          if ~(strcmp(ME.identifier,'MATLAB:badsubscript') || strcmp(ME.identifier,'MATLAB:nonExistentField'))
              throw(ME);
          end
      end
      try
          delete(h.blend_handle(k))
      catch ME
          if ~(strcmp(ME.identifier,'MATLAB:badsubscript') || strcmp(ME.identifier,'MATLAB:nonExistentField'))
              throw(ME);
          end
      end
   end
end
i = 0;  % ��ɫָ������
sum_plot_junction_crack = 0;  % ��Ҫ���Ӻ�����ǿ�����Ƽ���
sum_plot_split_crack = 0;
sum_plot_tip_crack = 0;
sum_plot_blend = 0;
for k = 1:size(xCr,2)
    i = i+1;
    if i > length(color)
        i = 1;
    end
    h.crack_handle(k) = plot(xCr(k).coor(:,1),xCr(k).coor(:,2),...
        'LineWidth',1,...
        'LineStyle','-',...
        'Color',color(i,:),...
        'Marker','o',...
        'MarkerFaceColor',[.49 1 .63],...
        'MarkerSize',3,...
        'DisplayName',['Crack',num2str(k)]);
    
    if ~isempty(enrich_node)
        split_nodes = find(enrich_node(:,k)==2 | enrich_node(:,k)==21);
        tip_nodes = find(enrich_node(:,k) == 1);
        junction_nodes = find(enrich_node(:,k) == 4);
        blend_nodes = find(enrich_node(:,k)==11 | enrich_node(:,k)==21);
        % ����Ѽ��ǿ�ڵ�
        if ~isempty(tip_nodes)
            sum_plot_tip_crack = sum_plot_tip_crack+1;
            h.tip_handle(sum_plot_tip_crack) = ...
                plot(node(tip_nodes,1),node(tip_nodes,2),...
                'LineStyle','none',...
                'Color',color(i,:),...
                'Marker',marker{k},...
                'MarkerSize',5,...
                'DisplayName',['Tip Nodes of Crack ',num2str(k)]);
        end
        % ��ǹᴩ��ǿ�ڵ�
        if ~isempty(split_nodes)
            sum_plot_split_crack = sum_plot_split_crack+1;
            h.split_handle(sum_plot_split_crack) = ...
                plot(node(split_nodes,1),node(split_nodes,2),...
                'LineStyle','none',...
                'Color',color(i,:),...
                'Marker',marker{k},...
                'MarkerSize',10,...
                'DisplayName',['Split Nodes of Crack ',num2str(k)]);
        end
        % ������Ӽ�ǿ�ڵ�
        if ~isempty(junction_nodes)
            % ������Ҫ���Ӻ�����ǿ
            sum_plot_junction_crack = sum_plot_junction_crack+1;
            h.junction_handle(sum_plot_junction_crack) = ...
                plot(node(junction_nodes,1),node(junction_nodes,2),...
                'LineStyle','none',...
                'Color',color(i,:),...
                'Marker',marker{k},...
                'MarkerSize',15,...
                'DisplayName',['Junction Nodes of Crack ',num2str(k)]);
        end
        % ��ǻ�ϵ�Ԫ�Ľ��
        if ~isempty(blend_nodes)
            sum_plot_blend = sum_plot_blend+1;
            h.blend_handle(sum_plot_blend) = ...
                plot(node(blend_nodes,1),node(blend_nodes,2),...
                'LineStyle','none',...
                'Color',color(i,:),...
                'Marker','*',...
                'MarkerSize',8,...
                'DisplayName',['Blend Nodes of Crack ',num2str(k)]);
        end
    end
end
%% ��ע��Ԫ���
if NEW&&plot_elem_num || plot_vari_elem&&plot_elem_num
    Average_of_X_of_Elem = mean(X); % ÿ����Ԫ��x�����ƽ��ֵ
    Average_of_Y_of_Elem = mean(Y);
    Elem_Count = (1:length(element))';
    if ~isempty(type_elem)
        ind = sum(type_elem,2)~=0;  % ��Ԫ���Ͳ���0������
    else
        ind = true(size(Elem_Count));
    end
    text(Average_of_X_of_Elem(ind),Average_of_Y_of_Elem(ind),num2str(Elem_Count(ind)),'Color','r');
end
%% ��ע�ڵ���
if NEW&&plot_node_num || plot_vari_elem&&plot_node_num
    Node_Count = (1:length(node))';
    if ~isempty(type_elem)
        ind = sum(type_elem,2)~=0;  % ��Ԫ���Ͳ���0������
        ind = unique(element(ind,:));  % ����һ�е�Ԫ��صĽ����
    else
        ind = true(size(Node_Count));
    end
    text(Xtemp(ind),Ytemp(ind),num2str(Node_Count(ind)),'Color','b');
end
%% ����J��������
if ~isempty(plot_J_radius)
    Jdomain = plot_J_radius{1}; % �����û������ڵĵ�Ԫ
    qnode = plot_J_radius{2};   % �����û������ڵĵ�Ԫ�Ľ��Ȩϵ��
    node_num_Jdomain = ElemSctr(Jdomain,:); % �����û������ڵĵ�Ԫ�ϵĽ���ţ���Ч�����0���
    node_num_q_eq_1 = node_num_Jdomain(qnode==1);  % �����û������ڵĵ�Ԫ�ϵĽ��Ȩϵ��=1�Ľ���ţ�������
    node_num_q_eq_0 = node_num_Jdomain(qnode==0);
    if ~NEW && isfield(h,'J_handle')
        delete(h.J_handle);
    end
    h.J_handle(1) = plot(node(node_num_q_eq_1,1),node(node_num_q_eq_1,2),...
        'Marker','*',...
        'Color',[128/255,0,1],...
        'MarkerSize',8,...
        'LineStyle','none',...
        'DisplayName','q = 1');
    h.J_handle(2) = plot(node(node_num_q_eq_0,1),node(node_num_q_eq_0,2),...
        'Marker','o',...
        'Color',[128/255,0,1],...
        'MarkerSize',8,...
        'LineStyle','none',...
        'DisplayName','q = 0');
end
%% ����delaunay������
if ~isempty(plot_delaunay)
    if ~isempty(plot_delaunay{1})
        if ~NEW && isfield(h,'delaunay')
            delete(h.delaunay);
        end
        tri = plot_delaunay{1};
        tri_node = plot_delaunay{2};
        h.delaunay = triplot(tri,tri_node(:,1),tri_node(:,2),'b--','DisplayName','delaunay triangle');
    end
end
%% ���Ƹ�˹���ֵ�
if ~isempty(plot_gausspt)
    if ~NEW && isfield(h,'gausspt')
        delete(h.gausspt);
    end
    h.gausspt = plot(plot_gausspt(:,1),plot_gausspt(:,2),...
        'LineStyle','none',...
        'Color','blue',...
        'Marker','.',...
        'DisplayName','integration pts');
end
%% ����ͼ��
if plot_legend
    ref_field = {'mesh','vari_elem','crack_handle','tip_handle','split_handle',...
        'junction_handle','blend_handle','J_handle','delaunay','gausspt',...
        'heaviside','boundarynodes'};
    present_field = fieldnames(h);
    needed = intersect(present_field,ref_field,'stable');   % ��Ҫ����ͼ���ľ��
    L = length(needed);
    hand = [];
    for k = 1:L
        field_value = getfield(h,needed{k});
        % �޳��Ѿ�ɾ���ľ������Щ���������ͼ����ʾ����
        flag = isvalid(field_value);
        field_value = field_value(flag);
        if strcmp(needed{k},'heaviside')   % J����ͼ��ֻ��Ҫ1������
            field_value = field_value(1);
        end
        hand = [hand,field_value];
    end
    legend(hand);
end
axis image
axis off
%% ����ͼ��
if isa(save_pic,'cell')
    if NEW
        set(h.fig_handle,'Position',get(0,'ScreenSize'));
    end
    cell_length = length(save_pic);
    switch cell_length
        case 3
            print(h.fig_handle,[save_pic{1},save_pic{2}],save_pic{3},'-r300');
        case 5  % �����ض�ʱ�䲽
            if ismember(save_pic{3},save_pic{4})
                print(h.fig_handle,[save_pic{1},save_pic{2},'_',num2str(save_pic{3})],save_pic{5},'-r300');
                frame = getframe;
                im = frame2im(frame);
                [A,map] = rgb2ind(im,256);
                if NEW
                    imwrite(A,map,[save_pic{1},'animate.gif'],'gif','LoopCount',Inf,'DelayTime',0.5);
                else
                    imwrite(A,map,[save_pic{1},'animate.gif'],'gif','WriteMode','append','DelayTime',0.5);
                end
            end
    end
end
hold off
end
%}