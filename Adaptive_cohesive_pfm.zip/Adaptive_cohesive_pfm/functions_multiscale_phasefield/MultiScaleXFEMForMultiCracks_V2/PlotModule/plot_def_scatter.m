function hobj = plot_def_scatter(hobj,fac,u_x,u_y)
global node ElemSctr num_not_nan element

if isempty(ElemSctr) && isempty(num_not_nan)
    ElemSctr = element;
    num_not_nan = sum(~isnan(ElemSctr),2);
end

if isempty(hobj)
    h = figure;
    hobj = h;
else
    if isa(hobj,'matlab.ui.Figure')
        h = figure(hobj);
        p = gca;
        delete(p)
    elseif isa(hobj,'matlab.graphics.axis.Axes')
        p = findobj(hobj,'Type','patch');
        if ~isempty(p)
            delete(p);
        end
        axes(hobj)
        h = hobj.Parent;
    end
end
%% �����µĽ������
New_Node = node+fac*[u_x(:),u_y(:)];
Xtemp = New_Node(:,1);
Ytemp = New_Node(:,2);

scatter(Xtemp,Ytemp);
