function hobj2 = show_typeelem(hobj,element,node,type_elem,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'element',@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));
addRequired(p,'type_elem',@(x) validateattributes(x,{'numeric'},{'2d','integer'}));

defaultsubindex = true(size(type_elem,2),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultcolorType_1 = 'c';
addParameter(p,'colorType_1',defaultcolorType_1,@(x) isnumeric(x)||ischar(x));
defaultcolorType_11 = [153,0,255]./255;
addParameter(p,'colorType_11',defaultcolorType_11,@(x) isnumeric(x)||ischar(x));
defaultcolorType_12 = 'b';
addParameter(p,'colorType_12',defaultcolorType_12,@(x) isnumeric(x)||ischar(x));
defaultcolorType_2 = 'g';
addParameter(p,'colorType_2',defaultcolorType_2,@(x) isnumeric(x)||ischar(x));
defaultcolorType_20 = 'y';
addParameter(p,'colorType_20',defaultcolorType_20,@(x) isnumeric(x)||ischar(x));
defaultcolorType_5 = [255,0,102]./255;
addParameter(p,'colorType_5',defaultcolorType_5,@(x) isnumeric(x)||ischar(x));

defaultFaceAlpha = 0.5;
addParameter(p,'FaceAlpha',defaultFaceAlpha,@(x) validateattributes(x,{'numeric'},{'scalar','>=',0,'<=',1}));

parse(p,hobj,element,node,type_elem,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',size(ip.type_elem,2),'vector'})
else
    ip.subindex = unique(ip.subindex);
end

% extract crack by subindex
selectedTypeElem = ip.type_elem(:,ip.subindex);
[elemType_1,~] = find(selectedTypeElem==1);
[elemType_11,~] = find(selectedTypeElem==11);
[elemType_12,~] = find(selectedTypeElem==12);
[elemType_2,~] = find(selectedTypeElem==2);
[elemType_20,~] = find(selectedTypeElem==20);
[elemType_5,~] = find(selectedTypeElem==5);

%% plot
brush_element(ip.hobj,element,node,elemType_1,...
    'FaceColor',ip.colorType_1,...
    'FaceAlpha',ip.FaceAlpha,...
    'DisplayName','type\_elem = 1')
brush_element(ip.hobj,element,node,elemType_11,...
    'FaceColor',ip.colorType_11,...
    'DisplayName','type\_elem = 11')
brush_element(ip.hobj,element,node,elemType_12,...
    'FaceColor',ip.colorType_12,...
    'FaceAlpha',ip.FaceAlpha,...
    'DisplayName','type\_elem = 12')
brush_element(ip.hobj,element,node,elemType_2,...
    'FaceColor',ip.colorType_2,...
    'FaceAlpha',ip.FaceAlpha,...
    'DisplayName','type\_elem = 2')
brush_element(ip.hobj,element,node,elemType_20,...
    'FaceColor',ip.colorType_20,...
    'FaceAlpha',ip.FaceAlpha,...
    'DisplayName','type\_elem = 20')
brush_element(ip.hobj,element,node,elemType_5,...
    'FaceColor',ip.colorType_5,...
    'FaceAlpha',ip.FaceAlpha,...
    'DisplayName','type\_elem = 5')

legend 

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end