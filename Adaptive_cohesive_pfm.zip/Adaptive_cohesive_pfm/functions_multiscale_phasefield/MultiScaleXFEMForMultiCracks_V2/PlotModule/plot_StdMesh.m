function hobj2 = plot_StdMesh(hobj,element,node,varargin)
%plot_StdMesh ���Ƴ�������
%   plot_StdMesh(hobj,element,node) ������ element, node �������������,
%   hobj ָ����ͼ��ͼ�ξ��, �վ�����ڵ�ǰͼ���ϻ���
%
%   plot_StdMesh(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       FaceColor, EdgeColor, LineStyle, LineWidth, AxisStyle, TextNodeNum, 
%       NodeNumColor, ElemNumColor, TextArea ������ type_elem ���������
%
%   hobj = plot_StdMesh(...) ����ͼ�ξ��
%
%   See also brush_element, brush_node, text_element, text_node, 
%   plot_VNMesh. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'element',@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultFaceColor = 'w';
addParameter(p,'FaceColor',defaultFaceColor,@(x) isnumeric(x)||ischar(x));
defaultEdgeColor = 'k';
addParameter(p,'EdgeColor',defaultEdgeColor,@(x) isnumeric(x)||ischar(x));
defaultLineStyle = '-';
addParameter(p,'LineStyle',defaultLineStyle,@(x) ischar(x));
defaultLineWidth = 1.2;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));

defaultAxisStyle = 'equal';
addParameter(p,'AxisStyle',defaultAxisStyle,@(x) ischar(x));

defaultTextNodeNum = false;
addParameter(p,'TextNodeNum',defaultTextNodeNum,@(x) isnumeric(x)&&isscalar(x)||islogical(x));
defaultNodeNumColor = 'b';
addParameter(p,'NodeNumColor',defaultNodeNumColor,@(x) isnumeric(x)||ischar(x));
defaultTextElemNum = false;
addParameter(p,'TextElemNum',defaultTextElemNum,@(x) isnumeric(x)&&isscalar(x)||islogical(x));
defaultElemNumColor = 'r';
addParameter(p,'ElemNumColor',defaultElemNumColor,@(x) isnumeric(x)||ischar(x));
defaultTextArea = [];
addParameter(p,'TextArea',defaultTextArea,@(x) validateattributes(x,{'numeric'},{'2d'}));

parse(p,hobj,element,node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;

%% data process
X = ip.node(:,1);
Y = ip.node(:,2);

%% patch plot
patch('XData',X(ip.element)','YData',Y(ip.element)','FaceColor',ip.FaceColor,...
                                                    'EdgeColor',ip.EdgeColor,...
                                                    'LineStyle',ip.LineStyle,...
                                                    'LineWidth',ip.LineWidth,...
                                                    'DisplayName','4-node element',...
                                                    'UserData',0);
ax = gca;                                                
axis(ax,ip.AxisStyle);
axis off;
hold on;

%% Text number
if ip.TextNodeNum
    if ~isempty(ip.TextArea)
        % ip.TextArea = type_elem
        indElem = sum(ip.TextArea,2)~=0;    % ��Ԫ���Ͳ���0���߼�����
        text_node(ip.hobj,node,'subindex',indElem,'subtype',element,...
            'Color',ip.NodeNumColor)
    else
        text_node(ip.hobj,node,...
            'Color',ip.NodeNumColor)
    end
end

if ip.TextElemNum
    if ~isempty(ip.TextArea)
        indElem = sum(ip.TextArea,2)~=0;    % ��Ԫ���Ͳ���0���߼�����
        text_element(ip.hobj,ip.element,ip.node,'subindex',indElem,...
            'Color',ip.ElemNumColor)
    else
        text_element(ip.hobj,ip.element,ip.node,...
            'Color',ip.ElemNumColor)
    end
end

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end