function hobj2 = text_element(hobj,element,node,varargin)
%text_element ��ʾָ����Ԫ�ı��
%   text_element(hobj,element,node) ��ʾ element, node ��������е�Ԫ�ı��
%
%   text_element(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       subindex ��Ԫ��Ż��߼�����, Color
%
%   hobj = text_element(...) ����ͼ�ξ��
%
%   See also brush_node, brush_element, text_node, plot_VNMesh,
%   plot_StdMesh. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'element',@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultsubindex = true(size(element,1),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));
defaultColor = 'r';
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,element,node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',size(ip.element,1),'vector'})
else
    ip.subindex = unique(ip.subindex);
end
X = ip.node(:,1);
Y = ip.node(:,2);
elemnum = size(ip.element,1);
ElemCount = (1:elemnum)';
if numel(ip.subindex) == 1
    AveXElem = mean(X(ip.element(ip.subindex,:)));
    AveYElem = mean(Y(ip.element(ip.subindex,:)));
else
    AveXElem = mean(X(ip.element(ip.subindex,:)),2);
    AveYElem = mean(Y(ip.element(ip.subindex,:)),2);
end

%% text
text(AveXElem,AveYElem,num2str(ElemCount(ip.subindex)),...
    'HorizontalAlignment','center',...
    'Color',ip.Color,...
    'UserData',11);

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end






















