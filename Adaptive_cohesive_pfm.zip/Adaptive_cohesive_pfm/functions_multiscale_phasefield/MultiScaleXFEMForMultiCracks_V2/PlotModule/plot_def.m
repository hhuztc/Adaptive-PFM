function hobj2 = plot_def(hobj,node,ElemSctr,ValidNodeNum,Displacement,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));
addRequired(p,'ElemSctr',@(x) validateattributes(x,{'numeric'},{'2d','integer'}));
addRequired(p,'ValidNodeNum',@(x) validateattributes(x,{'numeric'},{'column'}));
addRequired(p,'Displacement',@(x) validateattributes(x,{'numeric'},{'ncols',2}));

defaultFactor = 0.01;
addParameter(p,'Factor',defaultFactor,@(x) validateattributes(x,{'numeric'},{'positive','scalar'}));

defaultFaceColor = 'w';
defaultEdgeColor = 'k';
defaultLineStyle = '-';
defaultLineWidth = 1.2;
addParameter(p,'FaceColor',defaultFaceColor,@(x) isnumeric(x)||ischar(x));
addParameter(p,'EdgeColor',defaultEdgeColor,@(x) isnumeric(x)||ischar(x));
addParameter(p,'LineStyle',defaultLineStyle,@(x) ischar(x));
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));

parse(p,hobj,node,ElemSctr,ValidNodeNum,Displacement,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if ip.Factor==0.01
    % �Զ�����λ�ƷŴ���
    dispMax = max(ip.Displacement(:));
    dispMin = min(ip.Displacement(:));
    globMax = max(abs([dispMax,dispMin]));
    exp = abs(fix(log10(globMax)))-0.5;
    ip.Factor = 10^exp;
end

newNode = ip.node+ip.Factor*ip.Displacement;
X = newNode(:,1);
Y = newNode(:,2);

validNodeType = unique(ip.ValidNodeNum);    % ��Ч�������
sumValidNodeType = numel(validNodeType);
xConnec = cell(1,sumValidNodeType);
yConnec = xConnec;
for i = 1:sumValidNodeType
    ind = ip.ValidNodeNum==validNodeType(i);
    connec = ip.ElemSctr(ind,1:validNodeType(i));
    xConnec{i} = X(connec);
    yConnec{i} = Y(connec);
end

%% plot
for i = 1:sumValidNodeType
    patch('XData',xConnec{i}','YData',yConnec{i}',...
        'FaceColor',ip.FaceColor,...
        'EdgeColor',ip.EdgeColor,...
        'LineStyle',ip.LineStyle,...
        'LineWidth',ip.LineWidth);
end

axis equal

title(['Numerical deformed configuration (factor = ',num2str(ip.Factor),')'])

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end