function hobj2 = brush_element(hobj,element,node,varargin)
%brush_element ˢ��ָ����Ԫ
%   brush_element(hobj,element,node) ˢ�� element, node �������������, hobj
%   ָ����ͼ��ͼ�ξ��, �վ�����ڵ�ǰͼ���ϻ���
%
%   brush_element(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       subindex ��Ԫ��Ż��߼�����, FaceColor EdgeColor LineStyle FaceAlpha
%       DisplayName
%
%   hobj = brush_element(...) ����ͼ�ξ��
%
%   See also brush_node, text_element, text_node, plot_VNMesh,
%   plot_StdMesh. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'element',@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultsubindex = true(size(element,1),1);
addOptional(p,'subindex',defaultsubindex,@(x) isnumeric(x) || islogical(x));

defaultFaceColor = [68,114,196]./255;
addParameter(p,'FaceColor',defaultFaceColor,@(x) isnumeric(x)||ischar(x));
defaultEdgeColor = 'none';
addParameter(p,'EdgeColor',defaultEdgeColor,@(x) isnumeric(x)||ischar(x));
defaultLineStyle = '-';
addParameter(p,'LineStyle',defaultLineStyle,@(x) ischar(x));
defaultLineWidth = 1.2;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultFaceAlpha = 0.5;
addParameter(p,'FaceAlpha',defaultFaceAlpha,@(x) validateattributes(x,{'numeric'},{'scalar','>=',0,'<=',1}));

defaultDisplayName = 'highlighted elements';
addParameter(p,'DisplayName',defaultDisplayName,@(x) ischar(x)||isstring(x));

parse(p,hobj,element,node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if islogical(ip.subindex)
    validateattributes(ip.subindex,{'logical'},{'numel',size(ip.element,1),'vector'})
else
    ip.subindex = unique(ip.subindex);
end
xnode = ip.node(:,1);
ynode = ip.node(:,2);

%% plot
patch('XData',xnode(ip.element(ip.subindex,:))','YData',ynode(ip.element(ip.subindex,:))',...
      'FaceColor',ip.FaceColor,...
      'EdgeColor',ip.EdgeColor,...
      'LineStyle',ip.LineStyle,...
      'LineWidth',ip.LineWidth,...
      'FaceAlpha',ip.FaceAlpha,...
      'DisplayName',ip.DisplayName,...
      'UserData',3);

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end

















