function hobj2 = plot_crack(hobj,xCr,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'xCr',@(x) isempty(x) || isstruct(x)&&isfield(x,'coor'));

defaultColor = 'MATLABauto';
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x)||iscell(x)&&numel(x)>=numel(xCr));
defaultLineWidth = 1.2;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));

defaultMarker = 'o';
addParameter(p,'Marker',defaultMarker,@(x) ischar(x));
defaultMarkerSize = 8;
addParameter(p,'MarkerSize',defaultMarkerSize,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultMarkerEdgeColor = defaultColor;
addParameter(p,'MarkerEdgeColor',defaultMarkerEdgeColor,@(x) isnumeric(x)||ischar(x)||iscell(x)&&numel(x)>=numel(xCr));
defaultMarkerFaceColor = 'c';
addParameter(p,'MarkerFaceColor',defaultMarkerFaceColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,xCr,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
cracknum = numel(ip.xCr);

if iscell(ip.Color)
    ip.MarkerEdgeColor = ip.Color;
elseif iscell(ip.MarkerEdgeColor)
    ip.Color = ip.MarkerEdgeColor;
end

%% plot
h_crack = gobjects(1,cracknum);     % ��ʼ��ͼ�ξ��
for i = 1:cracknum
    h_crack(i) = plot(ip.xCr(i).coor(:,1),ip.xCr(i).coor(:,2),...
                      'LineWidth',ip.LineWidth,...
                      'Marker',ip.Marker,...
                      'MarkerSize',ip.MarkerSize,...
                      'MarkerFaceColor',ip.MarkerFaceColor,...
                      'DisplayName',['Crack No.',num2str(i)],...
                      'UserData',1);
end
if iscell(ip.Color)&&numel(ip.Color)>=cracknum
    for i = 1:cracknum
        h_crack(i).Color = ip.Color{i};
%         h_crack(i).MarkerEdgeColor = ip.MarkerEdgeColor{i};
    end
elseif ~strcmpi(ip.Color,'MATLABauto')
    set(h_crack,'Color',ip.Color);
%     set(h_crack,'MarkerEdgeColor',ip.MarkerEdgeColor);
end

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end