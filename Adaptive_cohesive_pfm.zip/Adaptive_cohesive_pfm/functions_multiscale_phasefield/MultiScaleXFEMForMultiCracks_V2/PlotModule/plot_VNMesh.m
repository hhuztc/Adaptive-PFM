function hobj2 = plot_VNMesh(hobj,element,node,vari_ele_node,varargin)
%plot_VNMesh ���Ʊ��㵥Ԫ
%   plot_VNMesh(hobj,element,node,vari_ele_node) �� element, node ���������
%   ������, ˢ���� vari_ele_node ����ı��㵥Ԫ, hobj ָ����ͼ��ͼ�ξ��, ��
%   ������ڵ�ǰͼ���ϻ���
%
%   plot_VNMesh(...,Name,Value) ������-ֵ�����趨ͼ�β���
%       SplitNode ������� ElemSctr �� ValidNodeNum, ���ն���ڵ����ڲ�ͬ��
%       Ԫ�߻���, FaceColor, FaceAlpha, MarkerEdgeColor, MarkerFaceColor, 
%       LineWidth, FourEdgeColor ָ����ͬ��Ԫ���ϵĶ�������ɫ, DataScale ָ
%       ������ڵ�ƫ�Ʋ��������ݳ߶�, tol ���ݳ߶ȵ�����ֵ
%
%   hobj = plot_VNMesh(...) ����ͼ�ξ��
%
%   See also brush_element, brush_node, text_element, text_node, 
%   plot_StdMesh, GetExtraNodesOnEdge. 

%   Copyright 2018.9.15 Junlei Ding

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'element',@(x) validateattributes(x,{'numeric'},{'2d','positive','integer'}));
addRequired(p,'node',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));
addRequired(p,'vari_ele_node',@(x) validateattributes(x,{'numeric'},{'2d','integer'}));

defaultSplitNode = [];
addParameter(p,'SplitNode',defaultSplitNode,@(x) validateattributes(x,{'cell'},{'numel',2}));   % ElemSctr ValidNodeNum

defaultFaceColor = [191,191,191]./255;
addParameter(p,'FaceColor',defaultFaceColor,@(x) isnumeric(x)||ischar(x));
defaultFaceAlpha = 0.5;
addParameter(p,'FaceAlpha',defaultFaceAlpha,@(x) validateattributes(x,{'numeric'},{'scalar','>=',0,'<=',1}));

defaultMarkerEdgeColor = 'MATLABauto';
addParameter(p,'MarkerEdgeColor',defaultMarkerEdgeColor,@(x) isnumeric(x)||ischar(x));
defaultMarkerFaceColor = [0,176,240]./255;
addParameter(p,'MarkerFaceColor',defaultMarkerFaceColor,@(x) isnumeric(x)||ischar(x));
defaultMarkerSize = 6;
addParameter(p,'MarkerSize',defaultMarkerSize,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultLineWidth = 0.72;
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
defaultMarker = '*';
addParameter(p,'Marker',defaultMarker,@(x) ischar(x));

% �Ľ����򣬿���ֻ����ָ����Ԫ�ߣ����3���߻��1����3�����ϵĶ����㡣
defaultFourEdgeColor = {'b','r','g','c'};
addParameter(p,'FourEdgeColor',defaultFourEdgeColor,@(x) validateattributes(x,{'cell'},{'numel',4}));
defaultDataScale = max(abs([node(:,1);node(:,2)]));
addParameter(p,'DataScale',defaultDataScale,@(x) isscalar(x));
defaulttol = 1e-3;
addParameter(p,'tol',defaulttol,@(x) validateattributes(x,{'numeric'},{'real','positive','scalar'}));

parse(p,hobj,element,node,vari_ele_node,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
if isempty(ip.vari_ele_node)
    if(~oldhold)
        hold off
    end
    if nargout > 0
        hobj2 = ip.hobj;
    end
    return
end

VariNodeElem = ip.vari_ele_node(:,1);
if ~isempty(ip.SplitNode)
    ElemSctr = ip.SplitNode{1};
    ValidNodeNum = ip.SplitNode{2};
    [Edge0{1},Edge0{2},Edge0{3},Edge0{4},IA,~] = GetExtraNodesOnEdge(ip.element,ElemSctr,ValidNodeNum,ip.vari_ele_node);
    Connec = element(VariNodeElem(IA),:);
    X = ip.node(:,1);
    Y = ip.node(:,2);
    XConnec = X(Connec);
    YConnec = Y(Connec);
    ind = [1:4,1];
    vectorStart2End = zeros(numel(VariNodeElem),2*4);                       % ǰһ�����ָ���һ����������
    vectorStart2End(:,1:2:end) = XConnec(:,ind(2:end))-XConnec(:,ind(1:end-1));
    vectorStart2End(:,2:2:end) = YConnec(:,ind(2:end))-YConnec(:,ind(1:end-1));
    vectorStart2End_norm = sqrt(vectorStart2End(:,1:2:end).^2+vectorStart2End(:,2:2:end).^2);
    unitvectorStart2End = zeros(numel(VariNodeElem),2*4);
    unitvectorStart2End(:,1:2:end) = vectorStart2End(:,1:2:end)./vectorStart2End_norm;
    unitvectorStart2End(:,2:2:end) = vectorStart2End(:,2:2:end)./vectorStart2End_norm;
    unitvectorStart2End = mat2cell(unitvectorStart2End,ones(1,numel(VariNodeElem)),2*ones(1,4));
    rotateMatrix = [cos(pi/2),sin(pi/2);-sin(pi/2),cos(pi/2)];  % ��ʱ����ת90�����
    delta_l = ip.tol*ip.DataScale;  % ƫ��λ��
    normalvector = cellfun(@(x) x*rotateMatrix*delta_l,unitvectorStart2End,'UniformOutput',false);
%     normalvector = reshape(normalvector(:),[],2*4);
    normalvector = cell2mat(normalvector);
    maxExtraNode = [size(Edge0{1},2)-1,size(Edge0{2},2)-1,size(Edge0{3},2)-1,size(Edge0{4},2)-1];
    Edge{1} = NaN(numel(VariNodeElem),2*maxExtraNode(1));
    Edge{2} = NaN(numel(VariNodeElem),2*maxExtraNode(2));
    Edge{3} = NaN(numel(VariNodeElem),2*maxExtraNode(3));
    Edge{4} = NaN(numel(VariNodeElem),2*maxExtraNode(4));
    for i = 1:4
        s = 1;
        for j = 1:maxExtraNode(i)
            ind = Edge0{i}(:,1+j)~=0;
            Edge{i}(ind,s:s+1) = [X(Edge0{i}(ind,1+j)),Y(Edge0{i}(ind,1+j))]+normalvector(ind,[2*i-1,2*i]);
            s = s+2;
        end
    end
%     NodeCoorEdge = cell2mat(reshape(mat2cell(cell2mat(Edge),ones(1,numel(VariNodeElem)),2*sum(maxExtraNode)),[],1));
else
    temp = ip.vari_ele_node(:,2:end);
    ExtraNode = temp(temp~=0);
end
    
    
%% plot
brush_element(ip.hobj,ip.element,ip.node,VariNodeElem,'FaceColor',ip.FaceColor,...
                                                      'FaceAlpha',ip.FaceAlpha,...
                                                      'DisplayName','variable-node element');

% if ~isempty(ip.SplitNode)
%     for i = 1:4
%         temp = mat2cell(Edge{i},ones(1,numel(VariNodeElem)),2*ones(1,maxExtraNode(i)));
%         coor = cell2mat(reshape(temp,[],1));
%         plot(coor(:,1),coor(:,2),...
%             'LineStyle','none',...
%             'MarkerEdgeColor',ip.FourEdgeColor{i},...
%             'MarkerFaceColor',ip.MarkerFaceColor,...
%             'LineWidth',ip.LineWidth,...
%             'MarkerSize',ip.MarkerSize,...
%             'Marker',ip.Marker,...
%             'DisplayName',['extra node on edge ',num2str(i),' of variable-node element']);
%     end
% else
%     brush_node(ip.hobj,ip.node,ExtraNode,'MarkerEdgeColor',ip.MarkerEdgeColor,...
%                                          'MarkerFaceColor',ip.MarkerFaceColor,...
%                                          'LineWidth',ip.LineWidth,...
%                                          'MarkerSize',ip.MarkerSize,...
%                                          'Marker',ip.Marker,...
%                                          'DisplayName','extra node on variable-node element');
% end
 if ~isempty(ip.SplitNode)
    for i = 1:4
        temp = mat2cell(Edge{i},ones(1,numel(VariNodeElem)),2*ones(1,maxExtraNode(i)));
        coor = cell2mat(reshape(temp,[],1));
        plot(coor(:,1),coor(:,2),...
            'LineStyle','none',...
            'MarkerEdgeColor',ip.FourEdgeColor{i},...
            'MarkerFaceColor',ip.MarkerFaceColor,...
            'LineWidth',ip.LineWidth,...
            'MarkerSize',ip.MarkerSize,...
            'Marker',ip.Marker,...
            'DisplayName',['extra node on edge ',num2str(i),' of variable-node element']);
    end
else
    brush_node(ip.hobj,ip.node,ip.MarkerEdgeColor,...
                                         'MarkerFaceColor',ip.MarkerFaceColor,...
                                         'LineWidth',ip.LineWidth,...
                                         'MarkerSize',ip.MarkerSize,...
                                         'Marker',ip.Marker,...
                                         'DisplayName','extra node on variable-node element');
end
    
%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    