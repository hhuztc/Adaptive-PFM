function hobj2 = plot_delaunay(hobj,TRI,vertexNode,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'TRI',@(x) validateattributes(x,{'numeric'},{'2d','integer','ncols',3}));
addRequired(p,'vertexNode',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultLineWidth = 0.72;
defaultColor = 'b';
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,TRI,vertexNode,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% data process
x = ip.vertexNode(:,1);
y = ip.vertexNode(:,2);

%% plot
triplot(ip.TRI,x,y,...
    'Color',ip.Color,...
    'LineWidth',ip.LineWidth,...
    'DisplayName','Delaunay triangle',...
    'UserData',3);

%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end
