function hobj = plot_field(hobj,varargin)
%plot_field post process of field plot
%Syntax
%   * fighandle_new = plot_field(fighandle_old) creats a new figure window 
%     if fighandle_old is empty, otherwise makes the figure specified by 
%     fighandle_old the current figure.
%   * ax_new = plot_field(ax_old) updates the plot in the axes specified by
%     ax_old, then return the same axes handle in ax_new.
%   * plot_field(___,Name,Value) specifies the kind of field plot
%     and the axes properties using one or more Name,Value pair arguments. 
%       * Name,Value pair arguments:
%         'XDisp'--plot displacement in x component
%               vector,u_x
%         'YDisp'--plot displacement in y component
%               vector,u_y
%         'RDisp'--plot resultant displacement
%               cell vector,{u_x,u_y}
%         'XStress'--plot stress in x component
%               three-dimensional array|two-dimensional array with one of
%               dimension equal 3, stress|[sigmax(:),sigmay(:),sigmaxy(:)]
%         'YStress'--plot stress in y component
%               three-dimensional array|two-dimensional array with one of
%               dimension equal 3, stress|[sigmax(:),sigmay(:),sigmaxy(:)]
%         'XYStress'--plot stress in xy component
%               three-dimensional array|two-dimensional array with one of
%               dimension equal 3, stress|[sigmax(:),sigmay(:),sigmaxy(:)]
%         'VonStress'--plot von Mises stress
%               three-dimensional array|two-dimensional array with one of
%               dimension equal 3, stress|[sigmax(:),sigmay(:),sigmaxy(:)]
%         'NodalAverageStress'--plot nodal average stress
%               logical scalar, false(default:element stress instead)|true
%         'Deformation'--plot field based on the deformed mesh
%               cell array, {u_x,u_y,fac}
%         'Title'--add title to the figure
%               character vector|string
%         'Colorbar'--add colorbar to the figure
%               logical scalar, false(default)|true
%         'Colormap'--set the colormap for the current figure
%               colormap name,'jet'|'parula'|��default'|...
%         'Caxis'--set colormap limits
%               vector of the form [cmin cmax]
%         'Save'--save figures in specified steps to specific path.
%               cell array, {ipas,step_required,path}
%         'Axis'--set axis limits
%               four-element vector, [xmin xmax ymin ymax]
%         'Save'--save figure to specific path.
%               cell array, {ipas,step_required,path}
%         'MakeGif'--write figure of specified steps to gif file.
%               cell array, {ipas,step_required,path}
%See also plot_m, plot_def

global node ElemSctr num_not_nan
persistent Field_min_max typenum_perstep SCTRSIZE

if isempty(hobj)
    h = figure;
    hobj = h;
else
    if isa(hobj,'matlab.ui.Figure')
        h = figure(hobj);
        p = gca;
        delete(p)
    elseif isa(hobj,'matlab.graphics.axis.Axes')
        p = findobj(hobj,'Type','patch');
        if ~isempty(p)
            delete(p);
        end
        axes(hobj)
        h = hobj.Parent;
    end
end
name_arg = string(varargin(1:2:end));
value_arg = varargin(2:2:end);
[name_arg,ia,~] = unique(name_arg); % ȥ��
value_arg = value_arg(ia);

valid_node_type = unique(num_not_nan);
typenum = numel(valid_node_type);
% һ��ͼֻ�ܻ�һ������������ͼ
ind_field = name_arg=="XDisp"|name_arg=="YDisp"|name_arg=="RDisp"|...
    name_arg=="XStress"|name_arg=="YStress"|name_arg=="XYStress"|...
    name_arg=="VonStress";
if nnz(ind_field) > 1
    error('One figure can only plot one kind of field.')
end
%% ������Σ���Ҫ�Ȼ�������
ind_deform = name_arg=="Deformation";
if any(ind_deform)
    var_temp = value_arg{ind_deform};
    u_x = var_temp{1};
    u_y = var_temp{2};
    fac = var_temp{3};
    New_Node = node+fac*[u_x(:),u_y(:)];
    X = New_Node(:,1);
    Y = New_Node(:,2);
    DispScale = fac;
    name_arg(ind_deform) = [];
    value_arg(ind_deform) = [];
else
    DispScale = 1;
    X = node(:,1);
    Y = node(:,2);
end
%% �Ƿ���Ҫ���� ���ƽ��Ӧ����ͼ
ind_NodalAverageStress = name_arg=="NodalAverageStress";
flag_NodalAverageStress = false;
if any(ind_NodalAverageStress)
    if value_arg{ind_NodalAverageStress}
        flag_NodalAverageStress = true;
    end
    name_arg(ind_NodalAverageStress) = [];
    value_arg(ind_NodalAverageStress) = [];
end
%% ��Axisָ���������
ind_Axis = name_arg=="Axis";
if any(ind_Axis)
    name_arg(ind_Axis) = [];
    name_arg = [name_arg,"Axis"];
    temp = value_arg(ind_Axis);
    value_arg(ind_Axis) = [];
    value_arg = [value_arg,temp];
end
%% ����ͼƬ
ind_Save = name_arg=="Save";
if any(ind_Save)    % ��Saveָ��������󣬱����������˳�����
    name_arg(ind_Save) = [];
    temp = value_arg(ind_Save);
    value_arg(ind_Save) = [];
    name_arg = [name_arg,"Save"];
    value_arg = [value_arg,temp];
end
%% �Ƿ���Ҫ���ƶ�ͼ
ind_MakeGif = name_arg=="MakeGif";
if any(ind_MakeGif)
    temp = value_arg{ind_MakeGif};
    ipas = temp{1};
    step_required = temp{2};
    first_step = min(step_required);
    if any(step_required==ipas)
        if ipas == first_step
            permission = 'w';
            Field_min_max = NaN(2,1);
        else
            permission = 'a';
        end
        XFileID = fopen('TempFileForFieldPlotX.bin',permission);
        YFileID = fopen('TempFileForFieldPlotY.bin',permission);
        FFileID = fopen('TempFileForFieldPlotF.bin',permission);
        typenum_perstep = [typenum_perstep;typenum];
    end
    name_arg(ind_MakeGif) = [];
    name_arg = [name_arg,"MakeGif"]; % ��MakeGif������󣬱����������˳�����
    temp = value_arg(ind_MakeGif);
    value_arg(ind_MakeGif) = [];
    value_arg = [value_arg,temp];
end
ind_Colormap = name_arg=="Colormap";
ind_Title = name_arg=="Title";
ind_Axis = name_arg=="Axis";
%% ��ͼ
XSctr{typenum} = [];
YSctr{typenum} = [];
FieldSctr{typenum} = [];
for i = 1:numel(name_arg)
    switch name_arg(i)
        case {'XDisp','YDisp','RDisp'}
            temp = value_arg{i};
            if isa(temp,'cell') % ���λ��
                u_temp = sqrt(temp{1}.^2+temp{2}.^2);
            else
                u_temp = temp;
            end
            for j = 1:typenum
                ind = num_not_nan==valid_node_type(j);
                CONNECT = ElemSctr(ind,1:valid_node_type(j));
                XSctr{j} = X(CONNECT)';
                YSctr{j} = Y(CONNECT)';
                FieldSctr{j} = u_temp(CONNECT)';
                patch(XSctr{j},YSctr{j},FieldSctr{j},'EdgeColor','interp');
            end
            axis image
            axis on
            clear u_temp CONNECT
        case {'XStress','YStress','XYStress','VonStress'}
            stress_temp = value_arg{i};
            elem_form_data = true;
            if numel(size(stress_temp)) == 2
                if flag_NodalAverageStress
                    warning('Nodal stress have already been given, the command ''NodalAverageStress'' will be ignored.')
                    flag_NodalAverageStress = false;
                end
                elem_form_data = false;
                dimension_flag = size(stress_temp)==3;
                if find(dimension_flag) == 1
                    stress_temp = stress_temp';
                end
                temp(:,:,1) = stress_temp(:,1);
                temp(:,:,2) = stress_temp(:,2);
                temp(:,:,3) = stress_temp(:,3);
                stress_temp = temp;
            end
            if flag_NodalAverageStress
                %{
                test data:
                ElemSctr = [1,2,13,5,4;
                    2,10,14,13,0;
                    4,5,8,7,0;
                    5,6,9,8,0;
                    10,3,11,14,0;
                    14,11,6,12,0;
                    13,14,12,5,0;];
                stress_temp(:,:,1) = [1,2,13,5,4;
                    2,10,14,13,NaN;
                    4,5,8,7,NaN;
                    5,6,9,8,NaN;
                    10,3,11,14,NaN;
                    14,11,6,12,NaN;
                    13,14,12,5,NaN;];
                stress_temp(:,:,2) = stress_temp(:,:,1);
                stress_temp(:,:,3) = stress_temp(:,:,1);
                %}
                [node_num,I] = sort(ElemSctr(:));   % ����ȫ�ֽ���ţ����ܺ�0������Ч���)
                ind_zero = node_num==0;
                node_num(ind_zero) = [];    % ȥ0����Ч���
                I(ind_zero) = [];
                DIFFERENCE = diff([node_num;NaN]);  % ȥ��
                unique_ind = DIFFERENCE~=0;  % ȥ�ؽ���߼�����
                sub = find(unique_ind); % ȥ�ؽ���±�
                count_unique_node = diff(find([1;unique_ind])); % ͳ�Ƹ�������ظ��Ĵ���
                unique_count_type = unique(count_unique_node);
                max_count = max(unique_count_type);
                
                Sx_temp = stress_temp(:,:,1);
                Sy_temp = stress_temp(:,:,2);
                Sxy_temp = stress_temp(:,:,3);
                Sx_temp = Sx_temp(:);
                Sy_temp = Sy_temp(:);
                Sxy_temp = Sxy_temp(:);
                Sx = Sx_temp(I);
                Sy = Sy_temp(I);
                Sxy = Sxy_temp(I);
                S = zeros(numel(count_unique_node),max_count,3);    % �洢����ϵ�Ӧ��ֵ
                for k = 1:numel(unique_count_type)
                    ind = count_unique_node==unique_count_type(k);  % ����ظ�����Ϊunique_count_type(k)�Ľ���߼�������ֻ��ӳunique�������
                    temp = reshape(sub(ind),[],1);
                    temp2 = -(0:unique_count_type(k)-1);
                    ha = temp+temp2;    % �õ��ظ��ڵ�������������൱������ind
                    Sx_temp = Sx(ha);
                    Sy_temp = Sy(ha);
                    Sxy_temp = Sxy(ha);
                    S(ind,1:unique_count_type(k),1) = Sx_temp;
                    S(ind,1:unique_count_type(k),2) = Sy_temp;
                    S(ind,1:unique_count_type(k),3) = Sxy_temp;
                end
                S2 = sum(S,2);
                average_nodal_stress = S2./count_unique_node;
                
                stress_temp = average_nodal_stress;
                elem_form_data = false;
            end
            flag = ["XStress","YStress","XYStress"]==name_arg(i);
            if any(flag)    % ����ĳһ�����Ӧ��
                STRESS = stress_temp(:,:,flag);
            else
                Sx_temp = stress_temp(:,:,1);
                Sy_temp = stress_temp(:,:,2);
                Sxy_temp = stress_temp(:,:,3);
                STRESS = sqrt(Sx_temp.^2+Sy_temp.^2-Sx_temp.*Sy_temp+3*Sxy_temp.^2);
            end
            for j = 1:typenum
                ind = num_not_nan==valid_node_type(j);
                CONNECT = ElemSctr(ind,1:valid_node_type(j));
                XSctr{j} = X(CONNECT)';
                YSctr{j} = Y(CONNECT)';
                if elem_form_data
                    FieldSctr{j} = STRESS(ind,1:valid_node_type(j))';
                else
                    FieldSctr{j} = STRESS(CONNECT)';
                end
                patch(XSctr{j},YSctr{j},FieldSctr{j},'EdgeColor','interp');
            end
            axis image
            axis on
            clear stress_temp Sx_temp Sy_temp Sxy_temp Sx Sy Sxy STRESS CONNECT average_nodal_stress
        case 'Save'
            temp = value_arg{i};
            ipas = temp{1};
            step_required = temp{2};
            filepath = temp{3};
            if any(step_required==ipas)
                h.Position = get(0,'ScreenSize');
                print(h,[filepath,'FieldPicStep_',num2str(ipas)],'-dpng','-r0');
            end
            clear ipas step_required filepath
        case 'MakeGif'
            temp = value_arg{i};
            ipas = temp{1};
            step_required = temp{2};
            filepath = temp{3};
            last_step = max(step_required);
            SIZE = zeros(typenum,2);
            for j = 1:typenum
                fwrite(XFileID,XSctr{j},'double');
                fwrite(YFileID,YSctr{j},'double');
                fwrite(FFileID,FieldSctr{j},'double');
                Field_min_max = [min([Field_min_max(1);reshape(FieldSctr{j},[],1)]);...
                                 max([Field_min_max(2);reshape(FieldSctr{j},[],1)])];
                SIZE(j,:) = size(XSctr{j});
            end
            SCTRSIZE = [SCTRSIZE;SIZE];
            fclose(XFileID);
            fclose(YFileID);
            fclose(FFileID);
            
            k = 1;
            if ipas == last_step
                h2 = figure;
                hold on
                XFileID = fopen('TempFileForFieldPlotX.bin','r');
                YFileID = fopen('TempFileForFieldPlotY.bin','r');
                FFileID = fopen('TempFileForFieldPlotF.bin','r');
                h2.Position = get(0,'ScreenSize');
                for m = 1:numel(step_required)
                    if m ~= 1
                        p = gca;
                        delete(p);
                    end
                    typenem_current = typenum_perstep(m);
                    for n = 1:typenem_current
                        XSctr = fread(XFileID,SCTRSIZE(k,:),'double');
                        YSctr = fread(YFileID,SCTRSIZE(k,:),'double');
                        FieldSctr = fread(FFileID,SCTRSIZE(k,:),'double');
                        if any(isnan(XSctr(:)))||any(isnan(YSctr(:)))||any(isnan(FieldSctr(:)))
                            error('NaN found.')
                        end
                        figure(h2);
                        patch(XSctr,YSctr,FieldSctr,'EdgeColor','interp')
                        k = k+1;
                    end
                    colorbar
%                     caxis(Field_min_max')
                    if nnz(ind_Title) == 1
                        title([value_arg{ind_Title},'DispScale = ',num2str(DispScale)])
                    end
                    if nnz(ind_Colormap)
                        colormap(value_arg{ind_Colormap});
                    else
                        colormap;
                    end
                    axis image
                    axis on
                    if nnz(ind_Axis)
                        axis(value_arg{ind_Axis});
                    end
                    drawnow
                    pause(5)
                    frame = getframe(h2);
                    im = frame2im(frame);
                    [A,map] = rgb2ind(im,256);
                    if m == 1
                        imwrite(A,map,[filepath,'FieldAnimate.gif'],'gif','LoopCount',Inf,'DelayTime',0.5);
                    else
                        imwrite(A,map,[filepath,'FieldAnimate.gif'],'gif','WriteMode','append','DelayTime',0.5);
                    end
                end
                
                fclose(XFileID);
                fclose(YFileID);
                fclose(FFileID);
                delete TempFileForFieldPlotX.bin TempFileForFieldPlotY.bin TempFileForFieldPlotF.bin
                close(h2);
                clear SCTRSIZE typenum_perstep
            end
            clear ipas step_required filepath
        case 'Caxis'
            temp = value_arg{i};
            caxis([min(temp),max(temp)])
        case 'Colorbar'
            temp = value_arg{i};
            if temp
                colorbar
            end
        case 'Colormap'
            temp = value_arg{i};
            colormap(temp)
        case 'Title'
            temp = value_arg{i};
            title([temp,'(DispScale = ',num2str(DispScale),')'])
        case 'Axis'
            temp = value_arg{i};
            axis(temp);
        otherwise
            error(['Unexpected input argument: ',name_arg{i}]);
    end
    clear temp
end
