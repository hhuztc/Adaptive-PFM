function hobj = plot_def(hobj,fac,u_x,u_y,varargin)
%plot_def post process of deformation plot
% Syntax
%   * fighandle_new = plot_def(fighandle_old,fac,u_x,u_y) creats the plot 
%     of deformation.
%       * If fighandle_old is empty, the program will make a new figure. If
%         fighandle_old is not empty, then updates the image in the old 
%         figure. The function return the figure handle in fighandle_new.
%       * u_x, u_y are nodal displacement in x and y direction,
%         respectively.
%   * ax_new = plot_def(ax_old,fac,u_x,u_y) updates the plot in the axes 
%     specified by ax_old, then return the same axes handle in ax_new.
%   * plot_def(___,fac,u_x,u_y,Name,Value) specifies extra commands to the 
%     figure by using one or more Name,Value pair arguments.
%       * Name-Value Pair Arguments:
%         'Save' -- save figure to specific path.
%                cell array, {ipas,step_required,path}
%         'MakeGif' -- write figure of specified steps to gif file.
%                cell array, {ipas,step_required,path}
%         'Axis' -- set axis limits
%                four-element vector,[xmin xmax ymin ymax]
%See also plot_m, plot_field

global node ElemSctr num_not_nan element
if isempty(ElemSctr) && isempty(num_not_nan)
    ElemSctr = element;
    num_not_nan = sum(~isnan(ElemSctr),2);
end

if isempty(hobj)
    h = figure;
    hobj = h;
else
    if isa(hobj,'matlab.ui.Figure')
        h = figure(hobj);
        p = gca;
        delete(p)
    elseif isa(hobj,'matlab.graphics.axis.Axes')
        p = findobj(hobj,'Type','patch');
        if ~isempty(p)
            delete(p);
        end
        axes(hobj)
        h = hobj.Parent;
    end
end

%% �����µĽ������
New_Node = node+fac*[u_x(:),u_y(:)];
Xtemp = New_Node(:,1);
Ytemp = New_Node(:,2);
%% ����Ԫ�����Ŀ���࣬Ϊpatch��׼��
unique_num_not_nan = unique(num_not_nan);
num_sctr_type = numel(unique_num_not_nan);  % �ṹ�ĵ�Ԫ����������࣬�м��಻ͬ�ڵ����ĵ�Ԫ
% Ԥ�����ڴ�
elem_sctr{num_sctr_type} = [];
X_vari{num_sctr_type} = [];
Y_vari{num_sctr_type} = [];

for i = 1:num_sctr_type
    ind = num_not_nan==unique_num_not_nan(i);
    elem_sctr{i} = ElemSctr(ind,1:unique_num_not_nan(i));
    X_vari{i} = Xtemp(elem_sctr{i})';
    Y_vari{i} = Ytemp(elem_sctr{i})';
end
%% ��ͼ
for i = 1:num_sctr_type
    patch(X_vari{i},Y_vari{i},[0.8 0.8 0.8],'DisplayName','Deformed mesh');
end
title(['Numerical deformed configuration(factor = ',num2str(fac),')'])
axis image
axis on
varnum = numel(varargin);
for i = 1:2:varnum
    var_value = varargin{i+1};
    switch varargin{i}
        case 'Save'
            ipas = var_value{1};
            step_required = var_value{2};
            filepath = var_value{3};
            if any(step_required==ipas)
                h.Position = get(0,'ScreenSize');
                print(h,[filepath,'DefPicStep_',num2str(ipas)],'-dpng','-r0');
            end
        case 'MakeGif'
            ipas = var_value{1};
            step_required = var_value{2};
            first_step = min(step_required);
            filepath = var_value{3};
            if any(step_required==ipas)
                h.Position = get(0,'ScreenSize');
                frame = getframe(h);
                im = frame2im(frame);
                [A,map] = rgb2ind(im,256);
                if ipas == first_step
                    imwrite(A,map,[filepath,'DefAnimate.gif'],'gif','LoopCount',Inf,'DelayTime',0.5);
                else
                    imwrite(A,map,[filepath,'DefAnimate.gif'],'gif','WriteMode','append','DelayTime',0.5);
                end
            end
        case 'Axis'
            limits = var_value;
            axis(limits);
        otherwise
            error(['Unexpected input argument:',varargin{i}]);
    end
end
