function hobj2 = plot_pts(hobj,ptsCoor,varargin)

%% Input Parsing
p = inputParser;
addRequired(p,'hobj',@(x) isempty(x)||isa(x,'matlab.ui.Figure')||ishandle(x));
addRequired(p,'ptsCoor',@(x) validateattributes(x,{'numeric'},{'2d','ncols',2}));

defaultLineWidth = 0.72;
defaultColor = 'r';
defaultMarkerSize = 8;
defaultMarker = '.';
defaultMarkerFaceColor = 'none';
addParameter(p,'LineWidth',defaultLineWidth,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
addParameter(p,'Color',defaultColor,@(x) isnumeric(x)||ischar(x));
addParameter(p,'MarkerSize',defaultMarkerSize,@(x) validateattributes(x,{'numeric'},{'scalar','positive'}));
addParameter(p,'Marker',defaultMarker,@(x) ischar(x));
addParameter(p,'MarkerFaceColor',defaultMarkerFaceColor,@(x) isnumeric(x)||ischar(x));

parse(p,hobj,ptsCoor,varargin{:});
ip = p.Results;

%% generate figure and axes
if isempty(ip.hobj)
    ip.hobj = gca;
elseif isa(ip.hobj,'matlab.ui.Figure')
    figure(ip.hobj);
elseif ishandle(ip.hobj)
    axes(ip.hobj);
end

oldhold = ishold;
hold on

%% plot
plot(ip.ptsCoor(:,1),ip.ptsCoor(:,2),...
    'Color',ip.Color,...
    'LineStyle','none',...
    'Marker',ip.Marker,...
    'MarkerFaceColor',ip.MarkerFaceColor,...
    'MarkerSize',ip.MarkerSize,...
    'LineWidth',ip.LineWidth,...
    'DisplayName','integration point',...
    'UserData',3);
                                                           
%% Finish
% Return to old hold state
if(~oldhold)
    hold off
end
if nargout > 0
    hobj2 = ip.hobj;
end