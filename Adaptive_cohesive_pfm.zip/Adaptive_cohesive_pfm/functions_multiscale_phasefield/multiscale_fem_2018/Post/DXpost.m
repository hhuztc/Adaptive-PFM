clear all
% 
% [fname,pname]=uigetfile('input\*.txt',...    % gets name of input file
%     'Choose input file');
% 
% fmid=fopen([pname fname],'rt'); 

fmid = fopen(C:\Documents and Settings\David\Bureau\Stage\XFEM-propagation\essai_plot_complet.txt,'rt');

% xaxis = input('Column Number on the abscissa   : ','s');
% xaxis=str2num(xaxis);
% yaxis = input('Column Number(s) on the abscissa  (ex: [1,3,8]) : ','s');
% yaxis=str2num(yaxis);
% 
% nres=size(yaxis,2);


% ----------------------------%
% ----    reading     --------%

tline = fgets(fmid);
n=0;
while isempty(strfind(tline,'*ENDFILE')),
     tline = fgets(fmid);
     
     if strfind(tline,'*type');
          tline=tline(7:length(tline));
          type=sscanf(tline,'%s');
     end
     
     if strfind(tline,'*data')
         ttline = fgets(fmid);
         while isempty(strfind(tline,'****')),
                tline = fgets(fmid);
                if strfind(tline,'*begin')
                    tline = fgets(fmid);
                    title=textread(tline,'%s %s %s' )
                    tline = fgets(fmid);
                    n=n+1;
                    m=1;
                    while isempty(strfind(tline,'**')),   
                        temp_data = sscanf(tline, '%f %f %f %f %f %f %f %f ');
                        data(m,n,:)=temp_data';
                        tline = fgets(fmid);
                        m=m+1;
                    end
                end                        
          end   
     end     
end


% ----------------------------%
% ----    ploting     --------%

% style={'-x','-.o',':+','--*','-p','-.h'};
% switch type
%     case{'simple'}
%         disp('type = simple')
%         figure(1)
%         hold on
%         for ics=1:nres
%             plot(data(:,1,xaxis),data(:,1,yaxis(ics)),style{ics})
%             %set(gca,'DefaultAxesLineStyleOrder',{'-*',':','o'})
%         end
%     case{'multiple'}
%         disp('type = miltiple')
%         figure(1)
%         hold on
%         for ics=1:n
%             plot(data(:,ics,xaxis),data(:,ics,yaxis))
%         end
%     otherwise
%         disp('type unknown (be careful : no space after type=)')
% end