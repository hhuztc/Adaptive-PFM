function [nd]=disTip_point(phi,tip,nodess,xCr,kk,mm)

nd=[]; 
corner  = [1 2 3 4 1];
node    = [-1 -1; 1 -1; 1 1; -1 1];

 
% loop on element edges
for i = 1:4
    n1 = corner(i);
    n2 = corner(i+1);
    if phi(n1)*phi(n2) < 0
        r    = phi(n1)/(phi(n1)-phi(n2));
        pnt  = (1-r)*node(n1,:)+r*node(n2,:); 
        [N,dNdxi]=lagrange_basis('Q4',pnt);
        Gpnt = N' * nodess; % global GP

if(mm==1)
       if(abs(xCr(kk).coor(1,1)-tip(1))+abs(xCr(kk).coor(1,2)-tip(2))<1e-8) 
           seg   = xCr(kk).coor(1,:) - xCr(kk).coor(2,:);
           seg2  = Gpnt - tip;
           if(sum(seg.*seg2)<0)
           nd = [nd;Gpnt];      
           end 
       else
           seg   = xCr(kk).coor(size(xCr(kk).coor,1),:) - xCr(kk).coor(size(xCr(kk).coor,1)-1,:);
           seg2  = Gpnt - tip;
           if(sum(seg.*seg2)<0)
           nd = [nd;Gpnt];      
           end 
       end 
else
nd = [nd;Gpnt];    
end
       
    end
end  
   
if(mm==1)
      if(abs(xCr(kk).coor(1,1)-tip(1))+abs(xCr(kk).coor(1,2)-tip(2))<1e-8)  
           nd = [tip;nd];     
       else 
           nd = [nd;tip];      
       end  
else

num=0;
for i=1:size(xCr(kk).coor,1)
 if(abs(xCr(kk).coor(i,1)-tip(1))+abs(xCr(kk).coor(i,2)-tip(2))<1e-8)  
num=i;
end
end

 seg   = xCr(kk).coor(num,:) - xCr(kk).coor(num-1,:);
           seg2  = tip-nd(1,:);
           if(sum(seg.*seg2)>0)
           nd = [ nd(1,:);tip;nd(2,:) ];    
else  
 nd = [ nd(2,:);tip;nd(1,:) ];   
           end 
end
 






