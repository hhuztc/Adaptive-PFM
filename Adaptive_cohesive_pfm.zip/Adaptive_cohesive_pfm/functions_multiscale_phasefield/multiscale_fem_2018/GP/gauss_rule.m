function [W,Q] = gauss_rule(iel,normal_order,ilab)

% Choose Gauss quadrature rules for elements 

global node element vari_ele  
 
sctr = element(iel,:);                          % element connectivity
        
          if(ismember(iel,vari_ele(:,1)))   % variable node element  
             nodes = node(sctr,:);  
             [W,Q] = quad_variable_node_ele(iel,2,nodes,ilab);  
              else  
            [W,Q] = quadrature(normal_order,'GAUSS',2);  
          end
        