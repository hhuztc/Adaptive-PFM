function [exisp,etasp]=G_L_coor(x0,y0,el1)   

el(1)=el1(1,1);
el(2)=el1(1,2);
el(3)=el1(2,1);
el(4)=el1(2,2);
el(5)=el1(3,1);
el(6)=el1(3,2);
el(7)=el1(4,1);
el(8)=el1(4,2);

for i=1:2
       ab(1+4*(i-1))=0.25*(-el(i)+el(i+2)+el(i+4)-el(i+6));
 	   ab(2+4*(i-1))=0.25*(el(i)-el(i+2)+el(i+4)-el(i+6)); 
	   ab(3+4*(i-1))=0.25*(-el(i)-el(i+2)+el(i+4)+el(i+6));
       ab(4+4*(i-1))=0.25*(el(i)+el(i+2)+el(i+4)+el(i+6));
end  
    
tolerance =  1.0e-5;

a1 = ab(1); 
a2 = ab(2);
a3 = ab(3);
a4 = ab(4);
b1 = ab(5); 
b2 = ab(6); 
b3 = ab(7); 
b4 = ab(8); 

x  = x0 - a4; 
y = y0 - b4;
s1 = a2*b3 - a3*b2;
t1 = b2*x - a2*y + a1*b3 - a3*b1;
d1 = b1*x - a1*y ;

if(abs(s1) < tolerance)  
   etasp = -d1/t1 ;
   
  if(abs(a1+a2*etasp)< tolerance) 
s1 = b2*a1 - b1*a2 ;
t1 = a2*y - b1*a3+ a1*b3 - b2*x ;
d1 = a3*y - b3*x ;
if(abs(s1) < tolerance )  
   exisp = -d1/t1 ;
   etasp= (x-a1*exisp) / (a3+a2*exisp) ;
else
   g1 = (-t1 + sqrt(t1*t1-4*s1*d1)) / (2*s1) ;
   g2 = (-t1 - sqrt(t1*t1-4*s1*d1)) / (2*s1) ;
   if(abs(g1) < 1.0+tolerance)  
      g0 = (x-a1*g1) / (a3+a2*g1)  ;
      if(abs(g0) < 1.0+tolerance)  
         exisp = g1  ;
          etasp= g0  ;
      end
   end
   if(abs(g2) < 1.0+tolerance)  
      g0 = (x-a1*g2) / (a3+a2*g2) ;
      if(abs(g0) < 1.0+tolerance)  
         exisp = g2  ;
          etasp= g0  ;
      end
   end
end  
return

  end
  
   exisp = (x-a3*etasp) / (a1+a2*etasp) ; 
  
  else
   g1 = (-t1 + sqrt(t1*t1-4*s1*d1)) / (2*s1);
   g2 = (-t1 - sqrt(t1*t1-4*s1*d1)) / (2*s1);
   if(abs(g1) < 1.0+tolerance)  
      g0 = (x-a3*g1) / (a1+a2*g1);
      if(abs(g0) < 1.0+tolerance)   
         etasp = g1 ;
         exisp = g0 ;
      end
   end
   
   if(abs(g2) < 1.0+tolerance)  
      g0 = (x-a3*g2) / (a1+a2*g2) ;
      
      if(abs(g0) < 1.0+tolerance)  
         etasp = g2 ;
         exisp = g0 ;
      end  
      
   end  
   
end 
 
% END OF FUNCTION
