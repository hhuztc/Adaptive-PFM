function [nd]=disTip_point2(phi,tip0,nodess,xCr,kk,kkk)

nd=[]; 
corner  = [1 2 3 4 1];
node    = [-1 -1; 1 -1; 1 1; -1 1]; 
 

% loop on element edges
for i = 1:4
    n1 = corner(i);
    n2 = corner(i+1);
    if phi(n1)*phi(n2) < 0
        r    = phi(n1)/(phi(n1)-phi(n2));
        pnt  = (1-r)*node(n1,:)+r*node(n2,:);
        [N,dNdxi]=lagrange_basis('Q4',pnt);
        Gpnt = N' * nodess; % global GP
         nd = [nd;Gpnt]; 
    end
end 
 
           seg   = xCr(kkk).coor(2,:) - xCr(kkk).coor(1,:);
           seg2  = nd(2,:)-nd(1,:) ;
           if(sum(seg.*seg2)<0)
           nd = [nd(2,:); nd(1,:)];      
           end 



 if(abs(xCr(kk).coor(1,1)-tip0(1))+abs(xCr(kk).coor(1,2)-tip0(2))<1e-8)  
           nd = [nd;tip0(1) tip0(2);tip0(3) tip0(4)];   
       end  
if(abs(xCr(kk).coor(1,1)-tip0(3))+abs(xCr(kk).coor(1,2)-tip0(4))<1e-8)  
           nd = [nd;tip0(3) tip0(4);tip0(1) tip0(2)];   
       end  

if(abs(xCr(kk).coor(size(xCr(kk).coor,1),1)-tip0(1))+abs(xCr(kk).coor(size(xCr(kk).coor,1),2)-tip0(2))<1e-8)  
           nd = [nd;tip0(3) tip0(4);tip0(1) tip0(2)];   
       end  
if(abs(xCr(kk).coor(size(xCr(kk).coor,1),1)-tip0(3))+abs(xCr(kk).coor(size(xCr(kk).coor,1),2)-tip0(4))<1e-8)  
           nd = [nd;tip0(1) tip0(2);tip0(3) tip0(4)];   
       end  

 

 