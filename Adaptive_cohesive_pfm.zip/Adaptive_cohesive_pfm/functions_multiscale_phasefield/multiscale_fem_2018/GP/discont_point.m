function [nd]=discont_point(phi,nodess,xCr,kk)

nd=[];
corner = [1 2 3 4 1];
node   = [-1 -1; 1 -1; 1 1; -1 1];

% loop on element edges
for i = 1 : 4
    n1 = corner(i);
    n2 = corner(i+1);
    if ( phi(n1)*phi(n2) < 0 )
        r    = phi(n1)/(phi(n1)-phi(n2));
        pnt  = (1-r)*node(n1,:)+r*node(n2,:);
        [N,dNdxi]=lagrange_basis('Q4',pnt);
         Gpnt = N' * nodess; % global GP
         nd = [nd;Gpnt]; 
    end 
end

 
 
           seg   = xCr(kk).coor(2,:) - xCr(kk).coor(1,:);
           seg2  = nd(2,:)-nd(1,:) ;
           if(sum(seg.*seg2)<0)
           nd = [nd(2,:); nd(1,:)];      
           end 
       
  