function [W,Q]=quad_variable_node_ele(e,order,nodes,ilab)

global node element vari_ele elemType fac_sub

   for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
   end 
    
     nodes0=[]; 
    local_shape=[];   
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
     local_shape=[local_shape; exisp,etasp];  
     nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
       end
   end 
      
      local_shape0=[]; 
      for i=1:size(local_shape,1)
         if(abs(local_shape(i,1)+1)<1e-5 | abs(local_shape(i,1)-1)<1e-5 ) 
            local_shape0= [local_shape0; -local_shape(i,1) local_shape(i,2)];
         elseif(abs(local_shape(i,2)+1)<1e-5 | abs(local_shape(i,2)-1)<1e-5 ) 
            local_shape0= [local_shape0; local_shape(i,1) -local_shape(i,2)];
         end
      end 
    
    local_shape1=[];
   if(size(local_shape,1)==2*(fac_sub-1) |  size(local_shape,1)==3*(fac_sub-1))   
   for i=1:fac_sub-1 % add nodes in the element
     if(abs(local_shape(i,1)+1)<1e-5 | abs(local_shape(i,1)-1)<1e-5 ) 
        p1=local_shape(i,:) ; p2=[-local_shape(i,1) local_shape(i,2)];
      for j=fac_sub:2*(fac_sub-1)
        q1=local_shape(j,:) ; q2=[local_shape(j,1) -local_shape(j,2)];
         [ ival, p0 ] = lines_exp_int_2d ( p1, p2, q1, q2 );
         local_shape1= [local_shape1; p0];
       end
     elseif(abs(local_shape(i,2)+1)<1e-5 | abs(local_shape(i,2)-1)<1e-5 ) 
      p1=local_shape(i,:) ; p2=[local_shape(i,1) -local_shape(i,2)];
      for j=fac_sub:2*(fac_sub-1)
        q1=local_shape(j,:) ; q2=[-local_shape(j,1) local_shape(j,2)];
         [ ival, p0 ] = lines_exp_int_2d ( p1, p2, q1, q2 );
         local_shape1= [local_shape1; p0];
     end
  end  
 end
end



      node0=[-1 -1; 1 -1; 1 1; -1 1;local_shape; local_shape0; local_shape1];

      node0=unique(node0,'rows'); 

     % get decompused triangles
       tri = delaunay(node0(:,1),node0(:,2));
 
       tri = tricheck(node0,tri);  
 

% ---- plot of the triangulation ------------ 
% 
if(ilab==1)
 nd=[]; 
    for igp = 1 : size(node0,1)
         gpnt = node0(igp,:);
     %    [N,dNdxi]=lagrange_basis('Q4',gpnt);  

       [N_vari,dN_varidxi] = shape_function_vari_ele(local_shape,gpnt);

       nodes1=[nodes;nodes0]; 
         Gpnt =  N_vari' * nodes1; % global GP

       %Gpnt = N' * nodes; % global GP
         nd = [nd;Gpnt];
    end 
 
 triplot(tri, nd(:,1),nd(:,2),'g')
end
% 
% ------------------------------------------



   % loop over subtriangles to get quadrature points and weights
    pt = 1;
    for ie = 1:size(tri,1)  
    [w,q]=quadrature(order,'TRIANGULAR',2);
    coord = node0(tri(ie,:),:);
    a = det([coord,[1;1;1]])/2;
    if ( a<0 )  % need to swap connectivity
        coord = [coord(2,:);coord(1,:);coord(3,:)];
        a = det([coord,[1;1;1]])/2;
    end 
     
     if ( a>1e-8 )
        for n=1:length(w)
            N=lagrange_basis('T3',q(n,:)); 
            Q(pt,:) = N'*coord;
            W(pt,1) = 2*w(n)*a; 
            pt = pt+1;
        end
    end

end
 
 