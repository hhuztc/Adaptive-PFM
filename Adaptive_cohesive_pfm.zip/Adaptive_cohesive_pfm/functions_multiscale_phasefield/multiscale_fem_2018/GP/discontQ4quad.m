function [W,Q]=discontQ4quad(order,phi,nodes,iel,ilab)

global node element vari_ele elemType fac_sub

corner = [1 2 3 4 1];
node0   = [-1 -1; 1 -1; 1 1; -1 1];

% loop on element edges
for i = 1 : 4
    n1 = corner(i);
    n2 = corner(i+1);
    if ( phi(n1)*phi(n2) < 0 )
        r    = phi(n1)/(phi(n1)-phi(n2));
        pnt  = (1-r)*node0(n1,:)+r*node0(n2,:);
        node0 = [node0;pnt];
    end
    if ( abs(phi(n1)*phi(n2)) < 1e-4 ) % notice here
      % pnt  = node0(n1,:);   
      % node0 = [node0; pnt];  
    end
end

if size(find(phi==0),1)==2   % 2points are considered on the crack 
    node0 = [node0; 0 0] ;
end 

   if(ismember(iel,vari_ele(:,1)))

 for i=1:size(vari_ele,1)
        if(iel==vari_ele(i,1))
        itmp=i;
        break
        end
    end  

    local_shape=[];   
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
     local_shape=[local_shape; exisp,etasp];  
       end
   end 
      
      local_shape0=[]; 
      for i=1:size(local_shape,1)
         if(abs(local_shape(i,1)+1)<1e-5 | abs(local_shape(i,1)-1)<1e-5 ) 
            local_shape0= [local_shape0; -local_shape(i,1) local_shape(i,2)];
         elseif(abs(local_shape(i,2)+1)<1e-5 | abs(local_shape(i,2)-1)<1e-5 ) 
            local_shape0= [local_shape0; local_shape(i,1) -local_shape(i,2)];
         end
      end 
    
    local_shape1=[];
   if(size(local_shape,1)==2*(fac_sub-1))   
   for i=1:fac_sub-1 % add nodes in the element
     if(abs(local_shape(i,1)+1)<1e-5 | abs(local_shape(i,1)-1)<1e-5 ) 
        p1=local_shape(i,:) ; p2=[-local_shape(i,1) local_shape(i,2)];
      for j=fac_sub:2*(fac_sub-1)
        q1=local_shape(j,:) ; q2=[local_shape(j,1) -local_shape(j,2)];
         [ ival, p0 ] = lines_exp_int_2d ( p1, p2, q1, q2 );
         local_shape1= [local_shape1; p0];
       end
     elseif(abs(local_shape(i,2)+1)<1e-5 | abs(local_shape(i,2)-1)<1e-5 ) 
      p1=local_shape(i,:) ; p2=[local_shape(i,1) -local_shape(i,2)];
      for j=fac_sub:2*(fac_sub-1)
        q1=local_shape(j,:) ; q2=[-local_shape(j,1) local_shape(j,2)];
         [ ival, p0 ] = lines_exp_int_2d ( p1, p2, q1, q2 );
         local_shape1= [local_shape1; p0];
     end
  end  
 end
end

      node0=[node0; local_shape; local_shape0; local_shape1];  
end

node0=unique(node0,'rows');

% get decompused triangles
tri = delaunay(node0(:,1),node0(:,2));
tri = tricheck(node0,tri);

% ---- plot of the triangulation ------------ 
% 
if(ilab==1)
 nd=[]; 
    for igp = 1 : size(node0,1)
         gpnt = node0(igp,:);
         [N,dNdxi]=lagrange_basis('Q4',gpnt);
         Gpnt = N' * nodes; % global GP
         nd = [nd;Gpnt];
    end 
 
 triplot(tri, nd(:,1),nd(:,2),'g')
end
% 
% ------------------------------------------

% loop over subtriangles to get quadrature points and weights
pt = 1;
for e = 1:size(tri,1) 
   %  [w,q]=quadrature(order,'DUNAVANT',2) ; 
 [w,q]=quadrature(order,'TRIANGULAR',2);
    % transform quadrature points into the parent element
    coord = node0(tri(e,:),:);
    a = det([coord,[1;1;1]])/2;
    if ( a<0 )  % need to swap connectivity
        coord = [coord(2,:);coord(1,:);coord(3,:)];
        a = det([coord,[1;1;1]])/2;
    end

    %if ( a~=0 )
     if ( a>1e-8 )
        for n=1:length(w)
            N=lagrange_basis('T3',q(n,:));
            Q(pt,:) = N'*coord;
            W(pt,1) = 2*w(n)*a; 
            pt = pt+1;
        end
    end

end
