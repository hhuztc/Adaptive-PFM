function plot_GP_new(elemType,Q,xCr,W,iel,compt,enrich_node,xyTip,radius)

global node element

q=[];
sctr = element(iel,:);
% Plot mesh and enriched nodes to check 
    for igp = 1 : size(W,1)
        gpnt = Q(igp,:) ;
        [N,dNdxi]=lagrange_basis(elemType,gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        q = [q;Gpnt];
    end

if(compt==1) 
figure
hold on
plot_m(elemType,xCr,enrich_node);
%plot_mesh(node,element,elemType,'b-');
plot(q(:,1),q(:,2),'r*');

for kk = 1: size(xCr,2) 
    for k = 1:size(xCr(1).coor,1)-1
        cr = plot(xCr(kk).coor(k:k+1,1),xCr(kk).coor(k:k+1,2),'r-');
        set(cr,'LineWidth',3);
    end
end
axis off
clear q

% plot the circle
 theta = -pi:0.1:pi;
 xo = xyTip(1) + radius*cos(theta) ;
 yo = xyTip(2) + radius*sin(theta) ;
 plot(xo,yo,'k-'); 
end