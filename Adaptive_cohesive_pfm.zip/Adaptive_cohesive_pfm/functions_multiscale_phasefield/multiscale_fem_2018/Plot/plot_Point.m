function plot_Point(elemType,q,xCr)
 
global node element 

figure
hold on
plot_mesh(node,element,elemType,'b-');
plot(q(:,1),q(:,2),'ko');
for k = 1:2:size(xCr,1)-1
cr = plot(xCr(k:k+1,1),xCr(k:k+1,2),'r--');
set(cr,'LineWidth',2);
end
for k = 1:size(xCr,2)
  for kj = 1:size(xCr(k).coor,1)-1
    cr = plot(xCr(k).coor(kj:kj+1,1),xCr(k).coor(kj:kj+1,2),'r--');
    set(cr,'LineWidth',2);
  end
  for kj = 1:size(xCr(k).coor,1)
   % plot(xCr(k).coor(kj,1),xCr(k).coor(kj,2),'ro','MarkerFaceColor',[.49 1 .63],'MarkerSize',10);
  end
end

axis off
clear q
