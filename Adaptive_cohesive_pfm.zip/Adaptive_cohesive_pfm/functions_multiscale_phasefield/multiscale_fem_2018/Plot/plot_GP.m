function plot_GP(elemType,q)
 
global node element  
 
plot(q(:,1),q(:,2),'r*'); 

axis off
clear q
