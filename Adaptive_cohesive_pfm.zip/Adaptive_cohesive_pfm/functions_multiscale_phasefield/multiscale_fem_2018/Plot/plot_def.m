function plot_def(fac,u_x,u_y,elemType)

global node element p_crack1 p_crack2

% Plot mesh and enriched nodes to check 
%v=get(0,'ScreenSize');
%figure('Color',[1 1 1],'Position', [0 0 0.4*v(1,3) 0.4*v(1,4)])
 
figure 
hold on

plot_mesh(node+fac*[u_x u_y],element,elemType,'k-');  
axis off

 