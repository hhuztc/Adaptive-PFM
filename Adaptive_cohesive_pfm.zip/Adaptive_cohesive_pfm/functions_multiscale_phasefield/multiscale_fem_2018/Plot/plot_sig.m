function plot_sig(fac,u_x,u_y,elemType,stress)

global node element  

stressComp=1; 
fac=0;
figure
%set(gcf,'Position',[100 100 160 70]);
set(gca,'position',[0 0 1 1]); 
figure_FontSize=8;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',10),'FontSize',figure_FontSize);
set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',2);
plot_field(node+fac*[u_x u_y],element,elemType,stress(:,:,stressComp)); 
colorbar
axis off
title('raw \sigma_x') 
print(gcf,'-dtiff','raw sigma_x.tiff')



stressComp=2; 
fac=0;
figure
%set(gcf,'Position',[100 100 160 70]);
set(gca,'position',[0 0 1 1]); 
figure_FontSize=8;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',10),'FontSize',figure_FontSize);
set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',2);
plot_field(node+fac*[u_x u_y],element,elemType,stress(:,:,stressComp)); 
colorbar
axis off
title('raw \sigma_y') 
print(gcf,'-dtiff','raw sigma_y.tiff')


stressComp=3; 
fac=0;
figure
%set(gcf,'Position',[100 100 160 70]);
set(gca,'position',[0 0 1 1]); 
figure_FontSize=8;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',10),'FontSize',figure_FontSize);
set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',2);
plot_field(node+fac*[u_x u_y],element,elemType,stress(:,:,stressComp)); 
colorbar
axis off
title('raw \tau_x_y') 
print(gcf,'-dtiff','raw sigma_xy.tiff')