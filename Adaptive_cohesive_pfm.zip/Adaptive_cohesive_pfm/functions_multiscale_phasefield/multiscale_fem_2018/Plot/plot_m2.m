function plot_m2(elemType,xCr,enrich_node,dispNodes)

global node element

% Plot mesh and enriched nodes to check 

%to adjust the size and the background's color of the figure
%v=get(0,'ScreenSize');
%figure('Color',[1 1 1],'Position', [0 0 0.4*v(1,3) 0.4*v(1,4)])

figure
hold on
plot_mesh(node,element,elemType,'k-');
for k = 1:size(xCr,2)
  for kj = 1:size(xCr(k).coor,1)-1
    cr = plot(xCr(k).coor(kj:kj+1,1),xCr(k).coor(kj:kj+1,2),'r-');
    set(cr,'LineWidth',2);
  end
  for kj = 1:size(xCr(k).coor,1)
   plot(xCr(k).coor(kj,1),xCr(k).coor(kj,2),'ro','MarkerFaceColor',[.49 1 .63],'MarkerSize',7);
  end
split_nodes = find(enrich_node(:,k) == 2);
tip_nodes   = find(enrich_node(:,k) == 1);  
junct_nodes   = find(enrich_node(:,k) == 3); 
split_tip_nodes = find(enrich_node(:,k) == 22);
tip1_nodes   = find(enrich_node(:,k) == 11); 

 
end
axis off

%pause % watch the figure before continuing...