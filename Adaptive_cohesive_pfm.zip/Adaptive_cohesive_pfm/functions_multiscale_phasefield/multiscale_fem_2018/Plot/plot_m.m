function plot_m(elemType,xCr,enrich_node)

global node element  

% Plot mesh and enriched nodes to check 

%to adjust the size and the background's color of the figure
%v=get(0,'ScreenSize');
%figure('Color',[1 1 1],'Position', [0 0 0.4*v(1,3) 0.4*v(1,4)])

figure
hold on
plot_mesh(node,element,elemType,'k-');
for k = 1:size(xCr,2)
  for kj = 1:size(xCr(k).coor,1)-1
    cr = plot(xCr(k).coor(kj:kj+1,1),xCr(k).coor(kj:kj+1,2),'r-');
    set(cr,'LineWidth',2);
  end
  for kj = 1:size(xCr(k).coor,1)
  % plot(xCr(k).coor(kj,1),xCr(k).coor(kj,2),'ro','MarkerFaceColor',[.49 1 .63],'MarkerSize',7);
  end
split_nodes = find(enrich_node(:,k) == 2);
tip_nodes   = find(enrich_node(:,k) == 1); 
split_tip_nodes = find(enrich_node(:,k) == 12); 
junct_nodes   = find(enrich_node(:,k) == 3); 
tip1_nodes   = find(enrich_node(:,k) == 11); 
split_tip1_nodes = find(enrich_node(:,k) == 22); 

if(k==1)
n1 = plot(node(split_nodes,1),node(split_nodes,2),'ks');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'ko');
n3 = plot(node(junct_nodes,1),node(junct_nodes,2),'rx');
n22 = plot(node(tip1_nodes,1),node(tip1_nodes,2),'bo');
n11 = plot(node(split_tip_nodes,1),node(split_tip_nodes,2),'ko');
n111 = plot(node(split_tip1_nodes,1),node(split_tip1_nodes,2),'b<'); 
else
n1 = plot(node(split_nodes,1),node(split_nodes,2),'k^');
n2 = plot(node(tip_nodes,1),node(tip_nodes,2),'ko');
n3 = plot(node(junct_nodes,1),node(junct_nodes,2),'rx');
n22 = plot(node(tip1_nodes,1),node(tip1_nodes,2),'bo');
n11 = plot(node(split_tip_nodes,1),node(split_tip_nodes,2),'ko');
n111 = plot(node(split_tip1_nodes,1),node(split_tip1_nodes,2),'b<'); 
end

set(n1,'MarkerSize',10);
set(n2,'MarkerSize',10);
set(n3,'MarkerSize',10);
set(n11,'MarkerSize',10);
set(n111,'MarkerSize',10);
set(n22,'MarkerSize',10);  
end
axis off 