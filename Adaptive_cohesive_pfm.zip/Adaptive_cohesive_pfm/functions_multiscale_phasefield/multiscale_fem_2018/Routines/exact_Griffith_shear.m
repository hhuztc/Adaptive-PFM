
function [ux,uy] = exact_Griffith_shear(xx,a,p,t,coef,stressState) ;

 global   E nu   

if ( strcmp(stressState,'PLANE_STRESS') )
   kappa = (3-nu)/(1+nu);    %Kolosov coeff, Plain stress
else
  kappa = 3-4*nu;    %Kolosov coeff, Plain strain
end 

mu = E/(2*(1+nu));

x1=xx(1,1);
x2=xx(1,2); 

 m=x1^2-x2^2-a^2;
 n=2*x1*x2;

 theta=-atan(n/m) ; 

 tt=sqrt(m^2+n^2);


 
    ux = (kappa+1)/(4*mu)*t*sqrt(tt)*sin(-theta/2)+x2/(2*mu)*t/sqrt(tt)*(x1*cos(theta/2)-x2*sin(theta/2));
    uy = -(kappa-1)/(4*mu)*t*sqrt(tt)*cos(-theta/2)-x2/(2*mu)*t/sqrt(tt)*(x2*cos(theta/2)+x1*sin(theta/2));
 




