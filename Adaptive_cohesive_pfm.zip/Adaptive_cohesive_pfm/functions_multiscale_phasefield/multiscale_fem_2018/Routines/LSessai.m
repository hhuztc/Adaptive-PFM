function [ls] = LS(iel,elem_crk)

% give the distance (vector) of the orthogonale projection of each point of the element iel   

% ls = 0 if this distance is smaller that the tolerance (tol_ratio *
%                                 average size of element's boundary)

global node element
sctr = element(iel,:);

tol_ratio = 1/100;    % ratio for the  


% fixing the tolerance
a = [node(element(iel,:),:) ; node(element(iel,1),:)];
somme = 0;
for n=1:size(element(iel,:),2)            % compute the average length of element's boundary (for Q4 and T3)
    somme=somme+((a(n+1,1)-a(n,1))^2+(a(n+1,2)-a(n,2))^2)^(0.5);
end
somme=somme/size(element(iel,:),2)

EPS = somme * tol_ratio

x0  = elem_crk(iel,1); y0 = elem_crk(iel,2);
x1  = elem_crk(iel,3); y1 = elem_crk(iel,4);

for i = 1 : size(sctr,2)
    x = node(sctr(i),1);
    y = node(sctr(i),2);
    xp=(x0*y1^2-x1*y1*y0-y1*x0*y-x0*y1*y0+y1*x1*y+x1^2*x+x1*y0^2+x0*y0*y-2*x1*x0*x-x1*y0*y+x0^2*x)/(y1^2-2*y1*y0+y0^2+x1^2-2*x1*x0+x0^2)
    yp=(y1*x1*x-y1*x0*x-y0*x1*x+y1^2*y+y1*x0^2-2*y1*y0*y-x0*x1*y0+y0*x0*x+y0^2*y+x1^2*y0-x1*y1*x0)/(y1^2-2*y1*y0+y0^2+x1^2-2*x1*x0+x0^2)
    phi3= ((x-xp)^2+(y-yp)^2)^0.5;
    %phi2   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0))  % non usata!mi interessano i rapporti e i segni di phi...
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    if abs(phi) < EPS
        ls(i,1) = 0;            % normal LS    
    else
        %ls(i,1) = phi;  % normal LS
        ls(i,1)= phi3*sign(phi);
    end
end 

ratio = max(abs(ls)) / min(abs(ls))
