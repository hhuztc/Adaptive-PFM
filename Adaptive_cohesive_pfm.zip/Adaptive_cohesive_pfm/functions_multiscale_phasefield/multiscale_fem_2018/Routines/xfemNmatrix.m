function Nc = xfemNmatrix(pt,elemType,e,type_elem,enrich_node,xCrl,GVertex,xJertex,cont)
global node element

sctr = element(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions 
Gpt = N' * node(sctr,:);                  % GP in global coord, used


Bfem = zeros(2,2*nn); 
 

% Switch between non-enriched and enriched elements
if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements (for all cracks)
    Nc = Bfem;
else                               % Enriched elements
    Bxfem = [] ;
    % loop on nodes, check node is enriched ...
    for in = 1 : nn 
% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        if ( enrich_node(sctr(in)) == 2) 
            if (type_elem(e,cont) == 2) | (type_elem(e,cont) == 3)  %node in a split element
                BI_enr = [2*N(in)  0 ; 0   2*N(in)]; 
            else
              BI_enr = [0  0 ; 0   0];    
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;  

        
% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        elseif ( enrich_node(sctr(in)) == 3) 
            if (type_elem(e,cont) == 4  )   % junction  
                 BI_enr = [2*N(in)  0 ; 0   2*N(in)]; 
                else
               BI_enr = [0  0 ; 0   0]; 
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;  
            
% ------------ Enriched by asymptotic functions -----------------------------------             
        elseif ( enrich_node(sctr(in)) == 1) % B(x) enriched node
            if type_elem(e,1) == 1   %looking for the "tip" element
                ref_elem = e;
            else    %trovo l'elemento/fessura a cui fa riferimento il nodo (SOLO 1 RIF AUTORIZZATO!!)
                [sctrn,xx] = find(element == sctr(in));
                [ele,xx] = find(type_elem(sctrn,:)==1);
                ref_elem = sctrn(ele);
            end                
            % compute branch functions at Gauss point
            xCre  = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];
            seg   = xCre(2,:) - xCre(1,:); 
 
            alpha = atan2(seg(2),seg(1));
            xTip  = [xCre(2,1) xCre(2,2)];
            QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
            xp    = QT*(Gpt-xTip)';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));  

            aa = 2*sqrt(r)*N(in); 
            B1_enr = [aa 0 ; 0 aa]; 
            B2_enr = [0 0 ; 0 0]; 
            B3_enr = [0 0 ; 0 0]; 
            B4_enr = [0 0 ; 0 0];

            BI_enr = [B1_enr B2_enr B3_enr B4_enr];

            clear B1_enr; clear B2_enr; clear B3_enr; clear B4_enr;
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;
         end

    end          % end of loop on nodes
    % B matrix
    Nc= [ Bfem Bxfem ];
    clear Bfem; clear Bxfem;
end              % end of switch between enriched and non-enriched elements 


    