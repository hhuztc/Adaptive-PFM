function [dispNodes,tracNodes,edgeNodes,bnodes]=boundarynodes(nnx,nny)

global node element
global numnode numelem elemType
global typeMethod typeProblem typeCrack

% define essential boundaries
uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)

rightEdge= [ lrn:nnx:(uln-1); (lrn+nnx):nnx:urn ]';
leftEdge = [ uln:-nnx:(lrn+1); (uln-nnx):-nnx:1 ]';
topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
botNodes   = unique(botEdge);
rightNodes = unique(rightEdge);
topNodes   = unique(topEdge);
leftNodes  = unique(leftEdge);

% dispNodes = [botNodes;rightNodes;topNodes];
% dispNodes = unique(dispNodes);

bnodes = {botNodes rightNodes topNodes leftNodes} ;
% edgenodes = {botEdge rightEdge topEdge leftEdge} ;

if( strcmp(typeProblem,'Griffith') )
    dispNodes = unique([botNodes;rightNodes;topNodes;leftNodes]) ;
    tracNodes = [] ;
    edgeNodes = {botEdge rightEdge topEdge leftEdge} ;
else
    dispNodes = unique([botNodes]) ;
    tracNodes = unique([topNodes]) ;
    edgeNodes = {botEdge rightEdge topEdge leftEdge} ;
end