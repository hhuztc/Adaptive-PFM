function [Jdomain,qnode,radius] = Jdomainf(tip_elem,xTip,enrich_node)

global node element fac_J vari_ele

sysm x y;

numnode = size(node,1);  
 
sctr = element(tip_elem,:);
area = polyarea(node(sctr,1),node(sctr,2)); 
 

for itr=1:10
radius = (fac_J+(itr-1)*0.5) * sqrt(area);
center = xTip;

r=[];
% Distance from the center of tip element
for i = 1 : numnode
    sctr = node(i,:);
    rho  = sqrt((sctr(1)-center(1))^2+(sctr(2)-center(2))^2);
    r    = [r,rho];
end
test = r-radius;
test = test(element)';
test = max(test).*min(test);
Jdomain = find(test<=0);
test1 = r-radius;
test1 = test1(element(Jdomain,:))';
test1 = (test1<=0);
qnode = test1';

% checking if there is some B enriched elements in the Jdomain
for i=1:size(Jdomain,2)
    sctr = element (Jdomain(i),:);
    tip_enr = find(enrich_node(sctr,:) == 1);
    if size(tip_enr,1) > 0 
        disp('!!!WARNING!!! the Jdomain contain tip enriched elements => you should use a finer mesh')
        return % in order to not display the error message several times 
    end
end  
  
for i=1:size(vari_ele,1) 
   kk(i)=0;
     if(vari_ele(i,1)>0) 
    sctr=element(vari_ele(i,1),:);
     for j=1:length(sctr)
     if(j==length(sctr))
       x0=node(sctr(j),1);  y0=node(sctr(j),2);
       x1=node(sctr(1),1);  y1=node(sctr(1),2);
        else
        x0=node(sctr(j),1);  y0=node(sctr(j),2);
       x1=node(sctr(j+1),1);  y1=node(sctr(j+1),2);
     end
     
    eq1=(x-center(1))^2+(y-center(2))^2-radius^2;
    eq1=subs(eq1);
    eq2=(y-y0)*(x1-x0)-(y1-y0)*(x-x0);
    eq2=subs(eq2);
    [x,y]=solve(eq1,eq2);
     
      end
     end  
     end 

 

tmp=0;
for i=1:size(vari_ele,1)   
   if(kk(i)>0 & kk(i)<4)   
   tmp=1;
  end
end  
 
tmp

   if(tmp>0)  
 else
 fprintf(' *** The factor for J integral: %8.3e\n', fac_J+(itr-1)*0.5)  
  return
 end 
 
end

 

