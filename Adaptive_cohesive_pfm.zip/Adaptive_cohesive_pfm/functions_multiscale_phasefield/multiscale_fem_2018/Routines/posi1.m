function pos = posi1(xCr,numnode,enrich_node)

pos = zeros(numnode,size(xCr,2));
    nsnode = 0 ;
    ntnode = 0 ;
    njnode = 0 ;
    nstnode = 0 ;
    nt1node = 0 ;
    nst1node = 0 ;

for k = 1:size(xCr,2)
    for i = 1 : numnode
        if (enrich_node(i,k) == 2)
             pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            nsnode = nsnode + 1 ;
        elseif (enrich_node(i,k) == 1)
            pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            ntnode = ntnode + 1 ;  
        elseif (enrich_node(i,k) == 3)
            pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            njnode = njnode + 1 ;  
        elseif (enrich_node(i,k) == 22)
           pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            nstnode = nstnode + 1 ;
        elseif (enrich_node(i,k) == 11)
            pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            nt1node = nt1node + 1 ;  
       elseif (enrich_node(i,k) == 12)
            pos(i,k) = (numnode + nsnode*1 + ntnode*2 +njnode*1+nstnode*3 + nt1node*2 + nst1node*3) + 1 ;
            nst1node = nst1node + 1 ; 
        end

    end
end