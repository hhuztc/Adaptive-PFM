function [enrich_node] = node_detect_0(xCr,elems)
 %enrich_node                                     
global node element fac_enrich iflag_blend vari_ele

type_elem = zeros(size(element,1),size(xCr,2));%xcr���Ƶ�x,
elem_crk = zeros(size(element,1),4);%�������ڵĵ�Ԫ

xCr_element = zeros(size(element,1),2);
xTip = zeros(size(element,1),2);
xVertex = zeros(size(element,1),2);
xJertex = zeros(size(element,1),4);

enrich_node = zeros(size(node,1),size(xCr,2));

% select the special elements(tip, vertex, split)
for kk = 1:size(xCr,2)    
    for iel=1:size(elems,1)                     %loop on elems (=elements selected for enrichment)
        e = elems(iel)  ;
         sctr=element(e,:);               
        vv = node(sctr,:) ;
        crk_int = [];
        intes = 0;
        flag1 = 0;
        flag2 = 0; 
        for kj = 1:size(xCr(kk).coor,1)-1       %loop over the elements of the fracture
            q1 = xCr(kk).coor(kj,:); 
            q2 = xCr(kk).coor(kj+1,:);
            sctrl = [sctr sctr(1,1)];      
            for iedge=1:size(sctr,2)             %loop over the edges of elements
                nnode1=sctrl(iedge);
                nnode2=sctrl(iedge+1);
                p1 = [node(nnode1,:)];
                p2 = [node(nnode2,:)];
                intersect=segments_int_2d(p1,p2,q1,q2) ;   
                intes = intes + intersect(1);
                if intersect(1) > 0
                    crk_int = [crk_int intersect(2) intersect(3)];
 
  icho=2;
  if(icho==1)
                    flag1 = inhull(xCr(kk).coor(kj,:),vv,[],-1e-8);
                    flag2 = inhull(xCr(kk).coor(kj+1,:),vv,[],-1e-8);  
  else
                    area0 = polyarea(vv(:,1),vv(:,2)); %����vv����Ķ���ε���� ���������ѡ�����ĵ�Ԫ�����
                    area1=0;
                    for i=1:4
                    if(i==4)
                    ss1=[node(sctr(i),:); node(sctr(1),:); xCr(kk).coor(kj,:)]; 
                    else
                    ss1=[node(sctr(i),:); node(sctr(i+1),:); xCr(kk).coor(kj,:)]; 
                    end 
                    area1 = area1 +polyarea(ss1(:,1),ss1(:,2)); 
                    end                        
            if(abs(area0-area1)<1e-8)
              flag1 = 1;
                else
               flag1 = 0;
             end

                   area2=0;
                    for i=1:4
                    if(i==4)
                    ss2=[node(sctr(i),:); node(sctr(1),:); xCr(kk).coor(kj+1,:)]; 
                    else
                    ss2=[node(sctr(i),:); node(sctr(i+1),:); xCr(kk).coor(kj+1,:)]; 
                    end
                    area2 = area2 +polyarea(ss2(:,1),ss2(:,2)); 
                    end                        
            if(abs(area0-area2)<1e-8)
              flag2 = 1;
                else
               flag2 = 0;
             end  
end  

                    xCr_element(e,:) = xCr(kk).coor(kj,:) * flag1 + xCr(kk).coor(kj+1,:) * flag2;  % link between crack coordinate and elements  
                end
            end %for iedge
        end % kj   
 
      if ((intes == 2) & (flag1 == 0) & (flag2 == 0))     % SPLIT  !!!not
            type_elem(elems(iel),kk) = 2;  
            elem_crk(e,:) = crk_int;
        end 

        if ((intes == 3) & (flag1 == 0) & (flag2 == 0))     % SPLIT  !!!note here -free traction 
            type_elem(elems(iel),kk) = 2;  
            elem_crk(e,:) = crk_int(1:4);
        end

        if (((flag1 == 1) | flag2==1) & (intes==2))         % VERTEX      
            type_elem(e,kk) = 3; 
            elem_crk(e,:) = crk_int;
            xVertex(e,:) = xCr_element(e,:); 
        end  

        if (intes == 1) % TIP or Junction  
           xTip(e,:) = xCr_element(e,:) ;   
            for kk1 = 1:size(xCr,2)   
              if(kk1 ~=kk)
                for kj1 = 1:size(xCr(kk1).coor,1)-1       %loop over the elements of the fracture
            q1 = xCr(kk1).coor(kj1,:); 
            q2 = xCr(kk1).coor(kj1+1,:); 
            [ival] = point_in_line (xTip(e,:),q1,q2);  
               if(ival==1)  % junction
            type_elem(e,kk) = 4;    
            xJertex(e,:) = [crk_int xTip(e,1) xTip(e,2)];  %    
            end
         end
        end
       end   

        if(type_elem(e,kk) ~= 4)  
          type_elem(e,kk) = 1;    % tip
          elem_crk(e,:) = [crk_int xTip(e,1) xTip(e,2)];  % coordinates needed for SIF computation  
        end
      end % TIP or Junction 

    end % iel    
end % kk
        
% select the enriched nodes��������µĽڵ㣬�Ƚ��Ƿ���Ҫϸ����
for kk = 1:size(xCr,2)    
   for iel=1:size(elems,1)                     %loop on elems (=elements selected for enrichment)
        sctr = element(elems(iel),:);
        if type_elem(elems(iel),kk) == 1        % tip
            enrich_node(sctr,kk) = 1;
        elseif  type_elem(elems(iel),kk) == 2   % split
            for in=1:length(sctr)               % loop on the nodes of the element
                if enrich_node (sctr(in),kk) == 0  % already enriched
                    [Aw, Awp] = support_area(sctr(in),elems(iel),type_elem,elem_crk,xVertex,kk);
                    if (abs(Awp / Aw) > 1e-4) & (abs((Aw-Awp) / Aw) > 1e-4) %�ж�����С���������Ҫ��ϸ��  
                    	enrich_node(sctr(in),kk)   = 2;
                    end
                end
            end
        elseif type_elem(elems(iel),kk) == 3    %vertex  
            for in=1:length(sctr)
                if enrich_node (sctr(in),kk) == 0  % already enriched
                    [Aw, Awp] = support_area(sctr(in),elems(iel),type_elem,elem_crk,xVertex,kk); % let's test the tolerance linked to the support area! 
                    if ((abs(Awp / Aw) > 1e-4) & (abs((Aw-Awp) / Aw) > 1e-4)) 
                        enrich_node(sctr(in),kk)   = 2;
                    end
                end
            end  % loop on the nodes  


 elseif type_elem(elems(iel),kk) == 4    %junction 
            for in=1:length(sctr) 
                         enrich_node(sctr(in),kk)   = 3; 
            end  % loop on the nodes


        end  %if
    end  %loop on the elements
end  %loop on cracks

if(fac_enrich>0)
% select the enriched nodes for geometrical enrichment
for kk = 1:size(xCr,2) 
for iel=1 : size(element,1)
   if(type_elem(iel,kk)==1) 
   area = polyarea(node(element(iel,:),1),node(element(iel,:),2)); 
   radius = fac_enrich* sqrt(area);
   center = xTip(iel,:) ;   
  end
end
 for i = 1 : size(node,1) 
    rho  = sqrt((node(i,1)-center(1))^2+(node(i,2)-center(2))^2);
   if(rho<=radius & enrich_node(i,kk)==2) 
       enrich_node(i,kk) = 12;
   elseif(rho<=radius & enrich_node(i,kk)==0) 
       enrich_node(i,kk) = 1;
  end
end 
end 
end
 
if(iflag_blend==1)
% select the enriched nodes
for kk = 1:size(xCr,2) 
for iel=1 : size(element,1)
    sctr = element(iel,:) ;  
        if (ismember(1,enrich_node(sctr,kk)) ~= 0 | ismember(12,enrich_node(sctr,kk)) ~= 0) 
           for j=1:length(sctr)  
           if(enrich_node(sctr(j),kk)== 0)
              enrich_node(sctr(j),kk)=11;
           elseif (enrich_node(sctr(j),kk)== 2 )
              enrich_node(sctr(j),kk)=22;
           end
        
           end
           
        end
end  
end
else
end

 