function sctrB  = assembly2(e,enrich_node,pos,cont)

global node element split_elem vari_ele


if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
   end  
sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
 else
 sctr = element(e,:); 
  end  
 
nn   = length(sctr);

if cont == 1
 for k = 1 : nn
    sctrBfem(3*k-2) = 3*sctr(k)-2 ;
    sctrBfem(3*k-1) = 3*sctr(k)-1 ;
    sctrBfem(3*k)   = 3*sctr(k)   ;
 end
else
   sctrBfem = [];
end

if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
    sctrB = sctrBfem ;
    else
    tn = size(find(enrich_node(sctr) == 1),1);
    sn = size(find(enrich_node(sctr) == 2),1);
    jn = size(find(enrich_node(sctr) == 3),1);
    t1n = size(find(enrich_node(sctr) == 11),1);
    stn = size(find(enrich_node(sctr) == 22),1);
    stn1 = size(find(enrich_node(sctr) == 12),1);
    sctrBxfem = zeros(1,3*(sn*1+tn*4+jn*1+ stn*5+t1n*4 +stn1*5 )); 
    cnt = 0 ;
    for k = 1 : nn
        if ( enrich_node(sctr(k)) == 2 | enrich_node(sctr(k)) == 3) % split or junction
            cnt = cnt + 1 ;
            sctrBxfem(3*cnt - 2) = 3 * pos(sctr(k)) - 2;
            sctrBxfem(3*cnt - 1) = 3 * pos(sctr(k)) - 1;
            sctrBxfem(3*cnt    ) = 3 * pos(sctr(k))    ;
        elseif ( enrich_node(sctr(k)) == 1 | enrich_node(sctr(k)) == 11) % tip
            for i=1:4
            cnt = cnt + 1 ;
            sctrBxfem(3*cnt - 2) = 3 * (pos(sctr(k))+i-1) - 2;
            sctrBxfem(3*cnt - 1) = 3 * (pos(sctr(k))+i-1) - 1;
            sctrBxfem(3*cnt    ) = 3 * (pos(sctr(k))+i-1)    ;
            end            
         elseif ( enrich_node(sctr(k)) == 22 | enrich_node(sctr(k)) == 12) % split-tip1
           for i=1:5
            cnt = cnt + 1 ;
            sctrBxfem(3*cnt - 2) = 3 * (pos(sctr(k))+i-1) - 2;
            sctrBxfem(3*cnt - 1) = 3 * (pos(sctr(k))+i-1) - 1;
            sctrBxfem(3*cnt    ) = 3 * (pos(sctr(k))+i-1)    ;
            end    
        end
    end
    sctrB = [ sctrBfem sctrBxfem ];
end
