function Nc = xfemNmatrix2(pt,elemType,e,type_elem,enrich_node,xCrl,GVertex,xJertex,cont)
global node element

sctr = element(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Gpt = N' * node(sctr,:);                  % GP in global coord, used


Bfem = zeros(2,2*nn); 

     rr=0; 
     for ij=1:nn
     if(enrich_node(sctr(ij)) == 1) 
       rr=rr+N(ij) ; 
      end
      end   

% Switch between non-enriched and enriched elements
if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements (for all cracks)
    Nc = Bfem;
else                               % Enriched elements
    Bxfem = [] ;
    % loop on nodes, check node is enriched ...
    for in = 1 : nn 
% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        if ( enrich_node(sctr(in)) == 2) 
            if (type_elem(e,cont) == 2) | (type_elem(e,cont) == 3)  %node in a split element
                BI_enr = [2*N(in)  0 ; 0   2*N(in)]; 
            else
              BI_enr = [0  0 ; 0   0];    
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;  

        
% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        elseif ( enrich_node(sctr(in)) == 3) 
            if (type_elem(e,cont) == 4  )   % junction  
                 BI_enr = [2*N(in)  0 ; 0   2*N(in)]; 
                else
               BI_enr = [0  0 ; 0   0]; 
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;  
            
% ------------ Enriched by asymptotic functions -----------------------------------             
        elseif ( enrich_node(sctr(in)) == 1 | enrich_node(sctr(in)) == 11) % B(x) enriched node 
            if type_elem(e,1) == 1   %looking for the "tip" element
                ref_elem = e;
            else    %trovo l'elemento/fessura a cui fa riferimento il nodo (SOLO 1 RIF AUTORIZZATO!!)
                 [sctrn,xx] = find(element == sctr(in));
                [ele,xx]=find(type_elem(sctrn,:)==1);                
                if(isempty(ele)~=1)
                ref_elem = sctrn(ele);
                else   
                [sctrn1,xx1] = find(enrich_node(element(sctrn,:)) == 1);  
                node_p=[];
                for i=1:size(sctrn1,1)
                 node_p=[ node_p;element(sctrn(sctrn1(i)),xx1(i))]; 
                end 
                 for i=1:size(node_p,1)
                 [sctrn,xx] = find(element == node_p(i));
                 [ele,xx]=find(type_elem(sctrn,:)==1);  
                 ref_elem = sctrn(ele);
                 end  
                end 
            end                
            % compute branch functions at Gauss point
            xCre  = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];
            seg   = xCre(2,:) - xCre(1,:);
            alpha = atan2(seg(2),seg(1));
            xTip  = [xCre(2,1) xCre(2,2)];
            QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
            xp    = QT*(Gpt-xTip)';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));  

            aa = 2*sqrt(r)*N(in)*rr; 
            B1_enr = [aa 0 ; 0 aa]; 
            B2_enr = [0 0 ; 0 0]; 
            B3_enr = [0 0 ; 0 0]; 
            B4_enr = [0 0 ; 0 0];

            BI_enr = [B1_enr B2_enr B3_enr B4_enr];

            clear B1_enr; clear B2_enr; clear B3_enr; clear B4_enr;
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;

% ------------ Enriched by asymptotic functions -----------------------------------             
        elseif ( enrich_node(sctr(in)) == 22) % B(x)-H enriched node 

if (type_elem(e,cont) == 2) | (type_elem(e,cont) == 3)  %node in a split element
                BI_enr = [2*N(in)  0 ; 0   2*N(in)]; 
            else
              BI_enr = [0  0 ; 0   0];    
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;  

            if type_elem(e,1) == 1   %looking for the "tip" element
                ref_elem = e;
            else    %trovo l'elemento/fessura a cui fa riferimento il nodo (SOLO 1 RIF AUTORIZZATO!!)
                 [sctrn,xx] = find(element == sctr(in));
                [ele,xx]=find(type_elem(sctrn,:)==1);                
                if(isempty(ele)~=1)
                ref_elem = sctrn(ele);
                else   
                [sctrn1,xx1] = find(enrich_node(element(sctrn,:)) == 1);  
                node_p=[];
                for i=1:size(sctrn1,1)
                 node_p=[ node_p;element(sctrn(sctrn1(i)),xx1(i))]; 
                end 
                 for i=1:size(node_p,1)
                 [sctrn,xx] = find(element == node_p(i));
                 [ele,xx]=find(type_elem(sctrn,:)==1);  
                 ref_elem = sctrn(ele);
                 end  
                end 
            end                
            % compute branch functions at Gauss point
            xCre  = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];
            seg   = xCre(2,:) - xCre(1,:);
            alpha = atan2(seg(2),seg(1));
            xTip  = [xCre(2,1) xCre(2,2)];
            QT    = [cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
            xp    = QT*(Gpt-xTip)';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));  

            aa = 2*sqrt(r)*N(in)*rr; 
            B1_enr = [aa 0 ; 0 aa]; 
            B2_enr = [0 0 ; 0 0]; 
            B3_enr = [0 0 ; 0 0]; 
            B4_enr = [0 0 ; 0 0];

            BI_enr = [B1_enr B2_enr B3_enr B4_enr];

            clear B1_enr; clear B2_enr; clear B3_enr; clear B4_enr;
            Bxfem = [Bxfem BI_enr];
            clear BI_enr ;
         end

    end          % end of loop on nodes
    % B matrix
    Nc= [ Bfem Bxfem ];
    clear Bfem; clear Bxfem;
end              % end of switch between enriched and non-enriched elements 


    