function [xc0] = boundary_algorithm(kk,pt1,pt2,pt3,pt4,xCr,delta_inc,xc0,xc1)
global node element  

            vv = [pt1;pt2;pt3;pt4];
            flag1 = inhull(xc0,vv,[],1e-8) ; 
            
            if(flag1 == 1) % the tip is inside the body
                
              d1 = signed_distanceC(pt1,pt2,xc1,1); 
              d2 = signed_distanceC(pt2,pt3,xc1,1); 
              d3 = signed_distanceC(pt3,pt4,xc1,1); 
              d4 = signed_distanceC(pt4,pt1,xc1,1); 
              x=[abs(d1),abs(d2),abs(d3),abs(d4)];
              [a1,a2]=min(x); % the nearest boundary
              if(x(a2)<=delta_inc) 
               if(a2==1)
                   p1=pt1;p2=pt2;
               end
               if(a2==2)
                   p1=pt2;p2=pt3;
               end
               if(a2==3)
                   p1=pt3;p2=pt4;
               end
               if(a2==4)
                   p1=pt4;p2=pt1;
               end
               p3=xc1;
               p0=sum((p3-p1).*(p2-p1))/sum((p2-p1).*(p2-p1))*(p2-p1)+p1; 
               flag = segments_int_2d ( p1, p2, p3, p0); 
               if(flag(1)~=1)
                 disp([num2str(toc),'      the intersection of tip1 is wrong'])  
               end
               xc0= p0; % the intersection of the free boundary with the virtual extension of the crack  
              end
                  
              else % the intersection between the free boundary and the virtual extension. 
                flag = segments_int_2d ( pt1, pt2, xc1, xc0); 
                if(flag(1)==1)
                   xc0= [flag(2) flag(3)]; %  
                end
                  flag = segments_int_2d ( pt2, pt3, xc1, xc0); 
                if(flag(1)==1)
                   xc0= [flag(2) flag(3)]; %  
                end
                  flag = segments_int_2d ( pt3, pt4, xc1, xc0); 
                if(flag(1)==1)
                   xc0= [flag(2) flag(3)]; %  
                end
                  flag = segments_int_2d ( pt4, pt1, xc1, xc0); 
                if(flag(1)==1)
                   xc0= [flag(2) flag(3)]; %  
                end
            end   
  