function [f,g] = branch1_node(r,theta)
% Compute the branch functions spanning the near tip field for LEFM
% Inputs: 
%   (r,theta) : polar coordinates of points where the branch
%               functions are to be evaluated
%   alpha     : inclination of the crack tip segment w.r.t x axis

if( r ~=0 )
    r2 = sqrt(r);
else
    r2    = 0.1d-4;
    theta = 0.0d0 ;
end
 

% Functions   

        SQR  = sqrt(r);
        CT   = cos(theta);
        ST   = sin(theta);
        CT2  = cos(theta/2);
        ST2  = sin(theta/2);
        C3T2 = cos(3*theta/2);
        S3T2 = sin(3*theta/2);

                f(1) = 1/SQR*CT2*(1-ST2*S3T2);
                g(1) = -1/SQR*ST2*(2+CT2*C3T2);

                f(2) = 1/SQR*CT2*(1+ST2*S3T2);
                g(2) = 1/SQR*ST2*CT2*C3T2;

                f(3) = 1/SQR*ST2*CT2*C3T2; 
                g(3) = 1/SQR*CT2*(1-ST2*S3T2);  
                 
        
