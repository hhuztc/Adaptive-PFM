function sig_s_e = element_str(e,pos,enrich_node,u,cont) 

global node element vari_ele

if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
   end  
sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
  
 else
 sctr = element(e,:); 
  end  
 
nn   = length(sctr);

% stdU contains true nodal displacement
if cont == 1
idx = 0 ;
stdU   = zeros(3*nn,1);
for in = 1 : nn
    idx = idx + 1;
    nodeI = sctr(in) ;
    stdU(3*idx-2) = u(3*nodeI-2);
    stdU(3*idx-1) = u(3*nodeI-1);
    stdU(3*idx)   = u(3*nodeI  );
end
else 
    stdU = [];
end

% A contains enriched dofs
A = [];

if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
    sig_s_e = stdU ;
else                               % having enriched DOFs
    for in = 1 : nn
        nodeI = sctr(in) ;
        if (enrich_node(nodeI) == 2)     % H(x) enriched node
            AA = [u(3*pos(nodeI)-2);u(3*pos(nodeI)-1);u(3*pos(nodeI))];
            A  = [A;AA];
        elseif (enrich_node(nodeI) == 1 | enrich_node(nodeI) == 11) % B(x) enriched node
            AA = [u(3*pos(nodeI)-2);
                u(3*pos(nodeI)-1);
                u(3*pos(nodeI));
                u(3*(pos(nodeI)+1)-2);
                u(3*(pos(nodeI)+1)-1);
                u(3*(pos(nodeI)+1)); 
                ];
           A  = [A;AA];
        elseif (enrich_node(nodeI) == 3) %  
            AA = [u(3*pos(nodeI)-2);u(3*pos(nodeI)-1);
                u(3*pos(nodeI)); 
                ];
           A  = [A;AA];
         elseif (enrich_node(nodeI) == 22 | enrich_node(nodeI) == 12 ) % H(x)-B(x) enriched node
            AA = [u(3*pos(nodeI)-2);
                u(3*pos(nodeI)-1);
                u(3*pos(nodeI));
                u(3*(pos(nodeI)+1)-2);
                u(3*(pos(nodeI)+1)-1);
                u(3*(pos(nodeI)+1));
                u(3*(pos(nodeI)+2)-2);
                u(3*(pos(nodeI)+2)-1);
                u(3*(pos(nodeI)+2)); 
                ];
            A  = [A;AA];
        end
    end    
end

% total
sig_s_e  = [stdU;A];
