function U = element_disp(e,u,cont)

% From the unknowns vector u, extract the parameters
% associated with the element "e"
% Then epsilon = B*U

global node element vari_ele

if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
   end  
sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
  
 else
 sctr = element(e,:); 
  end  
 
nn   = length(sctr);

% stdU contains true nodal displacement
if cont == 1
idx = 0 ;
stdU   = zeros(2*nn,1);
for in = 1 : nn
    idx = idx + 1;
    nodeI = sctr(in) ;
    stdU(2*idx-1) = u(2*nodeI-1);
    stdU(2*idx)   = u(2*nodeI  );
end
else 
    stdU = [];
end

 
% total
U = [stdU];
