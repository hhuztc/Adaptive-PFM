
function [err,err1,str1]=new_error_estimator(numnode,numelem,xCr,enrich_node,elem_crk,type_elem,xTip,xVertex,xJertex,pos,u,C) 

global element elemType node vari_ele

% A posteriori error estimation for extended finite elements by an extended global recovery 

split = 0;%���Ƶ���Щ��Ԫ
tip = 0;%���Ƽ�˵ĵ�Ԫ
split_tip = 0;
junction=0;%����
tip1 = 0;
split_tip1 = 0;

for k = 1:size(xCr,2)
    tip = tip + size(find(enrich_node(:,k) == 1),1);
    split = split + size(find(enrich_node(:,k) == 2),1);
    junction = junction + size(find(enrich_node(:,k) == 3),1);
    split_tip = split_tip + size(find(enrich_node(:,k) == 12),1); 
    tip1 = tip1 + size(find(enrich_node(:,k) == 11),1);
    split_tip1 = split_tip1 + size(find(enrich_node(:,k) == 22),1);
end

ndof=2;
total_unknown1 = numnode*ndof + split*1*ndof+ tip*4*ndof + ...
        junction*1*ndof + split_tip*5*ndof+tip1*4*ndof +split_tip1*5*ndof ;
 %���е�δ֪�ڵ㣬����ԭ���ĵ�Ԫ�Ľڵ㣬�������������еĽڵ㣬������ԭ��Ԫ�����ӽڵ㣬���Ʒ�չ�������ĺ����ڵ�
            
KK = sparse(total_unknown1,total_unknown1);            
ff = zeros(total_unknown1,1);   
%�նȾ����������
% ***********************************
%    System matrix computation
% ***********************************

pos1 = posi2(xCr,numnode,enrich_node); %�������꣬�ڵ�����ϸ���Ľڵ� 

disp([num2str(toc),'   System matrix computation'])   
 
%  triangular ELEMENT  1,2,4,7

normal_order = 4;           
tip_order    = 7;           
split_order  = 4;          
vertex_order = 4;           
junction_order = 4;         
normal_tip_order=6;  
   
% -----------------
% Loop on elements
% ----------------- 
xy_gauss = []; 
for iel = 1 : numelem  
    sctr = element(iel,:); % element connectivity
    nodes=node(sctr,:);
    nn   = length(sctr);   % number of nodes per element
    ke   = 0 ;             % elementary stiffness matrix 
    % Choose Gauss quadrature rules for elements 
    
    [W,Q] = gauss_rule(iel,enrich_node,elem_crk,type_elem,xTip,xVertex,elemType,...
     normal_order,tip_order,split_order,vertex_order,junction_order,xJertex,0); % determine GP   
      
   % Transform these Gauss points to global coords for plotting only
   for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis(elemType,gpnt);
        Gpnt = N' * node(sctr,:); % global GP
       xy_gauss = [xy_gauss;Gpnt]; %all of the global GP
   end  
 
% Determine the position in the global matrix K
   sctrB = [];
   for k = 1:size(xCr,2)
       sctrB = [sctrB assembly2(iel,enrich_node(:,k),pos1(:,k),k)]; % globale
   end  

    % ---------------------
    % Loop on Gauss points   
    % ---------------------
        U = [];
       for k = 1:size(xCr,2)  
        U     = [U; element_disp(iel,pos(:,k),enrich_node(:,k),u,k)];
        end %k   

    for kk = 1 : size(W,1)
        
        pt = Q(kk,:);       % quadrature point 

    if(ismember(iel,vari_ele(:,1))) 
      for i=1:size(vari_ele,1)
        if(iel==vari_ele(i,1))
        itmp=i;
        break
        end
      end  
        local_shape=[];%��ڵ�ĵȲ�����  nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
       nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
     local_shape=[local_shape; exisp,etasp];  
       end
   end 
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;%��ڵ��κ���
    J0 = [nodes; nodes0]'*dNdxi;                 % element Jacobian matrix  
         else
        [N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
        J0 = node(sctr,:)'*dNdxi;                 % element Jacobian matrix 
        end 
        B_s = []; % to compute enhanced strain
        B_h = []; % to compute the original strain   
        for k = 1:size(xCr,2) 
        B_s = [B_s xfemBmatrix4(pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,xJertex,k)];            
        B_h = [B_h xfemBmatrix2(pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,xJertex,k)];             
        end %k   

        KK(sctrB,sctrB) = KK(sctrB,sctrB) + B_s'*B_s*W(kk)*det(J0);  % Stiffness matrix  
        ff(sctrB) =ff(sctrB)+B_s'*(B_h*U)*W(kk)*det(J0); 

    end                  % end of looping on GPs 
end                      % end of looping on elements  
 
% ------------------------------------- 
 %plot_GP(elemType,xy_gauss,xCr) % Plot GPs for checking 
 clear xy_gauss;

str_s = KK\ff ;   %KU=F

% **********************************
%     L2 norm error of the straines
% **********************************

err=zeros(numelem,1);str0=zeros(numelem,1);

for iel = 1 : numelem  

    sctr = element(iel,:); % element connectivity 
    nodes=node(sctr,:);
    area = polyarea(node(sctr,1),node(sctr,2)); %�������Щ�ڵ㹹�ɵĶ���ε����
    nn   = length(sctr);   % number of nodes per element
    ke   = 0 ;             % elementary stiffness matrix 
    % Choose Gauss quadrature rules for elements 

    [W,Q] = gauss_rule(iel,enrich_node,elem_crk,type_elem,xTip,xVertex,elemType,...
            normal_order,tip_order,split_order,vertex_order,junction_order,xJertex,0); % determine GP   
        
% Determine the position in the global matrix K
   sctrB = [];%����Ƕ���һ�����飬���ɺ�����Ԫ��
   for k = 1:size(xCr,2)%��xcr������
       sctrB = [sctrB assembly1(iel,enrich_node(:,k),pos1(:,k),k)]; % globale
   end  

       U = [];
       for k = 1:size(xCr,2)
        U     = [U; element_disp(iel,pos(:,k),enrich_node(:,k),u,k)];
       end

       sig_s_e = [];
       for k = 1:size(xCr,2)
       sig_s_e = [sig_s_e; element_strain(iel,pos1(:,k),enrich_node(:,k),str_s,k)];
       end
 
    % ---------------------
    % Loop on Gauss points   
    % ---------------------
    for kk = 1 : size(W,1) 
       
        pt = Q(kk,:);                             % quadrature point 

        if(ismember(iel,vari_ele(:,1))) 
      for i=1:size(vari_ele,1)
        if(iel==vari_ele(i,1))
        itmp=i;
        break
        end
      end  
        local_shape=[];   nodes0=[];
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
       nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
     local_shape=[local_shape; exisp,etasp];  
       end
   end 
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
    J0 = [nodes; nodes0]'*dNdxi;                 % element Jacobian matrix  
         else
        [N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
        J0 = node(sctr,:)'*dNdxi;                 % element Jacobian matrix 
        end 
        B_h = []; 
        B_s = [];
        for k = 1:size(xCr,2)  
        B_h = [B_h xfemBmatrix2(pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,xJertex,k)];             
        B_s = [B_s xfemBmatrix4(pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,xJertex,k)];            
        end %k  
         
       sig_h=(B_h*U) ;   
 
       sig_s=B_s*sig_s_e;

       err(iel)=err(iel)+(sig_s-sig_h)'*(sig_s-sig_h)*W(kk)*det(J0);%��ʽ30�Ļ��֣�ʹ�ø�˹�������
       str0(iel)=str0(iel)+(sig_s)'*(sig_s)*W(kk)*det(J0);  

    end                  % end of looping on GPs 
      err1(iel)=sqrt(err(iel)/area); %��ʽ30��area��Ӧ��
      str1(iel)=sqrt(str0(iel)/area); 
end                      % end of looping on elements 

