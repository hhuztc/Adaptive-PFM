function B = Kbar(pt,elemType,e,type_elem,enrich_node,xCrl,GVertex,cont,fac)
global node element 



 xyTip = [elem_crk(tip,3) elem_crk(tip,4)]; 

numnode = size(node,1);

 
sctr = element(tip_elem,:);
area = polyarea(node(sctr,1),node(sctr,2));  
 
radius = fac * sqrt(area);
center = xTip;

r=[];
% Distance from the center of tip element
for i = 1 : numnode
    sctr = node(i,:);
    rho  = sqrt((sctr(1)-center(1))^2+(sctr(2)-center(2))^2);
    r    = [r,rho];
end
test = r-radius;
test = test(element)';
test = max(test).*min(test);
Jdomain = find(test<=0);
test1 = r-radius;
test1 = test1(element(Jdomain,:))';
test1 = (test1<=0);
qnode = test1';

% checking if there is some B enriched elements in the Jdomain
for i=1:size(Jdomain,2)
    sctr = element (Jdomain(i),:);
    tip_enr = find(enrich_node(sctr,:) == 1);
    if size(tip_enr,1) > 0 
        disp('!!!WARNING!!! the Jdomain contain tip enriched elements => you should use a finer mesh')
        return % in order to not display the error message several times 
    end
end



%%%%% degree for numerical integration %%%%%%
normal_order = 2;          % max = 8
tip_order    = 7;          % max = 20
split_order  = 3;          % idem
vertex_order = 3;          % idem

for iel = 1 : numelem 
    sctr = element(iel,:); % element connectivity
    nn   = length(sctr);   % number of nodes per element
    ke   = 0 ;             % elementary stiffness matrix
    % -----------------------------------------------
    % Choose Gauss quadrature rules for elements

    [W,Q] = gauss_rule(iel,enrich_node,elem_crk,type_elem,xTip,xVertex,elemType,...
                            normal_order,tip_order,split_order,vertex_order); % determine GP 
       
    % -----------------------------------------------
    
    % -----------------------------------------------
    % Transform these Gauss points to global coords
    % for plotting only
   for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis(elemType,gpnt);
        Gpnt = N' * node(sctr,:); % global GP
        q = [q;Gpnt]; %all of the global GP
    end  
    % -----------------------------------------------
    
    % Stiffness matrix Ke = B^T C B
    % B = [ Bfem | Bxfem ]
    
    % The nodal parameters are stored in the following manner:
    % u = [u1 v1 u2 v2 ... un vn | a1 b1 ... an bn]';
    % It means that the additional unknowns are placed at the end of vector
    % u. Hence, the true nodal displacement is simply :
    % u_x = u(1:2:2*numnode) and u_y = u(2:2:2*numnode)
    
    % Determine the position in the global matrix K
   sctrB = [];
   for k = 1:size(xCr,2)
       sctrB = [sctrB assembly(iel,enrich_node(:,k),pos(:,k),k)]; % globale
   end %k

    % ---------------------
    % Loop on Gauss points   
    % ---------------------
    for kk = 1 : size(W,1)
        B = [];
        Bbar = [];
        pt = Q(kk,:);                             % quadrature point
        % Jacobian
        [N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
        J0 = node(sctr,:)'*dNdxi;                 % element Jacobian matrix
 
 
        invJ0 = inv(J0);
        dNdx  = dNdxi*invJ0;
        q     = qnode(iel,:);
        gradq = q*dNdx;
        gradqx=gradq*cos(alpha);
        gradqy=gradq*sin(alpha);

        % B matrix
        %one node can be related to more than one crack!!
        for k = 1:size(xCr,2) 
        B = [B xfemBmatrix(pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,k)];  % B matrix        
        Bbar = [Bbar xfemBbarmatrix(gradq,pt,elemType,iel,type_elem,enrich_node(:,k),elem_crk,xVertex,k,alpha)];  % B matrix      
        end %k
        % Stiffness matrix
        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);
    end                  % end of looping on GPs
end                      % end of looping on elements