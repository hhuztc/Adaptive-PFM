function B = xfemBmatrix2(pt,elemType,e,cont)
global node element vari_ele iflag_blend

if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
    end  
   sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
 else
 sctr = element(e,:); 
end 
  
nodes = node(element(e,:),:);

nn   = length(sctr);

if(ismember(e,vari_ele(:,1)))   % variable node element  
   local_shape=[];  nodes0=[];   
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
     local_shape=[local_shape; exisp,etasp]; 
 nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];  
       end
   end 
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
else 
  local_shape=[];
  [N,dNdxi] = shape_function_vari_ele(local_shape,pt);
end  

%[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions  

if(ismember(e,vari_ele(:,1))) 
Gpt = N' * [nodes; nodes0];  
J0 = [nodes; nodes0]'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY      
else
Gpt = N' * node(sctr,:);                  % GP in global coord, used 
J0 =  node(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
end
 
% Bfem is always computed at first crack affecting the node...
if cont == 1
    Bfem = zeros(3,2*nn);
    Bfem(1,1:2:2*nn)  = dNdx(:,1)' ;
    Bfem(2,2:2:2*nn)  = dNdx(:,2)' ;
    Bfem(3,1:2:2*nn)  = dNdx(:,2)' ;
    Bfem(3,2:2:2*nn)  = dNdx(:,1)' ;
else
    Bfem = [];
end
 
 
    B = Bfem;
 
 

