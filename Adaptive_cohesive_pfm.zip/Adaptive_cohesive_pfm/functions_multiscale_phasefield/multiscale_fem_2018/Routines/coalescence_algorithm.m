function [xCr] = coalescence_algorithm(kk,xCr,delta_inc,ktip)
global node element 

x=[];
 if(ktip==1) 
            for i=1:size(xCr,2)   
              if(i==kk)
               d1=1e9;
              else
               d1 = signed_distanceC(xCr(i).coor(1,:),xCr(i).coor(2,:),xCr(kk).coor(1,:),1); 
               end
               x=[x;abs(d1)];
            end 
               
              [a1,a2]=min(x); % the nearest crack
              
              xc=(xCr(a2).coor(1,:)+xCr(a2).coor(2,:))/2;

              if(sqrt((xCr(kk).coor(1,1)-xc(1))^2+ (xCr(kk).coor(1,2)-xc(2))^2)<=delta_inc)
              xCr(kk).coornew1= [xc(1) xc(2)]; %
              end   
               
 end %ktip==1
     
if(ktip==2)  
         for i=1:size(xCr,2)   
              if(i==kk)
               d1=1e9;
              else
               d1 = signed_distanceC(xCr(i).coor(1,:),xCr(i).coor(2,:),xCr(kk).coor(size(xCr(kk).coor,1),:),1); 
               end
               x=[x;abs(d1)];
            end 
               
              [a1,a2]=min(x); % the nearest crack
              
              xc=(xCr(a2).coor(1,:)+xCr(a2).coor(2,:))/2;

              if(sqrt((xCr(kk).coor(size(xCr(kk).coor,1),1)-xc(1))^2+ (xCr(kk).coor(size(xCr(kk).coor,1),2)-xc(2))^2)<=delta_inc)
              xCr(kk).coornew2= [xc(1) xc(2)]; %
              end   
            
end %ktip==2
   
xCr(kk).coor = [xCr(kk).coornew1;xCr(kk).coor;xCr(kk).coornew2] ; 