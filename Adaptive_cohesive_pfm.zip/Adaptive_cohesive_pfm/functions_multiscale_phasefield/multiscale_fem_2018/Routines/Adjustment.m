function [element_adjust]=Adjustment(e,fac_sub)
% e=143;  %% number of element need to adjust
% fac_sub=3;  %% number of subdivisions
% element_adjust: element information after adjustment 
global element node vari_ele

sctr  = element(e,:);
nodes = node(sctr,:);
nodes = [nodes;nodes(1,:)];
element_adjust=[];

if(ismember(e,vari_ele(:,1)))
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
            itmp=i;
            break
        end
    end
    nodes0=[];
    element0=[];
    for i=1:size(vari_ele(itmp,:),2)-1
        if(vari_ele(itmp,i+1)>0)
            nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
            element0=[element0 vari_ele(itmp,i+1)];
        end
    end
    
    for i=1:4
        x1=nodes(i,1);y1=nodes(i,2);
        x2=nodes(i+1,1);y2=nodes(i+1,2);
        xy=[];ele=[];
        for j=1:size(nodes0,1)
            x0=nodes0(j,1);
            y0=nodes0(j,2);
            if abs((x0-x1)*(y2-y1)-(y0-y1)*(x2-x1))<=1e-5
                xy=[xy;x0 y0];
                ele=[ele element0(j)];
            end
        end
        element_adjust=[element_adjust sctr(i)];
        if size(xy,1)>=1
            for k=1:fac_sub-1
                for l=1:size(xy,1)
                    if abs(sqrt((xy(l,1)-x1)^2+(xy(l,2)-y1)^2)-k/fac_sub*sqrt((x2-x1)^2+(y2-y1)^2))<=1e-5
                        element_adjust=[element_adjust ele(l)];
                    end
                end
            end
        end
    end
    
end

