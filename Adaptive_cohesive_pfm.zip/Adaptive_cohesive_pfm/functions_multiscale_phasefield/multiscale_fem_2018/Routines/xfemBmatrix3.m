function B = xfemBmatrix3(pt,elemType,e,type_elem,enrich_node,xCrl,GVertex,xJertex,cont)

global node element vari_ele iflag_blend  

if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
    end  
   sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
 else
 sctr = element(e,:); 
end 
  
nodes = node(element(e,:),:);

nn   = length(sctr);

if(ismember(e,vari_ele(:,1)))   % variable node element  
   local_shape=[];  nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
     local_shape=[local_shape; exisp,etasp];  
     nodes0=[nodes0;node(vari_ele(itmp,i+1),:)];
       end
   end 
   [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
else 
  local_shape=[];
  [N,dNdxi] = shape_function_vari_ele(local_shape,pt);
end  

%[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions 
if(ismember(e,vari_ele(:,1))) 
Gpt = N' * [nodes; nodes0];  
J0 = [nodes; nodes0]'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY      
else
Gpt = N' * node(sctr,:);                  % GP in global coord, used 
J0 =  node(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
end
 
if(cont==1)
    Bfem=[];  
    for i=1:nn
    Bfem1 = N(i)*eye(3); 
    Bfem=[ Bfem Bfem1];  
    end 
else
Bfem=[];
end
    
    if(iflag_blend==1)
     rr=0; 
     for ij=1:nn
     if(enrich_node(sctr(ij)) == 1) 
       rr=rr+N(ij) ; 
      end
      end   
     else
      rr=1; 
     end  

% Switch between non-enriched and enriched elements
if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements (for all cracks)
    B = Bfem; 
else                               % Enriched elements
    Bxfem = [] ; 
    % loop on nodes, check node is enriched ...
    for in = 1 : nn 
% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        if ( enrich_node(sctr(in)) == 2) 
            if (type_elem(e,cont) == 2) | (type_elem(e,cont) == 3)  %node in a split element
                ref_elem = e;
                xCre = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];  %each element has its crack!
                if (type_elem(e,cont) == 3)
                    distV = signed_distance(xCre,GVertex(ref_elem,:),0);
                    HV = sign(distV);
                    dist = signed_distance(xCre,Gpt,0);
                    Hgp  = sign(dist);
                    if HV * Hgp <= 0 %below or above the line relating the crack intersections?
                        Hgp = Hgp;
                    else 
                        vv = [xCre(1,:); xCre(2,:); GVertex(ref_elem,:)]; 
                        flag = inhull(Gpt,vv); % is the point in the triangle formed by the crack ends and the vertex?
                        if flag == 1     % yes
                            Hgp =- Hgp;
                        else             % no
                            Hgp =  Hgp;
                        end
                    end
                    dist = signed_distance(xCre,node(sctr(in),:),0); % nodes are always outside the triangle..easy!
                    Hi  = sign(dist);
                else %
                    % Enrichment function, H(x) at global Gauss point
                    dist = signed_distance(xCre,Gpt,16); 
                    Hgp  = sign(dist);
                    % Enrichment function, H(x) at node "in"
                    dist = signed_distance(xCre,node(sctr(in),:),0);  
                    Hi   = sign(dist);   

                end % is vertex 
                
                BI_enr = (Hgp - Hi)* N(in) * eye(3); 
            else    %if the element is not cut by a crack, the enrichment is always 0
                BI_enr = [0 0 0; 0 0 0; 0 0 0]; 
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr]; 
            clear BI_enr ;  

% ---------  Enriched by H(x) at global Gauss point ---------------------------------------        
        elseif ( enrich_node(sctr(in)) == 3) 
            if (type_elem(e,cont) == 4  )   % junction
                ref_elem = e;
                xCreM= [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];     %each element has its crack!
                xCrem= [xJertex(ref_elem,1) xJertex(ref_elem,2);xJertex(ref_elem,3) xJertex(ref_elem,4)];
                 x0=[xJertex(ref_elem,1) xJertex(ref_elem,2)];

                    distV = signed_distance(xCreM,node(sctr(in),:),0); 
                    dist = signed_distance(xCreM,Gpt,0); 

                    if  distV * dist > 0   
                       Hgp=sign(dist); ;
                       Hi=sign(distV);
                    else 
                      dist = signed_distance(xCrem,Gpt,0);
                      Hgp= sign(dist); 
                      dist = signed_distance(xCrem,node(sctr(in),:),0);  
                      Hi  = sign(dist);  
                    end  

                % Bxfem at node "in"
                 BI_enr = (Hgp - Hi)* N(in) * eye(3); 
            else    %if the element is not cut by a crack, the enrichment is always 0
                BI_enr = [0 0 0; 0 0 0; 0 0 0]; 
            end
            % Add to the total Bxfem
            Bxfem = [Bxfem BI_enr]; 
            clear BI_enr ;  
            
% ------------ Enriched by asymptotic functions -----------------------------------             
       elseif ( enrich_node(sctr(in)) == 1 | enrich_node(sctr(in)) == 11) % B(x) enriched node 
            %looking for the "tip" element 
            if type_elem(e,1) == 1
                ref_elem = e;
            else  
                [sctrn,xx] = find(element == sctr(in));
                [ele,xx]=find(type_elem(sctrn,:)==1);                
                if(isempty(ele)~=1)
                ref_elem = sctrn(ele);
                else   
                [sctrn1,xx1] = find(enrich_node(element(sctrn,:)) == 1);  
                node_p=[];
                for i=1:size(sctrn1,1)
                 node_p=[ node_p;element(sctrn(sctrn1(i)),xx1(i))]; 
                end 
                 for i=1:size(node_p,1)
                 [sctrn,xx] = find(element == node_p(i));
                 [ele,xx]=find(type_elem(sctrn,:)==1);  
                 ref_elem = sctrn(ele);
                 end  
                end 
            end  

            % compute branch functions at Gauss point
            xCre = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];
            seg   = xCre(2,:) - xCre(1,:);
            alpha = atan2(seg(2),seg(1));
            xTip = [xCre(2,1) xCre(2,2)];
            QT  =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
            xp    = QT*(Gpt-xTip)';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
            theta = atan2(xp(2),xp(1));
            if ( theta > pi | theta < -pi)
                disp (['something wrong with angle ',num2str(thet)]);
            end
            [f1,g1] = branch1_node(r,theta);
            % compute branch functions at node "in"
            xp    = QT*(node(sctr(in),:)-xTip)';
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
            theta = atan2(xp(2),xp(1));
            if ( theta > pi | theta < -pi)
                disp (['something wrong with angle ',num2str(thet)]);
            end
            [f2,g2] = branch1_node(r,theta);

             % composants of Benr matrix  
            aa1 = N(in)*(f1(1)-f2(1))*rr ; 
            aa2 = N(in)*(f1(2)-f2(2))*rr ; 
            aa3 = N(in)*(f1(3)-f2(3))*rr ; 
            B_enr1 = [aa1 0 0; 0 aa2 0; 0 0 aa3];   
            aa4 = N(in)*(g1(1)-g2(1))*rr ; 
            aa5 = N(in)*(g1(2)-g2(2))*rr ; 
            aa6 = N(in)*(g1(3)-g2(3))*rr ; 
            B_enr2 = [aa4 0 0; 0 aa5 0; 0 0 aa6]; 
            BI_enr = [B_enr1 B_enr2];   

            Bxfem = [Bxfem BI_enr]; 
            clear BI_enr ;   

% ------------ Enriched by asymptotic and H functions -----------------------------------             
       elseif ( enrich_node(sctr(in)) == 22 | enrich_node(sctr(in)) == 12) % B(x) enriched node
 if (type_elem(e,cont) == 2) | (type_elem(e,cont) == 3)  %node in a split element
                ref_elem = e;
                xCre = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];                 %each element has its crack!
                if (type_elem(e,cont) == 3)
                    distV = signed_distance(xCre,GVertex(ref_elem,:),0);
                    HV = sign(distV);
                    dist = signed_distance(xCre,Gpt,0);
                    Hgp  = sign(dist);
                    if HV * Hgp <= 0 %below or above the line relating the crack intersections?
                        Hgp = Hgp;
                    else 
                        vv = [xCre(1,:); xCre(2,:); GVertex(ref_elem,:)]; 
                        flag = inhull(Gpt,vv); % is the point in the triangle formed by the crack ends and the vertex?
                        if flag == 1     % yes
                            Hgp =- Hgp;
                        else             % no
                            Hgp =  Hgp;
                        end
                    end
                    dist = signed_distance(xCre,node(sctr(in),:),0); % nodes are always outside the triangle..easy!
                    Hi  = sign(dist);
                else %
                    % Enrichment function, H(x) at global Gauss point
                    dist = signed_distance(xCre,Gpt,16); 
                    Hgp  = sign(dist);
                    % Enrichment function, H(x) at node "in"
                    dist = signed_distance(xCre,node(sctr(in),:),0);
                    Hi   = sign(dist);      
                end % is vertex
                % Bxfem at node "in"
                BI_enr = (Hgp - Hi)* N(in) * eye(3); 
            else    %if the element is not cut by a crack, the enrichment is always 0
                BI_enr = [0 0 0; 0 0 0; 0 0 0];
            end 
            Bxfem = [Bxfem BI_enr]; 
            clear BI_enr ;

            %looking for the "tip" element 
            
            if type_elem(e,1) == 1
                ref_elem = e;
            else %trovo l'elemento/fessura a cui fa riferimento il nodo (SOLO 1 RIF AUTORIZZATO!!)
               
                [sctrn,xx] = find(element == sctr(in));
                [ele,xx]=find(type_elem(sctrn,:)==1);                
                if(isempty(ele)~=1)
                ref_elem = sctrn(ele);
                else   
                [sctrn1,xx1] = find(enrich_node(element(sctrn,:)) == 1);  
                node_p=[];
                for i=1:size(sctrn1,1)
                 node_p=[ node_p;element(sctrn(sctrn1(i)),xx1(i))]; 
                end 
                 for i=1:size(node_p,1)
                 [sctrn,xx] = find(element == node_p(i));
                 [ele,xx]=find(type_elem(sctrn,:)==1);  
                 ref_elem = sctrn(ele);
                 end  
                end 
            end  
            
            % compute branch functions at Gauss point
            xCre = [xCrl(ref_elem,1) xCrl(ref_elem,2); xCrl(ref_elem,3) xCrl(ref_elem,4)];
            seg   = xCre(2,:) - xCre(1,:);
            alpha = atan2(seg(2),seg(1));
            xTip = [xCre(2,1) xCre(2,2)];
            QT  =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
            xp    = QT*(Gpt-xTip)';           % local coordinates
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
            theta = atan2(xp(2),xp(1));
            if ( theta > pi | theta < -pi)
                disp (['something wrong with angle ',num2str(thet)]);
            end
            [f1,g1] = branch1_node(r,theta);
            % compute branch functions at node "in"
            xp    = QT*(node(sctr(in),:)-xTip)';
            r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
            theta = atan2(xp(2),xp(1));
            if ( theta > pi | theta < -pi)
                disp (['something wrong with angle ',num2str(thet)]);
            end
            [f2,g2] = branch1_node(r,theta);


            % composants of Benr matrix  
             % composants of Benr matrix  
            aa1 = N(in)*(f1(1)-f2(1))*rr ; 
            aa2 = N(in)*(f1(2)-f2(2))*rr ; 
            aa3 = N(in)*(f1(3)-f2(3))*rr ; 
            B_enr1 = [aa1 0 0; 0 aa2 0; 0 0 aa3];   
            aa4 = N(in)*(g1(1)-g2(1))*rr ; 
            aa5 = N(in)*(g1(2)-g2(2))*rr ; 
            aa6 = N(in)*(g1(3)-g2(3))*rr ; 
            B_enr2 = [aa4 0 0; 0 aa5 0; 0 0 aa6]; 
            BI_enr = [B_enr1 B_enr2];    

            Bxfem = [Bxfem BI_enr]; 
            clear BI_enr ;
        end
    end          % end of loop on nodes
    % B matrix
    B = [ Bfem Bxfem ];  
    clear Bfem; clear Bxfem;
end              % end of switch between enriched and non-enriched elements

