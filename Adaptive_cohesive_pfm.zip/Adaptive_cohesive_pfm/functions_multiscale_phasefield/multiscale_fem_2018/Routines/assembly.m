function sctrB = assembly(e,cont)

global node element split_elem vari_ele


if(ismember(e,vari_ele(:,1)))   % variable node element
    for i=1:size(vari_ele,1)
        if(e==vari_ele(i,1))
        itmp=i;
        break
        end
   end  
sctr = [element(e,:) ]; 
 for j=2:size(vari_ele,2)
 if(vari_ele(itmp,j)>0)
 sctr = [sctr vari_ele(itmp,j)]; 
 end
 end
 else
 sctr = element(e,:); 
  end  
 
nn   = length(sctr);

if cont == 1
 for k = 1 : nn
    sctrBfem(2*k-1) = 2*sctr(k)-1 ;
    sctrBfem(2*k)   = 2*sctr(k)   ;
 end
else
   sctrBfem = [];
end 
 
     
    sctrB = [ sctrBfem   ];
 
