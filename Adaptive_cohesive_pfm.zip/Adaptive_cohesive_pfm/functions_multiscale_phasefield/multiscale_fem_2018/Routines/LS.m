function [ls] = LS(iel,elem_crk)

% give the distance (vector) of the orthogonale projection of each point of the element iel   

% ls = 0 if this distance is smaller that the tolerance (tol_ratio *
%                                 average size of element's boundary)

global node element
sctr = element(iel,:);

tol_ratio = 1/1000;    % ratio phi_min/phi_max 

x0  = elem_crk(iel,1); y0 = elem_crk(iel,2);
x1  = elem_crk(iel,3); y1 = elem_crk(iel,4);

for i = 1 : size(sctr,2)
    x = node(sctr(i),1);
    y = node(sctr(i),2);
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi;            % normal LS
end 

ratio =  min(abs(ls)) / max(abs(ls)) ;

for j = 1 : size(sctr,2)
    if abs(ls(j,1)) < (tol_ratio * max(abs(ls)))
        ls(j,1) = 0;
        disp('the crack is considered being on the node for quadrature')
    end
end

ratio =  min(abs(ls)) / max(abs(ls)) ;




%%%%%%% Projector
%     xp=(x0*y1^2-x1*y1*y0-y1*x0*y-x0*y1*y0+y1*x1*y+x1^2*x+x1*y0^2+x0*y0*y-2*x1*x0*x-x1*y0*y+x0^2*x)/(y1^2-2*y1*y0+y0^2+x1^2-2*x1*x0+x0^2);
%     yp=(y1*x1*x-y1*x0*x-y0*x1*x+y1^2*y+y1*x0^2-2*y1*y0*y-x0*x1*y0+y0*x0*x+y0^2*y+x1^2*y0-x1*y1*x0)/(y1^2-2*y1*y0+y0^2+x1^2-2*x1*x0+x0^2);
%     phi3= ((x-xp)^2+(y-yp)^2)^0.5;
    %phi2   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0))   
    %interessano i rapporti e i segni di phi...
%         ls(i,1)= phi3*sign(phi);