function [N_vari,dN_varidxi] = shape_function_vari_ele(local_shape,pt)
 
np=size(local_shape,1)+4;
a=zeros(np,np); 
 
if(size(local_shape)==[0 0])
kesi=[ -1 1 1 -1 ];
 eta=[ -1 -1 1 1 ];
else
kesi=[ -1 1 1 -1 local_shape(:,1)'];
 eta=[ -1 -1 1 1 local_shape(:,2)'];
end

 a(1,:)=[ones(1,np)];
 a(2,:)=[kesi];
 a(3,:)=[eta];
 a(4,:)=kesi.*eta; %���׹�ʽ8��q����
 
  for i=1:size(local_shape,1)  
%localshape(:,1) is kesi;localshape(:,2) is eta
 if(abs(local_shape(i,2)+1)<1e-5 || abs(local_shape(i,2)-1)<1e-5)   %����ƽ���Ĺ�ʽ4.14
    a(4+i,:)=abs(kesi-local_shape(i,1)).*(eta+sign(local_shape(i,2))); 
   elseif(abs(local_shape(i,1)+1)<1e-5 || abs(local_shape(i,1)-1)<1e-5) 
    a(4+i,:)=abs(eta-local_shape(i,2)).*(kesi+sign(local_shape(i,1))); 
   end 

  end

   b=inv(a);%����
  
   c=zeros(np,1); c1=zeros(np,1); c2=zeros(np,1); 
   c(1)=1;  c(2)=pt(1);  c(3)=pt(2);  c(4)=pt(1)*pt(2);%pt(1)is kesi;pt(2)is eta
   c1(1)=0;  c1(2)=1;  c1(3)=0;  c1(4)=pt(2);
   c2(1)=0;  c2(2)=0;  c2(3)=1;  c2(4)=pt(1);
   for i=1:size(local_shape,1) 

   if(abs(local_shape(i,2)+1)<1e-5 || abs(local_shape(i,2)-1)<1e-5) 
     c(4+i)=abs(pt(1)-local_shape(i,1))*(pt(2)+sign(local_shape(i,2)));
     c1(4+i)=sign(pt(1)-local_shape(i,1))*(pt(2)+sign(local_shape(i,2)));
     c2(4+i)=abs(pt(1)-local_shape(i,1));
   elseif(abs(local_shape(i,1)+1)<1e-5 || abs(local_shape(i,1)-1)<1e-5)
     c(4+i)=abs(pt(2)-local_shape(i,2))*(pt(1)+sign(local_shape(i,1)));
     c1(4+i)=abs(pt(2)-local_shape(i,2));
     c2(4+i)=sign(pt(2)-local_shape(i,2))*(pt(1)+sign(local_shape(i,1))); 
   end 

  end

   N_vari=b*c;

dN_varidxi=[b*c1 b*c2];

