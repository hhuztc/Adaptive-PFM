function [vari_ele]=vari_ele_generate2(ele_sub,fac_sub,boundaryNodes) 
 
global node  element  elemType

numelem=size(element,1);
numnode=size(node,1); 
numnode0=size(node,1);  

for ie=1:size(ele_sub,2) 
 e=ele_sub(ie); 
 sctr=element(e,:);
 nn=length(sctr);  
 xy=[]; 
 repeatnode_node=zeros((fac_sub-1)*(fac_sub+3),1); 
 numnode=size(node,1); 
 numele=size(element,1);

   k=0;
  for i=1:nn % added nodes at the four edges

  if(i==nn)
  x1=node(sctr(i),1); y1=node(sctr(i),2);
  x2=node(sctr(1),1); y2=node(sctr(1),2);
  else
  x1=node(sctr(i),1); y1=node(sctr(i),2);
  x2=node(sctr(i+1),1); y2=node(sctr(i+1),2); 
  end  
     
    for i0=1:fac_sub-1 
     x0= x1+(x2-x1)/fac_sub*i0;
     y0= y1+(y2-y1)/fac_sub*i0;
     k=k+1;
     xy(k,1)=x0; 
     xy(k,2)=y0;  
     
     for i1=numnode0+1:numnode
     if((node(i1,1)-x0)^2+(node(i1,2)-y0)^2<1e-8)  
     repeatnode_node(k)=i1; 
     end
     end  

    end % for i0
  
  end   % for i 

  for i=1:fac_sub-1 % add nodes in the element
  p1=xy(i,:) ; p2=xy(2*(fac_sub-1)+fac_sub-i,:);
  for j=1:fac_sub-1
  q1=xy(fac_sub-1+j,:) ; q2=xy(3*(fac_sub-1)+fac_sub-j,:);
  [ ival, p ] = lines_exp_int_2d ( p1, p2, q1, q2 );
   k=k+1; 
   xy(k,:)=p; 
  end
  end  

  k=0;  
  for i=1:size(xy,1)
   if(repeatnode_node(i)==0)
    k=k+1;
   node(numnode+k,:)=xy(i,:);
   end
  end   

  if(fac_sub==2) 
      k=0;
      lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
     if(repeatnode_node(i)==0) 
        k=k+1;
       lab(i)=numnode+k;
     else
       lab(i)=repeatnode_node(i);
      end  
     end
  
 element(e,:)=[sctr(1) lab(1) lab(5) lab(4)]; 
 element(numele+1,:)=[lab(1) sctr(2) lab(2) lab(5)];
 element(numele+2,:)=[lab(4) lab(5) lab(3) sctr(4)];
 element(numele+3,:)=[lab(5) lab(2) sctr(3) lab(3)];

 elseif(fac_sub==3)
      k=0;
     lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
        if(repeatnode_node(i)==0) 
          k=k+1;
          lab(i)=numnode+k;
           else
         lab(i)=repeatnode_node(i);
        end  
      end
 element(e,:)=[sctr(1) lab(1) lab(9) lab(8)];
 element(numele+1,:)=[ lab(1) lab(2) lab(11) lab(9)];
 element(numele+2,:)=[lab(2) sctr(2) lab(3) lab(11)];
 element(numele+3,:)=[lab(8) lab(9) lab(10) lab(7)]; 
 element(numele+4,:)=[lab(9) lab(11) lab(12) lab(10)];
 element(numele+5,:)=[lab(11) lab(3) lab(4) lab(12)];
 element(numele+6,:)=[lab(7) lab(10) lab(6) sctr(4)];
 element(numele+7,:)=[lab(10) lab(12) lab(5) lab(6)];
 element(numele+8,:)=[lab(12) lab(4) sctr(3) lab(5)];

elseif(fac_sub==4)
      k=0;
     lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
        if(repeatnode_node(i)==0) 
          k=k+1;
          lab(i)=numnode+k;
           else
         lab(i)=repeatnode_node(i);
        end  
      end
  element(e,:)=[sctr(1) lab(1) lab(13) lab(12)];
 element(numele+1,:)=[ lab(1) lab(2) lab(16) lab(13)];
 element(numele+2,:)=[lab(2) lab(3) lab(19) lab(16)];
 element(numele+3,:)=[lab(3) sctr(2) lab(4) lab(19)]; 

 element(numele+4,:)=[lab(12) lab(13) lab(14) lab(11)];
 element(numele+5,:)=[lab(13) lab(16) lab(17) lab(14)];
 element(numele+6,:)=[lab(16) lab(19) lab(20) lab(17)];
 element(numele+7,:)=[lab(19) lab(4) lab(5) lab(20)];

 element(numele+8,:)=[lab(11) lab(14) lab(15) lab(10)];
 element(numele+9,:)=[lab(14) lab(17) lab(18) lab(15)];
 element(numele+10,:)=[lab(17) lab(20) lab(21) lab(18)];
 element(numele+11,:)=[lab(20) lab(5) lab(6) lab(21)];

 element(numele+12,:)=[lab(10) lab(15) lab(9) sctr(4)];
 element(numele+13,:)=[lab(15) lab(18) lab(8) lab(9)];
 element(numele+14,:)=[lab(18) lab(21) lab(7) lab(8)];
 element(numele+15,:)=[lab(21) lab(6) sctr(3) lab(7)];

 elseif(fac_sub==5)
      k=0;
     lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
        if(repeatnode_node(i)==0) 
          k=k+1;
          lab(i)=numnode+k;
           else
         lab(i)=repeatnode_node(i);
        end  
      end

 element(e,:)=[sctr(1) lab(1) lab(17) lab(16)];
 element(numele+1,:)=[ lab(1) lab(2) lab(21) lab(17)];
 element(numele+2,:)=[lab(2) lab(3) lab(25) lab(21)];
 element(numele+3,:)=[lab(3) lab(4) lab(29) lab(25)]; 
 element(numele+4,:)=[lab(4) sctr(2) lab(5) lab(29)];

 element(numele+5,:)=[lab(16) lab(17) lab(18) lab(15)];
 element(numele+6,:)=[lab(17) lab(21) lab(22) lab(18)];
 element(numele+7,:)=[lab(21) lab(25) lab(26) lab(22)];
 element(numele+8,:)=[lab(25) lab(29) lab(30) lab(26)];
 element(numele+9,:)=[lab(29) lab(5) lab(6) lab(30)];

 element(numele+10,:)=[lab(15) lab(18) lab(19) lab(14)];
 element(numele+11,:)=[lab(18) lab(22) lab(23) lab(19)];
 element(numele+12,:)=[lab(22) lab(26) lab(27) lab(23)];
 element(numele+13,:)=[lab(26) lab(30) lab(31) lab(27)];
 element(numele+14,:)=[lab(30) lab(6) lab(7) lab(31)];

 element(numele+15,:)=[lab(14) lab(19) lab(20) lab(13)];
 element(numele+16,:)=[lab(19) lab(23) lab(24) lab(20)];
 element(numele+17,:)=[lab(23) lab(27) lab(28) lab(24)];
 element(numele+18,:)=[lab(27) lab(31) lab(32) lab(28)];
 element(numele+19,:)=[lab(31) lab(7) lab(8) lab(32)];

 element(numele+20,:)=[lab(13) lab(20) lab(12) sctr(4)];
 element(numele+21,:)=[lab(20) lab(24) lab(11) lab(12)];
 element(numele+22,:)=[lab(24) lab(28) lab(10) lab(11)];
 element(numele+23,:)=[lab(28) lab(32) lab(9) lab(10)];
 element(numele+24,:)=[lab(32) lab(8) sctr(3) lab(9)];

 elseif(fac_sub==7)
      k=0;
     lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
        if(repeatnode_node(i)==0) 
          k=k+1;
          lab(i)=numnode+k;
           else
         lab(i)=repeatnode_node(i);
        end  
      end

 element(e,:)=[sctr(1) lab(1) lab(25) lab(24)];
 element(numele+1,:)=[ lab(1) lab(2) lab(31) lab(25)];
 element(numele+2,:)=[lab(2) lab(3) lab(37) lab(31)];
 element(numele+3,:)=[lab(3) lab(4) lab(43) lab(37)]; 
 element(numele+4,:)=[lab(4) lab(5) lab(49) lab(43)];
 element(numele+5,:)=[lab(5) lab(6) lab(55) lab(49)];
 element(numele+6,:)=[lab(6) sctr(2) lab(7) lab(55)];

 element(numele+7,:)=[lab(24) lab(25) lab(26) lab(23)];
 element(numele+8,:)=[lab(25) lab(31) lab(32) lab(26)];
 element(numele+9,:)=[lab(31) lab(37) lab(38) lab(32)];
 element(numele+10,:)=[lab(37) lab(43) lab(44) lab(38)];
 element(numele+11,:)=[lab(43) lab(49) lab(50) lab(44)];
 element(numele+12,:)=[lab(49) lab(55) lab(56) lab(50)];
 element(numele+13,:)=[lab(55) lab(7) lab(8) lab(56)];

 element(numele+14,:)=[lab(23) lab(26) lab(27) lab(22)];
 element(numele+15,:)=[lab(26) lab(32) lab(33) lab(27)];
 element(numele+16,:)=[lab(32) lab(38) lab(39) lab(33)];
 element(numele+17,:)=[lab(38) lab(44) lab(45) lab(39)];
 element(numele+18,:)=[lab(44) lab(50) lab(51) lab(45)];
 element(numele+19,:)=[lab(50) lab(56) lab(57) lab(51)];
 element(numele+20,:)=[lab(56) lab(8) lab(9) lab(57)];

 element(numele+21,:)=[lab(22) lab(27) lab(28) lab(21)];
 element(numele+22,:)=[lab(27) lab(33) lab(34) lab(28)];
 element(numele+23,:)=[lab(33) lab(39) lab(40) lab(34)];
 element(numele+24,:)=[lab(39) lab(45) lab(46) lab(40)];
 element(numele+25,:)=[lab(45) lab(51) lab(52) lab(46)];
 element(numele+26,:)=[lab(51) lab(57) lab(58) lab(52)];
 element(numele+27,:)=[lab(57) lab(9) lab(10) lab(58)];

 element(numele+28,:)=[lab(21) lab(28) lab(29) lab(20)];
 element(numele+29,:)=[lab(28) lab(34) lab(35) lab(29)];
 element(numele+30,:)=[lab(34) lab(40) lab(41) lab(35)];
 element(numele+31,:)=[lab(40) lab(46) lab(47) lab(41)];
 element(numele+32,:)=[lab(46) lab(52) lab(53) lab(47)];
 element(numele+33,:)=[lab(52) lab(58) lab(59) lab(53)];
 element(numele+34,:)=[lab(58) lab(10) lab(11) lab(59)];

 element(numele+35,:)=[lab(20) lab(29) lab(30) lab(19)];
 element(numele+36,:)=[lab(29) lab(35) lab(36) lab(30)];
 element(numele+37,:)=[lab(35) lab(41) lab(42) lab(36)];
 element(numele+38,:)=[lab(41) lab(47) lab(48) lab(42)];
 element(numele+39,:)=[lab(47) lab(53) lab(54) lab(48)];
 element(numele+40,:)=[lab(53) lab(59) lab(60) lab(54)];
 element(numele+41,:)=[lab(59) lab(11) lab(12) lab(60)];

 element(numele+42,:)=[lab(19) lab(30) lab(18) sctr(4)];
 element(numele+43,:)=[lab(30) lab(36) lab(17) lab(18)];
 element(numele+44,:)=[lab(36) lab(42) lab(16) lab(17)];
 element(numele+45,:)=[lab(42) lab(48) lab(15) lab(16)];
 element(numele+46,:)=[lab(48) lab(54) lab(14) lab(15)];
 element(numele+47,:)=[lab(54) lab(60) lab(13) lab(14)];
 element(numele+48,:)=[lab(60) lab(12) sctr(3) lab(13)];

 elseif(fac_sub==6)
      k=0;
     lab=[];
      for i=1:(fac_sub-1)*(fac_sub+3)
        if(repeatnode_node(i)==0) 
          k=k+1;
          lab(i)=numnode+k;
           else
         lab(i)=repeatnode_node(i);
        end  
      end
  element(e,:)=[sctr(1) lab(1) lab(21) lab(20)];
 element(numele+1,:)=[ lab(1) lab(2) lab(26) lab(21)];
 element(numele+2,:)=[lab(2) lab(3) lab(31) lab(26)];
 element(numele+3,:)=[lab(3) lab(4) lab(36) lab(31)]; 
 element(numele+4,:)=[lab(4) lab(5) lab(41) lab(36)];
 element(numele+5,:)=[lab(5) sctr(2) lab(6) lab(41)];

 element(numele+6,:)=[lab(20) lab(21) lab(22) lab(19)];
 element(numele+7,:)=[lab(21) lab(26) lab(27) lab(22)];
 element(numele+8,:)=[lab(26) lab(31) lab(32) lab(27)];
 element(numele+9,:)=[lab(31) lab(36) lab(37) lab(32)];
 element(numele+10,:)=[lab(36) lab(41) lab(42) lab(37)];
 element(numele+11,:)=[lab(41) lab(6) lab(7) lab(42)];

 element(numele+12,:)=[lab(19) lab(22) lab(23) lab(18)];
 element(numele+13,:)=[lab(22) lab(27) lab(28) lab(23)];
 element(numele+14,:)=[lab(27) lab(32) lab(33) lab(28)];
 element(numele+15,:)=[lab(32) lab(37) lab(38) lab(33)];
 element(numele+16,:)=[lab(37) lab(42) lab(43) lab(38)];
 element(numele+17,:)=[lab(42) lab(7) lab(8) lab(43)];

 element(numele+18,:)=[lab(18) lab(23) lab(24) lab(17)];
 element(numele+19,:)=[lab(23) lab(28) lab(29) lab(24)];
 element(numele+20,:)=[lab(28) lab(33) lab(34) lab(29)];
 element(numele+21,:)=[lab(33) lab(38) lab(39) lab(34)];
 element(numele+22,:)=[lab(38) lab(43) lab(44) lab(39)];
 element(numele+23,:)=[lab(43) lab(8) lab(9) lab(44)];

 element(numele+24,:)=[lab(17) lab(24) lab(25) lab(16)];
 element(numele+25,:)=[lab(24) lab(29) lab(30) lab(25)];
 element(numele+26,:)=[lab(29) lab(34) lab(35) lab(30)];
 element(numele+27,:)=[lab(34) lab(39) lab(40) lab(35)];
 element(numele+28,:)=[lab(39) lab(44) lab(45) lab(40)];
 element(numele+29,:)=[lab(44) lab(9) lab(10) lab(45)];

element(numele+30,:)=[lab(16) lab(25) lab(15) sctr(4)];
 element(numele+31,:)=[lab(25) lab(30) lab(14) lab(15)];
 element(numele+32,:)=[lab(30) lab(35) lab(13) lab(14)];
 element(numele+33,:)=[lab(35) lab(40) lab(12) lab(13)];
 element(numele+34,:)=[lab(40) lab(45) lab(11) lab(12)];
 element(numele+35,:)=[lab(45) lab(10) sctr(3) lab(11)];
end

 end % for ie   

 for i=1:size(element,1)
 sctr=element(i,:) ;
 j=size(intersect(sctr,boundaryNodes),2);
 if(j>0)
 lab_ele(i,:)=[i j-1];
 else
 lab_ele(i,:)=[i 0];
  end
  end 
 
 [vari_ele]=vari_ele_infor(lab_ele);  
