
function [sigx,sigy,sigxy] = exact_stress(xx,a,p,t,coef,xtip)


  x=xx(1,1);
  y=xx(1,2); 

 m=x^2-y^2-a^2;
 n=2*x*y;

 theta=-atan2(n,m) ; 

 tt=sqrt(m^2+n^2);

 sigx=(t-coef*p)/sqrt(tt)*(2*(y*cos(theta/2)+x*sin(theta/2))-...
     y*a^2/tt^2*(m*cos(theta/2)+n*sin(theta/2)));

 sigy=y*a^2*(t-coef*p)/sqrt(tt)/tt^2*(m*cos(theta/2)+n*sin(theta/2))-p;

 sigxy=(t-coef*p)/sqrt(tt)*((x*cos(theta/2)-y*sin(theta/2))+...
     y*a^2/tt^2*(m*sin(theta/2)-n*cos(theta/2)))+coef*p;
 
 



