function [delta_x delta_y] = symmetrie(u_x,u_y,numnode,nnx)

global node

% function to test if the displacement are symmetrics : see the messages
% it also give relative error of the symmetrie (see delta_x and delta_y in %)

u_x = single(u_x);    %to erase the machine precision effect
u_y = single(u_y);
delta_x=[];
delta_y=[];
for hihi = 1:numnode
    bbb = floor((hihi-1)/nnx);
    ccc = hihi - nnx * bbb ;
    delta_x(hihi) = abs(100*(u_x(bbb*nnx + ccc) + u_x((bbb+1)*nnx - (ccc-1)))/(u_x(bbb*nnx + ccc)+0.00000000000000001));
    delta_y(hihi) = abs(100*(u_y(bbb*nnx + ccc) - u_y((bbb+1)*nnx - (ccc-1)))/(u_y(bbb*nnx + ccc)+0.00000000000000001));
end

delta_x = delta_x';
delta_y = delta_y';

if (delta_x < 0.1) & (delta_y < 0.1) 
    disp('Symetric displacement')
else
    disp('!!! WARNING !!! the displacement are not symmetrics')
end

% tri = delaunay(node(:,1),node(:,2));
% figure
% trisurf(tri,node(:,1),node(:,2),delta_x) 
% figure
% trisurf(tri,node(:,1),node(:,2),delta_y) 

 
% %artificial symetrie (put it in the main)
% for ene=1:nnx/2
%     u_x((nnx+1-ene):nnx:numnode) = -u_x(ene:nnx:numnode);
%     u_y((nnx+1-ene):nnx:numnode) =  u_y(ene:nnx:numnode);
% end
% u(1:2:2*numnode) = u_x;
% u(2:2:2*numnode) = u_y;