function nd = point_crack(iel,type_elem,elem_crk,xTip,xVertex,xJertex,xCr)

global node element   

[type_iel kk]= max(type_elem(iel,:));  % to deal with multiples cracks ->just select the number which is not 0 (intersection is not possible)

switch num2str(type_iel)
    case {'0'}
         return
    case {'1'} % tip element ----------------------------------------------
        phi   = LS(iel,elem_crk); 
            [nd] = disTip_point(phi,xTip(iel,:),node(element(iel,:),:),xCr,kk,1);   
    case {'2'} % split ----------------------------------------------------
        phi = LS(iel,elem_crk); 
        [nd] = discont_point(phi,node(element(iel,:),:),xCr,kk); 
    case {'3'} % vertex --------------------------------------------------- 
        phi   = LS(iel,elem_crk);  
        [nd] = disTip_point(phi,xVertex(iel,:),node(element(iel,:),:),xCr,kk,2);     
     case {'4'} % junction ------------------------------------------------ 
        phi   = LS(iel,elem_crk);  
        kkk=find(type_elem(iel,:)==2);
        [nd] = disTip_point2(phi,xJertex(iel,:),node(element(iel,:),:),xCr,kk,kkk); %   
end 