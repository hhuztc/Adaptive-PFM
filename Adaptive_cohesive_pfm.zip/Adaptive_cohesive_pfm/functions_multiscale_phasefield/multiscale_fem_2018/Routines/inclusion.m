function [nb_pt, xTip] = inclusion(e,xCr)

global nodes elements node

sctr=elements(e).sctr;

nb_pt = 0;
xTip = [];
%EPS = 0;% 1e-6; % la generazione dei nodi...non � precisissima!

for j = 1:size(xCr,1)
     if (xCr(j,1) <= max(node(sctr,1)))
         if (xCr(j,1) >= min(node(sctr,1)))
             if (xCr(j,2) <= max(node(sctr,2)))
                 if (xCr(j,2) >= min(node(sctr,2)))
                     nb_pt = nb_pt + 1;
                     xTip = [xCr(j,1) xCr(j,2)];
                     if (j > 1 & j < size(xCr,1))
                         elements(e).type = 3;
                     else
                         elements(e).type = 1;
                     end
                 end
             end
         end
     end
end
  
elements(e).type
