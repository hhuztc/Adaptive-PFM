function [blocked] = select_middle_nodes(list_nodes)

% select the nodes on the middle of the top left right and bottom edges

blocked = [];
half_node = (size(list_nodes,1)+1)/2;


if half_node == int32(half_node)
    blocked = [blocked list_nodes(half_node)];
else
    blocked = [blocked list_nodes(floor(half_node)) list_nodes(ceil(half_node))];
end

