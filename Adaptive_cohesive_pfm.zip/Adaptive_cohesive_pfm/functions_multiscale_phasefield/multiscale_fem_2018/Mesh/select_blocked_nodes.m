function [hori_blocked,vert_blocked] = select_blocked_nodes(topNodes,botNodes,leftEdge,rightEdge) 

% select the nodes on the middle of the top left right and bottom edges

hori_blocked = [];
vert_blocked = [];
tnode = (size(topNodes,1)+1)/2;
lnode = (size(leftEdge,1)+1)/2;


if tnode == int32(tnode)
    hori_blocked = [hori_blocked topNodes(tnode) botNodes(tnode)];
else
    hori_blocked = [hori_blocked botNodes(floor(tnode)) botNodes(ceil(tnode)) topNodes(floor(tnode)) topNodes(ceil(tnode)) ];
end

if lnode == int32(lnode)
    vert_blocked = [vert_blocked leftEdge(lnode) rightEdge(lnode)];;
else
    vert_blocked = [vert_blocked leftEdge(floor(lnode)) leftEdge(ceil(lnode)) rightEdge(floor(lnode)) rightEdge(ceil(lnode))];
end
