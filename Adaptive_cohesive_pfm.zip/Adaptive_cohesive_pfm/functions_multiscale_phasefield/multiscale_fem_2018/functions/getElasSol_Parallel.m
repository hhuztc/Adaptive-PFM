function [kuu,muu,fu] = getElasSol_Parallel(node,element,phiG,i,hplus,hminus)

% Purpose: solve elasticity equation on polygonal mesh..
% Hirshikesh, IITM Nov,2018
% -
% Sundar modified the following
%   - since the N and dNdx computations at the elemental level are computed
%   in the physical space, the computation of Jacobian is suppressed.
%   - gine variable is not used anywhere. suppressed it.
%   - removed reduntant usage of ke
%
%--------------------------------------------------------------------------

global MatData
global ndof_u ngp
global ldType

% material matrix
C = MatData.matmtx;
dens = MatData.dens;
lam = MatData.lambda ;
mu = MatData.mu ;
stressState = MatData.stressState ;
E = MatData.E ;
nu = MatData.nu ;
phi = MatData.phi ;
c = MatData.c ;

% loading type
ld_type = ldType ;

% number of dofs per node
dofs_per_node = ndof_u ;

% number of gauss points
numgp = ngp;

numnode = length(node);
numelem = length(element);

sdofu = numnode*dofs_per_node;
fu = sparse(sdofu,1);

% initialize the variable to store the elemental mass and stiffness
% matrices...
Data = struct('kele',{},'eval',{},'mele',{}) ;
 parfor iel = 1:numelem%2500����Ԫ
    
    % get current element connectivity
    ginp = element{iel};
    
    % nodal coordinates
    coord = node(ginp,:);
    
    % total number of nodes in the current element
    nn = length(ginp) ;
    
    % global index
    gin_e = reshape([dofs_per_node*ginp-1;dofs_per_node*ginp],1,[]);%2*n-1,2*n,�ڵ����ɶȱ��룻�����Ǹı��˾��������˳�򣬰ѽڵ�����ɶȱ��붼�ŵ���һ����
    
    % current element phase field values
    phi_ele = phiG(ginp);%ÿ����Ԫ�Ͻڵ���ೡֵ
    
    % get the history variable...
    hp_ele = hplus(iel,i);
    hn_ele = hminus(iel,i);
        
    % get global index
    kele = zeros(size(gin_e,2),size(gin_e,2));
    mele = zeros(size(gin_e,2),size(gin_e,2));
    
    % get the integration points...
    if nn > 4
        intOrder = 2; intType = 'TRIANGULAR' ;
        [W,Q] = gauss(coord,intOrder,intType) ;
    else
        if nn == 4
            % get only four integration points..
            [wq,qq]=quadrature(numgp,'GAUSS',2);
            eTy = 'Q4' ;
        elseif nn == 3
            [wq,qq] = quadrature(numgp,'TRIANGULAR',2);
            eTy = 'T3' ;
        end
        cntqq = 0;
        for iigp = 1:size(wq,1)
            cntqq = cntqq + 1;
            ptq = qq(iigp,:);
            [ng,dndxig] = lagrange_basis(eTy,ptq);
            jacq = dndxig'*coord ;%coord��ʵ�ʵ�������X=x1*N1+x2*N2+x3*N3+x4*N4,jacq��Ԫ�ؾ���X��ƫ���ó���
            W(cntqq,1) = wq(iigp)*det(jacq);
            temp = ng'*coord;
            Q(cntqq,1) = temp(1); Q(cntqq,2)=temp(2);
        end
    end

    % based on new integration rule....
    for igp = 1:size(W,1)
        pt = Q(igp,:);
        
        % compute the shape function and its derivatives in the
        % canonical domain
        [N,dNdx]=meanvalue_shapefunction(coord,pt) ;       
        %gpt = N'*coord ;
        
        % the phase field variable
        phi = N'*phi_ele;%����Ԫ��ֵ֪���ĸ��ڵ��ֵ�������һ����ೡ
        
        % strain-displacement matrix
        B = zeros(3,dofs_per_node*nn) ;%4���ڵ����3��8��
        B(1,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
        B(2,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
        B(3,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
        B(3,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;
        
        % mass factor
        shpN = zeros(2,dofs_per_node*nn) ;
        shpN(1,1:dofs_per_node:dofs_per_node*nn) = N' ;
        shpN(2,2:dofs_per_node:dofs_per_node*nn) = N' ;
        
        if hp_ele < hn_ele
            phi = 0;
        end
        
        % compute the stiffness matrix
        kele = kele + ...
            B'*( (1-phi)^2 + 1e-6  )*C*B*W(igp) ;
        
        % mass matrix
        mele = mele + shpN'*dens*shpN*W(igp) ;
        
    end
    
    % store element mass and stiffness matrix
    Data(iel).mele = mele;
    Data(iel).kele = kele;
    Data(iel).eval = eig(kele);
 end

%==============================
% assembly in row column format
%==============================
NCOEFF_K = 0;

for iel=1:length(element)
    
    ginp = element{iel};
    DOF = reshape([dofs_per_node*ginp-1;dofs_per_node*ginp],1,[]);
    
    
    iStart = NCOEFF_K + 1 ;
    NCOEFF_K = NCOEFF_K + length(DOF)^2 ;
    iEnd = NCOEFF_K ;
    
    [X,Y] = meshgrid(DOF,DOF);
    
    % stiffness matrix
    kk = Data(iel).kele;
    
    % mass matrix
    mm = Data(iel).mele;
    
    rowIdx(iStart:iEnd) = reshape(Y,1,[]);
    colIdx(iStart:iEnd) = reshape(X,1,[]);
    
    coeffK(iStart:iEnd) = reshape(kk,1,[]);
    coeffM(iStart:iEnd) = reshape(mm,1,[]);
end
kuu = sparse(rowIdx,colIdx,coeffK,sdofu,sdofu,NCOEFF_K);

muu = sparse(rowIdx,colIdx,coeffM,sdofu,sdofu,NCOEFF_K);


end