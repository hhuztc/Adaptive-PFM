function [C] = getMatMtx_youngModulusField(fun_E,x,nu,stressState)

if( strcmp(stressState,'PlaneStress') )%����Ԫ���鹫ʽ3-9
    C = fun_E(x)/(1-nu^2)*[1 nu 0; nu 1 0; 0 0 (1-nu)/2];
elseif strcmp(stressState,'PlaneStrain')
    C = fun_E(x)/(1+nu)/(1-2*nu)*[1-nu nu 0; nu 1-nu 0; 0 0 (1/2)-nu];
end

end