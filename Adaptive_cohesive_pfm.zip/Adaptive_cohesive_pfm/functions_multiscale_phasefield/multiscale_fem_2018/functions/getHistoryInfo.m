function [hplus,points,hminus] = getHistoryInfo(node,element,udisp,i,hplus,hminus)

% filename: getHistoryInfo.m
%
% purpose:
%       to get the history variable at each gauss point (Polygonal)
%       Hirshikesh, IIT Nov 2018
%
% Modifications done by Sundar
%   1. introduced global variable ldType
%   2. defined global variable ndof_u
%   3. Since the history variable and the strain energy is always computed
%   at the center of the element, the loop over the gauss points is
%   suppressed.
%--------------------------------------------------------------------------

global MatData
global ldType TSsplit
global ndof_u

% material properties
lam = MatData.lambda ;
mu = MatData.mu ;
C = MatData.matmtx ;
stressState = MatData.stressState ;
E = MatData.E ;
nu = MatData.nu ;
phi = MatData.phi ;
c = MatData.c ;

% loading type
ld_type = ldType ;

% tension compression split
tens_com_split = TSsplit ;

% number of dofs per node
dofs_per_node = ndof_u ;

numelem = length(element);

% initialize the variable to store the gauss points and the history
% variable to the stored
points = sparse(numelem,3);

% loop over the elements
parfor iel = 1:numelem
    
    % get current element connectivity
    econ = element{iel} ;
    
    % nodal coordinates ȡ�����ڵ�Ԫ���ڵ�����꣨ʵ�ʵģ�
    coord = node(econ,:) ;
    
    % total number of nodes of the current element
    numside = length(econ) ;
    
    % get the geometric centroid
    XX = [mean(coord(:,1)) mean(coord(:,2))];%�õ�Ԫ���е��Hֵ����������Ԫ��Hֵ
    
    % get global index
    gindex = reshape([dofs_per_node*econ-1;dofs_per_node*econ],1,[]);%���һ��������
    
    % elemental displacement vector
    uele = udisp(gindex,1);%ȡ����Ӧ���ɶȵ�λ��
    
    % compute the shape function and its derivatives in the
    % canonical domain
    [N,dNdx]=meanvalue_shapefunction(coord,XX) ;
    glpt = N'*coord ;
    
    % strain-displacement matrix
    B = zeros(3,dofs_per_node*numside) ;
    B(1,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
    B(2,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
    B(3,1:dofs_per_node:dofs_per_node*numside) = dNdx(:,2)' ;
    B(3,2:dofs_per_node:dofs_per_node*numside) = dNdx(:,1)' ;
    
    % compute the strain
    eps_e = B*uele ;
    
    str_e = C*eps_e ;
    
    % get the history variable at the current Gauss point from all
    % all the load steps....
    if strcmp(stressState,'PlaneStrain')
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0;...
            0 0 0];
    else
        %str = C*eps_e ;
        epse4 = -nu/E*(str_e(1) + str_e(2));
        eps_mat = [eps_e(1) eps_e(3)/2 0; eps_e(3)/2 eps_e(2) 0; 0 0 epse4];
    end
    
    if strcmp(tens_com_split,'ambatti')
        
        [~, eig_val] = eig(eps_mat);
        
        
        % Sundar - 2-Jul-2020
        %    the eigen values are stored in the diagonal form, so extract that
        %    and then compute the postive and the negative part
        eig_val = diag(eig_val);
        
        % decompose the strain into positive and negative part
        eig_p = 1/2*(eig_val + abs(eig_val)) ;
        eig_n = 1/2*(eig_val - abs(eig_val)) ;
        
        eig_val = diag(eig_val);
        if strcmp(ld_type,'Tension')
            
            % positive part of the strain
            Psi_p = 0.5*lam*( 0.5*( trace(eig_val) + abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_p(1)*eig_p(1) + eig_p(2)*eig_p(2) + eig_p(3)*eig_p(3) );
            
            % negative part of strain
            Psi_n = 0.5*lam*( 0.5*( trace(eig_val) - abs(trace(eig_val)) ) )^2 +...
                mu*trace( eig_n(1)*eig_n(1) + eig_n(2)*eig_n(2) + eig_n(3)*eig_n(3) );
            
        elseif strcmp(ld_type,'Compressive')%���׹�ʽ16��i=1��4����
            
            term1 = mu*(eig_n(2)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(2) + eig_n(1)))*tand(phi) - c ;
            
            term2 = mu*(eig_n(3)-eig_n(1))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(1)))*tand(phi) - c ;
            
            term3 = mu*(eig_n(3)-eig_n(2))/cosd(phi) + ...
                (lam*(eig_n(1) + eig_n(2) + eig_n(3)) + ...
                mu*(eig_n(3) + eig_n(2)))*tand(phi) - c ;
            
            term4 = 1/4*( (term1+abs(term1))^2 + ...
                (term2 + abs(term2))^2 + (term3 + abs(term3))^2) ;%term4��������ˣ�ǰ�������Ƿֱ����I��j=123�����
            
            Psi_p = 1/(2*mu)*term4 ;
            Psi_n = 0;
        end
        
    elseif strcmp(tens_com_split,'amor')
        
        Kn = lam + mu ;
        
        trE = trace(eps_mat);
        Edev = eps_mat - 1/3*trE*[1 0 0;0 1 0;0 0 1];
        
        trEp = 1/2*(trE + abs(trE)) ;
        trEn = 1/2*(trE - abs(trE)) ;
        
        
        Psi_p = 1/2*Kn*trEp^2 + mu*trace(Edev*Edev);
        Psi_n = 1/2*Kn*trEn^2 ;
    end

    points(iel,:) = [glpt Psi_p];
    
    % save the history variable
    hplus(iel,i) = Psi_p;
    hminus(iel,i) = Psi_n;
    
end

clear iel

end