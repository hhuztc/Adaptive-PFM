clear all
clc
state = 0;
tic;  

% set the path
addpath(genpath('../../multiscale_fem_2018')); 

%-----------------------------
%   GLOBAL VARIABLES
%-----------------------------
global node element elemType E nu xTip fac_J fac_enrich 
global vari_ele iflag_blend fac_sub

%-----------------------------
%     Control parameters
%-----------------------------   
E  = 1e3 ; % Young��s modulus
nu = 0.3 ; % Poisson��s ratio
stressState='PLANE_STRAIN';   
elemType = 'Q4' ;
% Loading
sigmato_x = 0  ; 
sigmato_y = -1  ; 
fac_J=3  ;% factor for J integral 
fac_sub=3;  % No. of subdivisions in one element (2<=fac_sub<=7) 
fac_layer=2; % No. of layers which are refined

%-----------------------------
% Input flag parameters 
%-----------------------------  
iflag_multi=1; %iflag_multi=1 for multiscale elements; and 2 for single scale elements    

% Compliance matrix  
if ( strcmp(stressState,'PLANE_STRESS') )
    C = E/(1-nu^2)*[ 1   nu 0;
                    nu  1  0 ;
                    0   0  0.5*(1-nu) ];  
else
    C = E/(1+nu)/(1-2*nu)*[ 1-nu  nu  0;
                            nu    1-nu 0;
                            0     0  0.5-nu ];
end   


%----------------------------
% Input info of mesh 
%---------------------------
disp([num2str(toc),' info of mesh']) 

% Number of nodes along x-direction and y-direction
   nnx =21;
   nny =21;  
% Dimension of the domain with a rectangular region D x L
   D = 1; % width
   L = 1 ; % height  

% Four corner points
  pt1 = [0  0] ;
  pt2 = [D  0] ;
  pt3 = [D  L] ;
  pt4 = [0  L] ;  
 [node,element] = meshRectangularRegion(pt1, pt2, pt3, pt4, nnx,nny,elemType);   

node0=node;
element0=element;

% define essential boundaries
uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)

rightEdge= [ lrn:nnx:(uln-1); (lrn+nnx):nnx:urn ]';
leftEdge = [ uln:-nnx:(lrn+1); (uln-nnx):-nnx:1 ]';
topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
botNodes   = unique(botEdge);     
rightNodes = unique(rightEdge);    
topNodes   = unique(topEdge);     
leftNodes  = unique(leftEdge); 
  
boundaryNodes=[botNodes ;rightNodes ;topNodes; leftNodes ];%��������һȦ
boundaryNodes=unique(boundaryNodes);

dispNodes_x = [leftNodes]; 
dispNodes_y = [leftNodes]; 

trac_edge=topEdge;  

 if(iflag_multi==2)
   vari_ele=[zeros(fac_sub,1)']; 
   ele_sub=[];
   else  
node=node0;
element=element0;
    disp([num2str(toc),'  Variable-node elements'])   
    [vari_ele]=vari_ele_generate3(fac_sub,D,L,boundaryNodes);
 %  vari_ele  ��һ�������ڵ����ڵĵ�Ԫ�ı�ţ�������������ڵ�Ԫ�������ӽڵ�ı��
  end 


% compute number of nodes, of elements
  numnode = size(node,1);
  numelem = size(element,1); 



plot_mesh(node,element,elemType,'k-'); 

 
total_unknown = numnode*2;%���ɶ�Ϊ�ڵ�����2
            
K = sparse(total_unknown,total_unknown);%�նȾ����Ƕ��ٽ�838*838            
f = zeros(total_unknown,1); %������838*1  



% ***********************************
%    Stiffness matrix computation
% *********************************** 

disp([num2str(toc),'   Stiffness matrix computation'])
% degree for numerical integration   

normal_order = 2;     

% -----------------
% Loop on elements
% -----------------
xy_gauss = []; 

figure
hold on
plot_mesh(node,element,elemType,'b-');
for iel = 1 : numelem  %ѡ��ĳ����Ԫ
    sctr = element(iel,:); % element connectivity
    nodes=node(sctr,:);
    nn   = length(sctr);   % number of nodes per element
    ke   = 0 ;             % elementary stiffness matrix 
    % Choose Gauss quadrature rules for elements  
    [W,Q] = gauss_rule(iel,normal_order,1); % determine GP    

   % Transform these Gauss points to global coords for plotting only
   for igp = 1 : size(W,1)
        gpnt = Q(igp,:);
        [N,dNdxi]=lagrange_basis(elemType,gpnt);
        Gpnt = N' * node(sctr,:); % global GP
       xy_gauss = [xy_gauss;Gpnt]; %all of the global GP
   end  
   
    % Stiffness matrix Ke = B^T C B
     
   % Determine the position in the global matrix K 
   
       sctrB =   assembly(iel,1); % globale
    

    % ---------------------
    % Loop on Gauss points   
    % ---------------------
    for kk = 1 : size(W,1)
        B = [];
        pt = Q(kk,:);                             % quadrature point 
       
  if(ismember(iel,vari_ele(:,1))) 
      for i=1:size(vari_ele,1)
        if(iel==vari_ele(i,1))
        itmp=i;
        break
        end
      end  
        local_shape=[]; nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       %��������;ֲ������ת��
     [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
       nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
     local_shape=[local_shape; exisp,etasp];  
       end
   end 
    [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
    J0 = [nodes; nodes0]'*dNdxi;  % element Jacobian matrix 
     clear nodes0;%%����Ǳ�ڵ㵥Ԫ����ȡ�κ��������ǵĻ��Ͱ�ԭ����
         else
        [N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
        J0 = node(sctr,:)'*dNdxi;                 % element Jacobian matrix 
  end

         k=1; 
        B = [B xfemBmatrix2(pt,elemType,iel,k)];            
                
        K(sctrB,sctrB) = K(sctrB,sctrB) + B'*C*B*W(kk)*det(J0);  % Stiffness matrix����ĸնȾ������Ϲ�ʽ
    end                  % end of looping on GPs 
end                      % end of looping on elements 

% ------------------------------------- 
 plot_GP(elemType,xy_gauss) % Plot GPs for checking 
 clear xy_gauss;
% -------------------------------------  

% ************************
%    NODAL FORCE VECTOR
% ************************  
disp([num2str(toc),'   Nodal force vector computation'])
[W,Q]=quadrature(2,'GAUSS',1);
for e = 1:size(trac_edge,1)%�����������Ƕ��ߣ��������Ը���ʵ�������
     sctr = trac_edge(e,:);
     sctry = sctr.*2  ; 
     sctrx = sctr.*2-1 ;  
    
    for q=1:size(W,1)
        pt = Q(q,:);
        wt = W(q);
        N  = lagrange_basis('L2',pt); 
        J0 = abs( node(sctr(2),1)-node(sctr(1),1) )/2; 
        f(sctry)=f(sctry)+N*sigmato_y*det(J0)*wt;
        f(sctrx)=f(sctrx)+N*sigmato_x*det(J0)*wt;
    end   % of quadrature loop
end       % of element loop   
 

%disp([num2str(toc),'   SOLUTION']) 
% **********************************
%    ESSENTIAL BOUNDARY CONDITION
% **********************************
disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])

bcwt = mean(diag(K)); % a measure of the average size of an element in K
% used to keep the conditioning of the K matrix
udofs = zeros(length(dispNodes_x),1);
vdofs = zeros(length(dispNodes_y),1);

vdofs = dispNodes_y.*2; %���ɶȣ���N��������n-��
udofs = dispNodes_x.*2-1; 

f(udofs) = 0 ;
f(vdofs) = 0 ;

K(udofs,:) = 0;   % zero out the rows and columns of the K matrix
K(vdofs,:) = 0;
K(:,udofs) = 0;
K(:,vdofs) = 0;
K(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
K(vdofs,vdofs) = bcwt*speye(length(vdofs));

u = K\f; 


% **********************************
%          Nodal displacements
% **********************************
u_x = u(1:2:2*numnode) ; % 1 3 5 7 ...
u_y = u(2:2:2*numnode) ; % 2 4 6 8 ...
%save dis-x.m -ascii u_x;
%save dis-y.m -ascii u_y;

% **********************************
%          POST PROCESSING
% **********************************
disp([num2str(toc),'   POST PROCESSING'])  

% Plot numerical deformed configuration
fac = 1;

plot_def(fac,u_x,u_y,elemType);  

figure
hold on 
plot_field(node,element,elemType,u_x); 
colorbar
axis off
%title('x-direntional Displacement contours ') 
%print(gcf,'-dtiff','dis-x.tiff')

figure
hold on  
plot_field(node ,element,elemType,u_y);
colorbar
axis off
%print(gcf,'-dtiff','dis-y.tiff')
%title('y-directional Displacement contours')  
 
disp([num2str(toc),'      Stress computation']) 
stressPoints=[-1 -1;1 -1;1 1;-1 1]; 
for e = 1 : numelem
    sctr = element(e,:);
    nn   = length(sctr);
    U = [];
      k = 1;
        U     = [U; element_disp(e,u,k)];
     
    for q=1:nn
        pt = stressPoints(q,:);   
        % B matrix
        B = [];
          k = 1; 
        B = [B xfemBmatrix2(pt,elemType,e,k)];    
         
        strain = B*U;
        stress(e,q,:) = C*strain;

% compute the mises stress
        str = C*strain;
        strx=str(1);  stry=str(2);   strxy=str(3);    strz=nu*(strx+stry);
        mise=sqrt(((strx-stry)^2+(stry-strz)^2+(strz-strx)^2+6*strxy^2)/2);
        stress_mise(e,q) = mise;

     end
end

 %plot_sig(fac,u_x,u_y,elemType,stress);    
 %plot_sig_mise(fac,u_x,u_y,elemType,stress_mise);  
 
 
 
 



