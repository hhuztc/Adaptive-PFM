function [pcoord] = polycoord(nvert)

%defines nodal locations for quadrilateral and other polygons
%the coordinates are for regular n-gons

if( nvert == 3 )
    pcoord = [0 0;1 0;0 1];
elseif( nvert == 4)
    pcoord = [-1 -1;1 -1;1 1;-1 1];
else
    theta = 2.*pi/nvert ;
    for i=1:nvert
        angle = (i-1)*theta ;
        pcoord(i,1) = cos(angle) ;
        pcoord(i,2) = sin(angle) ;
    end
end
