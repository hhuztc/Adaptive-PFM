clear all
close all
clc

total=0.025;
deltau=1e-5;

numstep = total/deltau;

% deltaU=200*1e-4;
% ff = ['Shear_' num2str(deltaU) '.mat'];
% load(ff);
% 
%     h = figure(1);
%     tri = delaunayn(node);
%     trisurf(tri,node(:,1),node(:,2),full(real(phi)))
%     view(2); shading interp; axis equal; colorbar;
%     colormap jet;
%     
%         figure(5); clf
%     DOMAIN.NODE = node; DOMAIN.ELEMENT = element;
%     plotmesh(DOMAIN,'N','N')

lo = load('Tension_c.txt');
loo = load('shear_hybrid.txt');

plot(lo(:,1), lo(:,2)*1e-3, '-k')
hold on
plot(loo(:,1), loo(:,2), 'sb')
