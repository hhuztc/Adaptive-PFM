function[phi,dphi]=meanvalue_shapefunction(v,x)


n=size(v,1);
w=zeros(n,1);
R = zeros(n,2);
phi = zeros(n,1);
dphi = zeros(n,2);

% computes the outward unit normal to each edge
un = getNormals(v);

v_back=circshift(v,1,1);%backword points
v_for=circshift(v,-1,1);%forward points

eps=1e-20;
for i = 1:n
    m_for=v_for(i,:)-x;
    m=v(i,:)-x;
    m_back=v_back(i,:)-x;
    if all(m==0)
        m=m+[eps eps];
    end
    if all(m_for==0)
        m_for=m_for+[eps eps];
    end
    if all(m_back==0)
        m_back=m_back+[eps eps];
    end
    if isempty(m)
        w=zeros(n,1);
        w(i)=1;
    end
    alpha(i)=acos(dot(m_for,m)/(norm(m_for)*norm(m)));
    alpha_back(i)=acos(dot(m_back,m)/(norm(m_back)*norm(m)));
    
    w(i)=(tan(alpha(i)/2)+tan(alpha_back(i)/2))/norm(m);  
    e(i,:)=m/norm(m);
end

e_for=circshift(e,-1,1);

for i = 1:n
    r_for=norm(v_for(i,:)-x);
    r=norm(v(i,:)-x);
    if all(r==0)
        r=r+eps;
    end 
    if all(r_for==0)
        r_for=r_for+eps;
    end
    c(i,:)=(e(i,:)/r)-(e_for(i,:)/r_for);
end

for i=1:n
    cP(i,:)=[-c(i,2) c(i,1)];
end
cP_back=circshift(cP,1,1);

for i=1:n
    m=v(i,:)-x;
    if all(m==0)
        m=m+[eps eps];
    end
    t=tan(alpha(i)/2);
    t_back=tan(alpha_back(i)/2);
    den1=sin(alpha(i));
    den2=sin(alpha_back(i));
    den3=(t_back+t);
    if sin(alpha(i))==0
        den1=den1+eps;
    end
    if sin(alpha_back(i))==0
        den2=den2+eps;
    end
    if (t_back+t)==0
        den3=den3+eps;
    end
    R(i,:)=((t_back/den3)*cP_back(i,:)/den2) ...
           +((t/den3)*cP(i,:)/den1)+(e(i,:)/norm(m));  
%     R(i,:)=((t_back/(t_back+t))*cP_back(i,:)/sin(alpha_back(i))) ...
%            +((t/(t_back+t))*cP(i,:)/sin(alpha(i)))+(e(i,:)/norm(m));  
    
end

wsum = sum(w);
phi= w/wsum;
phiR = phi'*R;

for k = 1:2
    dphi(:,k)= phi.*(R(:,k)-phiR(:,k));
end


end

