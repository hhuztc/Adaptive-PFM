function [kpp,fpp] = getPhaseField_Parallel(node,element,it,hplus)
% purpose: solve phase-field equation on polygonal mesh
% Hirshikesh, IITM Nov 2018
% modified to use in parallel
%                  jan 2019
%
% -
% Sundar modified the following
%   - since the N and dNdx computations at the elemental level are computed
%   in the physical space, the computation of Jacobian is suppressed.
%   - gine variable is not used anywhere. suppressed it.
%
%--------------------------------------------------------------------------

global MatData ndof_p
global ngp


% material parameters
Gc = MatData.Gc ;
lo = MatData.lo ;

% number of gauss points
numgp = ngp;

numnode = length(node);
numelem = length(element);
sdofp = numnode*ndof_p;

% initialize the element stiffness matrix
DataK = struct('kcele',{}) ;
Datafp = struct('fpele',{}) ;


for iel = 1:numelem
    
    % get current element connectivity
    ginp = element{iel};
    
    % nodal coordinates
    coord = node(ginp,:);
    
    % total number of nodes in the current element 
    nn = length(ginp) ;

    % initialize the elemental stiffness matrix and force vector
    kcele = zeros(size(ginp,2),size(ginp,2));
    fpele = zeros(size(ginp,2),1);

    % get the integration points...
    if nn > 4
        intOrder = 2; intType = 'TRIANGULAR' ;
        [W,Q] = gauss(coord,intOrder,intType) ;
    else
        if nn == 4
            % get only four integration points..
            [wq,qq]=quadrature(numgp,'GAUSS',2);
            eTy = 'Q4' ;
        elseif nn == 3
            [wq,qq] = quadrature(numgp,'TRIANGULAR',2);
            eTy = 'T3' ;
        end
        cntqq = 0;
        for iigp = 1:size(wq,1)
            cntqq = cntqq + 1;
            ptq = qq(iigp,:);
            [ng,dndxig] = lagrange_basis(eTy,ptq);
            jacq = dndxig'*coord ;
            W(cntqq,1) = wq(iigp)*det(jacq);
            temp = ng'*coord;
            Q(cntqq,1) = temp(1); Q(cntqq,2)=temp(2);
        end
    end
    
    % History variable of the current element
    H = max(hplus(iel,:)) ;

    % based on new integration rule....
    for igp = 1:size(W,1)
        pt = Q(igp,:) ;
        
        % compute the shape function and its derivatives in the
        % canonical domain
        [N,dNdx]=meanvalue_shapefunction(coord,pt) ;
                
        % the forcing term
        fpele = fpele + 2*N*H*W(igp) ;
        
        % compute the stiffness matrix
        kcele = kcele + ...
            (dNdx*Gc*lo*dNdx' + N*(Gc/lo + 2*H)*N' )*W(igp) ;
    end
    
    DataK(iel).kcele = kcele;
    Datafp(iel).fpele = fpele;
    
end

%==============================
% assembly in row column format
%==============================
NCOEFF_K = 0;
NCOEFF_F = 0;
for iel=1:length(element)
    
    %DOF = gindexp{iel};
    
    DOF = element{iel};
    
    % for stiffness matrix
    iStart = NCOEFF_K+1 ;
    NCOEFF_K = NCOEFF_K + length(DOF)^2 ;
    iEnd = NCOEFF_K ;
    
    % for force vector
    jStart = NCOEFF_F + 1;
    NCOEFF_F = NCOEFF_F + length(DOF) ;
    jEnd = NCOEFF_F ;
    
    [X,Y] = meshgrid(DOF,DOF);
    
    kk = DataK(iel).kcele;
    ff = Datafp(iel).fpele;
    
    rowIdx(iStart:iEnd) = reshape(Y,1,[]);
    colIdx(iStart:iEnd) = reshape(X,1,[]);
    coeffK(iStart:iEnd) = reshape(kk,1,[]);
    
    colJdx(jStart:jEnd) = Y(:,1)';
    coeffF(jStart:jEnd) = reshape(ff,1,[]);
end
kpp = sparse(rowIdx,colIdx,coeffK,sdofp,sdofp,NCOEFF_K);

% force vector
fpp = sparse(colJdx,1,coeffF,sdofp,1,NCOEFF_F);

clear iel

end