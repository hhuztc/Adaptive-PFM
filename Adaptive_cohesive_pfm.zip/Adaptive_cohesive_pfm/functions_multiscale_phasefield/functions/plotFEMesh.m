function plotFEMesh(X,connect,elem_type,se,pnode,node,element)

% plots a nodal mesh and an associated connectivity.  X is
% teh nodal coordinates, connect is the connectivity, and
% elem_type is either 'L2', 'L3', 'T3', 'T6', 'Q4', or 'Q9'
% depending on the element topology.

%Author(s): Sundar, Stephane, Stefano, Phu, David
%Modified: Jan 2009
%--------------------------------------------------------------------

if ( nargin < 4 )
    se='w-';
end

holdState=ishold;
hold on
grid on
box on

% fill X if needed
if (size(X,2) < 3)
    for c=size(X,2)+1:3
        X(:,c)=[zeros(size(X,1),1)];
    end
end

for e=1:size(connect,1)
    
    if ( strcmp(elem_type,'Q9') )       % 9-node quad element
        ord=[1,5,2,6,3,7,4,8,1];
    elseif ( strcmp(elem_type,'Q8') )  % 8-node quad element
        ord=[1,5,2,6,3,7,4,8,1];
    elseif ( strcmp(elem_type,'Q81') )  % 8-node quad element
        ord=[1,2,3,4,5,6,7,8,1];
    elseif ( strcmp(elem_type,'T3') )  % 3-node triangle element
        ord=[1,2,3,1];
    elseif ( strcmp(elem_type,'T6') )  % 6-node triangle element
        ord=[1,4,2,5,3,6,1];
    elseif ( strcmp(elem_type,'T61') )  % 6-node triangle element
        ord=[1,2,3,4,5,6,1];
    elseif ( strcmp(elem_type,'Q4') )  % 4-node quadrilateral element
        ord=[1,2,3,4,1];
    elseif ( strcmp(elem_type,'L2') )  % 2-node line element
        ord=[1,2];
    elseif ( strcmp(elem_type,'L3') )  % 3-node line element
        ord=[1,3,2];
    elseif ( strcmp(elem_type,'L31') )  % 3-node line element
        ord=[1,2,3];
    elseif ( strcmp(elem_type,'H4') )  % 4-node tet element
        ord=[1,2,4,1,3,4,2,3];
    elseif ( strcmp(elem_type,'B8') )  % 8-node brick element
        ord=[1,5,6,2,3,7,8,4,1,2,3,4,8,5,6,7];
    end
    
    for n=1:size(ord,2)
        xpt(n)=X(connect(e,ord(n)),1);
        ypt(n)=X(connect(e,ord(n)),2);
        zpt(n)=X(connect(e,ord(n)),3);
    end
    plot3(xpt,ypt,zpt,se)
%     fill3(xpt,ypt,zpt,'b','LineWidth',1)
end
% 
alpha(0)
rotate3d on
axis equal

% if ( ~holdState )
%   hold off
% end

% % highlight nodal locations...
% plot(node(:,1),node(:,2),'ko')

if( strcmp(pnode,'yes') )
    switch elem_type
        case 'Q4'
            xd = node(:,1); yd = node(:,2) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)+0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
        case 'Q8'
            xd = node(:,1); yd = node(:,2) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)-0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
        case 'Q81'
            xd = node(:,1); yd = node(:,2) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)-0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
        case 'L2'
            xd = node(:,1) ; yd = zeros(size(xd,1)) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01 ; yc = yd(i) + 0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
            
        case 'L3'
            xd = node(:,1) ; yd = zeros(size(xd,1)) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01 ; yc = yd(i) + 0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
            
        case 'L31'
            xd = node(:,1) ; yd = zeros(size(xd,1)) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01 ; yc = yd(i) + 0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
            
        case 'T3'
            xd = node(:,1); yd = node(:,2) ;
            for i=1:size(node,1)
                %plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)+0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
            
        case 'T61'
            xd = node(:,1); yd = node(:,2) ;
            for i=1:size(node,1)
                plot(xd(i),yd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)-0.01;
                text(xc,yc,num2str(i),'FontSize',10);
            end
            
        case 'B8'
            xd = node(:,1); yd = node(:,2); zd = node(:,3);
            for i=1:size(node,1)
                plot3(xd(i),yd(i),zd(i),'o','LineWidth',1,'Markersize',3,'MarkerFaceColor','r')
                xc = xd(i)+0.01; yc=yd(i)-0.01; zc = zd(i)+0.01;
                text(xc,yc,zc,num2str(i),'FontSize',10);
            end
    end
end
