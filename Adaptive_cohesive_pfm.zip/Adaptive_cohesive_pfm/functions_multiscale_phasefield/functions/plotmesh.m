function plotmesh(DOMAIN,N,E)

NODE = DOMAIN.NODE;
ELEMENT = DOMAIN.ELEMENT;
XX = NODE(:,1); YY = NODE(:,2);
for i=1:size(ELEMENT,2)
    l=ELEMENT{i};
    for j=1:length(l)
        if j==length(l)
            A = [XX(l(j)) XX(l(1))];B = [YY(l(j)) YY(l(1))];
        else
            A = [XX(l(j)) XX(l(j+1))];B = [YY(l(j)) YY(l(j+1))];
        end
        plot(A,B,'k')
        if isequal(N,'Y')
            text(XX(l(j)),YY(l(j)),num2str(l(j)))
        end
        hold on
    end
    hold on
    if isequal(E,'Y')
        text(mean(XX(l)),mean(YY(l)),num2str(i),'color','r')
    end
end
axis equal