function [W,Q] = gauss(lcoord,intOrder,intType)

%get integration points

%get the centroid for triangulation
[geom,iner,cpmo] = polygeom(lcoord(:,1), lcoord(:,2)) ;

lcoord = [lcoord;geom(2) geom(3)] ;

tri = delaunay(lcoord(:,1),lcoord(:,2)) ;
tri = tricheck(lcoord,tri);
% triplot(tri,lcoord(:,1),lcoord(:,2))

% loop over subtriangles to get quadrature points and weights
pt = 1;
w=[]; q=[] ;
for e=1:size(tri,1)
    [w,q] = quadrature(intOrder,intType,2) ;
    % transform quadrature points into the parent element
    coord = lcoord(tri(e,:),:);
    a = det([coord,[1;1;1]])/2;
    if ( a<0 )  % need to swap connectivity
        coord=[coord(2,:);coord(1,:);coord(3,:)];
        a = det([coord,[1;1;1]])/2;
    end

    if ( a~=0 )
        for n=1:length(w)
            N = lagrange_basis('T3',q(n,:));
            Q(pt,:) = N'*coord;
            W(pt,1) = 2*w(n)*a;
            pt = pt+1;
        end
    end
end
% 
% plot(Q(:,1),Q(:,2),'b+')
% pause
