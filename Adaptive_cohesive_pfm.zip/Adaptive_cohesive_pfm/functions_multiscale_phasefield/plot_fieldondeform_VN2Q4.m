function plot_fieldondeform_VN2Q4(node,element,field,disp,fac_deform)

hold on;

nodenew=node+fac_deform*reshape(disp',[2,size(node,1)])';

numelem = length(element);
ien=zeros(4,numelem);
for ie=1:numelem
    ien(:,ie) = element(ie,:);
end

xe = reshape(nodenew(ien,1),size(ien));
ye = reshape(nodenew(ien,2),size(ien));
ce = reshape(field(ien),size(ien));
patch(xe,ye,ce);
%set(plotdisp,'LineStyle','none');
axis equal;
axis off;
%colorbar;
colorbar('east','FontSize',15);
colormap('jet');

end 

