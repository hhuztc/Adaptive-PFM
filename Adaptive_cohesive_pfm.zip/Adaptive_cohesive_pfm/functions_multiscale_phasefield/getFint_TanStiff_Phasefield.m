function [Pp,KTpp] = getFint_TanStiff_Phasefield(node,element,Pfield,DrivForce)

%--------------------------------------------------------------------------
% get Internal Force Vector & Tangent Stiffness Matrix of Phase-field sub-problem
% for Staggered Phase-field solver
% include both linear & non-linear Phase-field weak form
%--------------------------------------------------------------------------

global PhfProps MdlProps

Phf_Props = PhfProps;

order    = MdlProps.order;    % quadrature order ���ִ���
orderVNE = MdlProps.orderVNE; % quadrature order for Variable-node Element

numnode = length(node);
numelem = length(element);

pdofs = MdlProps.pdofs; % number of phase-field  dofs per node

pdofs_total = numnode*pdofs;

DataP  = struct('P_ele',{});  % initialize the variable to store Pp
DataKT = struct('KT_ele',{}); % initialize the variable to store KTpp

parfor iel = 1:numelem
%for iel = 1:numelem

    elenod = element{iel} ;    % get element connectivity
    crd    = node(elenod,:) ;  % nodal coordinates
    nnod   = length(elenod) ;  % total number of nodes in the current element
    
    % global index of dofs:
    sctr_p = zeros(1,nnod*pdofs); % for phase-field  dof
    for inod = 1:nnod
        sctr_p(pdofs*(inod-1)+1:pdofs*inod) = pdofs*(elenod(inod)-1)+1:pdofs*elenod(inod);
    end
    
    % current element field values:
    phi_ele = Pfield(sctr_p);
    
    % initialize elemental Residual & Tangent Stiffness:
    Pp_ele   = zeros(size(sctr_p,2),1);
    KTpp_ele = zeros(size(sctr_p,2),size(sctr_p,2));
    
    % get the integration points:�õ���˹��
    [W,Q] = unified_quadrature(crd,order,orderVNE,0);

    % loop over the integration points:
    for iip = 1:size(W,1)
        Ip = Q(iip,:) ;
        
        % compute shape function, its derivatives, and determinant of Jacobian:
        [N,dNdxy,detJ] = unified_N_dNdxy_detJ(crd,Ip);
        
        % the phase field variable:
        phi_ip = N * phi_ele;
        dp_ip  = dNdxy * phi_ele; % derivative of phi
        
        % geometric crack function alpha(phi):dalpha��ddalpha
        [~,dap,d2ap] = UnifiedPF_alpha(phi_ip,Phf_Props);
        
        % degradation function g(phi):
        [~,dgp,d2gp] = UnifiedPF_degradation(phi_ip,Phf_Props);
             
        % phase-field function parameters:
        L0       = Phf_Props.L0;
        Gc       = Phf_Props.Gc;
        C0       = Phf_Props.C0;
        EnerBarr = Phf_Props.EnerBarr;
        
%         % crack driving force:
%         DF_ip = DrivForce{iel}(iip,:);
%         
%         if norm(DF_ip(1:2)-Ip) > 1e-5, error('DrivForce Ip changed !!!!'); end
%         
        DrivF = max(DF_ip(3),EnerBarr);
        
        % calculate Residual Vector & Tangent Stiffness Matrix:
        Pp_ele   = Pp_ele + ...
              W(iip)*detJ * ( N'*  ( dgp*DrivF+ dap*Gc/C0/L0) + dNdxy'*dp_ip*(2*L0*Gc/C0) );
        
        KTpp_ele = KTpp_ele + ...
              W(iip)*detJ * ( N'*N*(d2gp*DrivF+d2ap*Gc/C0/L0) + dNdxy'*dNdxy*(2*L0*Gc/C0) );
        
    end
    
    % store Pp & KTpp:
    DataP(iel).P_ele   = Pp_ele;
    DataKT(iel).KT_ele = KTpp_ele;
        
end

%==============================
% assembly in row column format
%==============================
NCOEFF_P = 0;
NCOEFF_K = 0;

for iel=1:length(element)
    
    elenod = element{iel};
    nnod   = length(elenod);
    
    DOF = zeros(1,nnod*pdofs);
    for inod = 1:nnod
        DOF(pdofs*(inod-1)+1:pdofs*inod) = pdofs*(elenod(inod)-1)+1:pdofs*elenod(inod);
    end
    
    % for vector:
    jStart   = NCOEFF_P + 1;
    NCOEFF_P = NCOEFF_P + length(DOF) ;
    jEnd     = NCOEFF_P ;
    
    % for matrix:
    iStart   = NCOEFF_K + 1 ;
    NCOEFF_K = NCOEFF_K + length(DOF)^2 ;
    iEnd     = NCOEFF_K ;
    
    [X,Y] = meshgrid(DOF,DOF);
    
    rr = DataP(iel).P_ele;
    kk = DataKT(iel).KT_ele;
    
    colJdx(jStart:jEnd) = Y(:,1)';
    coeffR(jStart:jEnd) = reshape(rr,1,[]);
    
    rowIdx(iStart:iEnd) = reshape(Y,1,[]);
    colIdx(iStart:iEnd) = reshape(X,1,[]);
    coeffK(iStart:iEnd) = reshape(kk,1,[]);
    
end

Pp   = sparse(colJdx, 1,coeffR,pdofs_total, 1,NCOEFF_P);

KTpp = sparse(rowIdx,colIdx,coeffK,pdofs_total,pdofs_total,NCOEFF_K);

end