function [node,element,Enode] = getcrackconnectivity_cohesive(node,element,x0,x1,crackDist)
D = 100;
% D = 50;
nn = size(node,1);
xx = node(:,1); yy = node(:,2);
duplicate = find(xx<x0+1e-6 & xx>x0-1e-6 & yy<D/2);%3point
% duplicate1 = find(xx<x0 & yy<D/2+1e-6 & yy>D/2-1e-6);%double edge
% duplicate2 = find(xx>x1 & yy<D/2+1e-6 & yy>D/2-1e-6);
% duplicate = [duplicate1 ; duplicate2];

node(duplicate,1) = node(duplicate,1)-crackDist;
k = 1;
extra = [];
for j=1:length(duplicate)
    
    extra = [ extra; duplicate(j) nn+k];
    k = k + 1;
end
dist = 1e-5;
mid = find(xx<x0+dist & xx>x0-dist & yy<D/2+dist & yy>D/2-dist);
for j=1:length(duplicate)
    
    for i=1:length(element)
        
        econ = element(i,:);
        
        if econ(1)==duplicate(j)
            
            node(extra(j,2),2) = node(econ(1),2)+2*crackDist;
            node(extra(j,2),1) = node(econ(1),1);
            econ(1) = extra(j,2);
            element(i,:) = econ;
         end
        if econ(2)==duplicate(j)
            node(extra(j,2),2) = node(econ(2),2)+2*crackDist;
            node(extra(j,2),1) = node(econ(2),1);
            econ(2) = extra(j,2);
            element(i,:)= econ;
        end
    end
end
% Enode = [];
Enode = [mid;extra(:,1);extra(:,2)];