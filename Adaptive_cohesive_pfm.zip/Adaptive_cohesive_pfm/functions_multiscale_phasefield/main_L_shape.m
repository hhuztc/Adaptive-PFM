clear all
close all
clc
% declare global variables
global elemType 
global ngp ndof_p ndof_u
global  MatData 
global ldType TSsplit
global fac_J
global fac_sub 
global vari_ele node element
global boundaryNodes bcNodes loadnode

fac_J=3  ;% factor for J integral 
fac_sub=2;  % No. of subdivisions in one element (2<=fac_sub<=7) 
fac_layer=1; % No. of layers which are refined


% fid = fopen('Dummy.txt','w');
fid = 1 ;

% load the reference results
% ref = load('tension_015_miehe.txt');
% 
% figure(20); hold on;
% plot(ref(:,1),ref(:,2),'r-');%

% choosing the loading type..
% options: Compressive and Tension
%ldType = 'Tension' ;
ldType = 'Tension' ;

% TSsplit - tension compression split
% options: amor/ambatti
TSsplit = 'ambatti' ; 

if strcmp(ldType,'Compressive')
    % following properties are taken from the reference paper given in the
    % preamble.
    MatData.Gc = 100*1e-03 ; % N/mm
    E = 60e09*(1e-03)^2 ;    % N/mm^2 Gpa
    nu = 0.3;%���ɱ�
    dens = 0;
    MatData.phi = 15 ;  % in deg, internal friction angle
    MatData.c = 100e03*(1e-03)^2 ;    % cohesion % N/mm^2 
elseif strcmp(ldType,'Tension')
    MatData.Gc = 0.13;   %N/mm
    E = 21e3;% Mpa;
    nu = 0.18;
    ft= 2.7;%Mpa;
    theck = 100;
    MatData.phi = 0;
    MatData.c = 0;
    dens = 0;
end

stressState = 'PlaneStrain';
matmtx = getMatMtx(E,nu,stressState);%Elastic_matrix

lambda = E*nu/((1+nu)*(1-2*nu)) ;
mu = E/(2*(1+nu)) ;

MatData.nu = nu;
MatData.E = E;
MatData.lambda = lambda;
MatData.mu = mu ;
MatData.matmtx = matmtx;
MatData.stressState = stressState;
MatData.dens = dens;
MatData.ft = ft;
MatData.theck =theck;

% number of gauss points
ngp = 2 ;

% dofs per node
ndof_p = 1;%
ndof_u = 2;
elemType = 'Q4';
nodedata = xlsread('node_data_L.xlsx');
node = nodedata(:,2:end);
elementdata = xlsread('element_data_L.xlsx');
element = elementdata(:,2:end);
node0=node;
element0=element;
% define essential boundaries
botNodes   = find(node(:,2) == min(node(:,2)));     
rightNodes = find(node(:,1) == max(node(:,1)));    
topNodes   = find(node(:,2) == max(node(:,2)));     
leftNodes  = find(node(:,1) == min(node(:,1))); 
[t1,t2] = sort(node(rightNodes,2)) ;
rightNodes = rightNodes(t2) ;
boundaryNodes=[botNodes; rightNodes ;topNodes; leftNodes ];%��������һȦ
boundaryNodes=unique(boundaryNodes);
bcNodes={botNodes rightNodes topNodes leftNodes};
loadnode = 37;
%if exist initial variable-node elements
iflag_multi=2;
 if(iflag_multi==2)
   vari_ele=[zeros(fac_sub,1)']; 
   ele_sub=[];
 else  
 node=node0;
 element=element0;
      [vari_ele]=vari_ele_generate3_phasefield(fac_sub,boundaryNodes);
 end 
%generate duplicate nodes along crack faces
% X0 = 225; % crack tip coordinate
% crackDist = 1e-8;
% [node,element,Enode] = getcrackconnectivity_phasefield(node,element,X0,crackDist);
% compute number of nodes, of elements

  numnode = size(node,1);
  numelem = size(element,1); 
% 
figure(10)
plot_mesh_phasefield(node,element,elemType,'k-'); 

%-------------------------------------------------------
tic;%save running time

%adaptive schemes
total_adaptive_steps = 4;

 for adaptive_steps = 1:total_adaptive_steps
% to find the size of the element
for iel = 1:numelem
    econ = element(iel,:);
    nds_iel = node(econ,:);
    hdia(iel) = polygon_diameter_2d(length(econ),nds_iel');
end

% % minimum element size..
h = min(hdia);

% % length scale parameter
MatData.lo = 2*h/sqrt(2);
% MatData.lo = 0.01; to match load_disp from the paper
% get the initial crack geometry distribution
fprintf(fid,'Find the initial phase field description\n');
[phi] = sparse(numnode*ndof_p,1) ;

% store the history information for each load step...
Hini = sparse(length(element),1);
HisInfo(1).Hval = Hini ;

dU = 5e-3;         % incremental displacements..
deltaU = 0;         % total displacements...
displacement = 5e-3;
%numSteps = 5500;     % number of loading steps...
numSteps = 1500;     % number of loading steps...

% initialize the displacement field and the crack geometry
phiOld = phi ;
udisp = sparse(numnode*ndof_u,1);%һ�����������ɶ�
uOld = udisp;
% hmax = Hini ;

hmax = zeros(numelem,numSteps);

hplus = zeros(numelem,numSteps);
hminus = zeros(numelem,numSteps);

%--------------------------------------------------------------------------
%           loop over the loading steps...
%--------------------------------------------------------------------------

for i = 1:numSteps 
    
    % print the load step...
    fprintf(fid,'    Load step    %2d\n',i);
    
    dU = 5e-3;         % incremental displacements..  

    
    % increment in displacements...
    deltaU = dU;
    displacement = displacement + dU;
    % staggered solution process starts...
    err = 1; tol = 1e-02; iter = 1;
    tcheck = tic;
   while err > tol 
        
       
        
        %==================================================================
        %           elasticity solution
        % from this phase field distribution find the displacement field...
        %==================================================================
        % now apply boundary conditions for the elasticity problem....
        bcdof = [];
        bcval = [];
        botN = bcNodes{1};%�ױߵĽڵ���   
        for in = 1:length(botN)
             bcdof = [bcdof ndof_u*botN(in)-1 ndof_u*botN(in)];
             bcval = [bcval 0 0];
        end
         loadN = loadnode;
        for in = 1:length(loadnode)
            bcdof = [bcdof ndof_u*loadN(in) ndof_u*loadN(in)-1 ];
            bcval = [bcval deltaU 0];
        end
            
        
        % get the active DOF
        TotalDOF = [1:ndof_u*numnode];
        activeDof = setdiff(TotalDOF,bcdof);
        fixDof = setdiff(TotalDOF,activeDof);
        % get the active DOF
        TotalDOF = [1:ndof_u*numnode];
        activeDof = setdiff(TotalDOF,bcdof);
%         fixDof = setdiff(TotalDOF,activeDof);
   [udisp,ruu,kuu] = risdual_NR_displacementfield(i,phi,hplus,hminus,udisp,activeDof,bcdof,bcval,iter,TotalDOF);
                 
        % update the strain energy density and the history variable...
   [hplus,points,hminus] = getHistoryInfo_cohesive(udisp,i,hplus,hminus);
        %==================================================================
        %           Phase field solution
        % find the distribution of phase field that represents the crack
        % geometry...
        %==================================================================
      
        
      [phi] = risdual_NR_Phasefield(phi,hplus);
     
        err1 = norm(phi-phiOld)/norm(phiOld) ;
        err2 = norm(udisp-uOld)/norm(uOld);
        
        err = max(err1,err2);
        
        fprintf(fid,'Staggered iteration:  %2d     Error   %6f\n',iter,err);
        
        % increment the counter
        iter = iter + 1 ;
        
        % save the solution for convergence check...
        phiOld = phi ;
        uOld = udisp;
        
    end
%     figure(23);
%     title('picture combined phase field and mesh');
%     fac_deform = 10;
%     plot_fieldondeform_VN2Q4(node,element,real(phi),real(udisp),fac_deform);
    
    fprintf(fid,'---------------------------------------------\n');
    fprintf(fid,'Staggered iteration converged after  %2d\n',iter);
    fprintf(fid,'     Error   %6f\n',err);
    fprintf(fid,'     DeltaU   %4.2e\n',deltaU);
    fprintf(fid,'     Displacement   %4.2e\n',displacement);
    fprintf(fid,'     Elapsed time (s)     %8.4e\n',toc(tcheck));
    fprintf(fid,'--------------------------------------------\n');
    
    if mod(i,numSteps) == 0
    save(['Tensi_' num2str(deltaU) '.mat'],'node', 'element', 'phi', 'udisp');
    end
    
    % plot the phase field variable
    if adaptive_steps == 1
    figure(1);clf
    title('figure of phase field');
    tri = delaunayn(unique(node));
    trisurf(element,node(:,1),node(:,2),full(real(phi)))
    view(2); axis equal;
    shading interp; colorbar;
    colormap jet;
    axis off;
    end
    %colormap jet;
    if adaptive_steps == 2
    figure(2);clf
    title('figure of phase field');
    tri = delaunayn(unique(node)); 
    trisurf(element,node(:,1),node(:,2),full(real(phi)))
    view(2); axis equal;
    shading interp; colorbar;
    colormap jet;
    axis off;
    end
     if adaptive_steps == 3
    figure(3);clf
    title('figure of phase field');
    tri = delaunayn(unique(node));
    trisurf(element,node(:,1),node(:,2),full(real(phi)))
    view(2); axis equal;
    shading interp; colorbar;
    colormap jet;
    axis off;
     end
    if adaptive_steps == 4
    figure(4);clf
    title('figure of phase field');
    tri = delaunayn(unique(node));
    trisurf(element,node(:,1),node(:,2),full(real(phi)))
    view(2); axis equal;
    shading interp; colorbar;
    colormap jet;
    axis off;
    end
    if adaptive_steps == 5
    figure(5);clf
    title('figure of phase field');
    tri = delaunayn(unique(node));
    trisurf(element,node(:,1),node(:,2),full(real(phi)))
    view(2); axis equal;
    shading interp; colorbar;
    colormap jet;
    axis off;
    end
   
    
    % ======================
    % load displacement data
    % ======================
    if adaptive_steps == total_adaptive_steps
    f = kuu*udisp;%��ʽfint
    F = f(loadnode*2);
    rf = sum(F);
    rf=abs(rf);   
    figure(9); hold on;
    title('the curve of displacement and load');
    plot(displacement, real(rf)./1e3, '.b')
    pause(0.1)
    fclose(fileID);
    end
    
   %stop the computational process
    if displacement>0.75
         displacement = displacement; 
         break
    end
%======================================================

     phasefieldseted=0.2;
if adaptive_steps <= total_adaptive_steps  
         % select the refinement criteria
         [marked_ele,ele_phi] = get_ele_phi2(phi,phasefieldseted,hplus);
    %===============================================================================
         %gengrate variable-node elements
         ElemSctr = element;
         ValidNodeNum = 4*ones(size(element,1),1);%��Ч�ڵ����
         sub_divide = 2;
         updElem = marked_ele; 
         vari_ele_node = vari_ele;
        if all(vari_ele==0)
           vari_ele_node = [];
        end
     [vari_ele,ElemSctr,ValidNodeNum] = vari_elem_generate(ElemSctr,ValidNodeNum,vari_ele_node,updElem,sub_divide);
       %renew number of elements/node
     numnode = size(node,1);
     numelem = size(element,1); 
        %renew the boundarynodes
    botNodes1 = find(node(:,2) == min(node(:,2))) ;
    rightNodes1 = find(node(:,1) == max(node(:,1))) ;
    topNodes1 = find(node(:,2) == max(node(:,2))) ;
    leftNodes1 = find(node(:,1) == min(node(:,1))) ;
    [t1,t2] = sort(node(rightNodes1,2)) ;
    rightNodes1 = rightNodes1(t2) ;
    bcNodes= {botNodes1 rightNodes1 topNodes1 leftNodes1} ;
    boundaryNodes = [botNodes1;rightNodes1;topNodes1;leftNodes1];
    boundaryNodes = unique(boundaryNodes);

    if adaptive_steps == 1
       figure(101);
       plot_StdMesh([],element,node)
       a = numelem;
    end
    if adaptive_steps == 2
       figure(102);
       plot_StdMesh([],element,node);
       b=numelem;
   end
 
   if adaptive_steps == 3
       figure(103);
       plot_StdMesh([],element,node);
       c = numelem;
   end

   if adaptive_steps == 4
       figure(104);
       plot_StdMesh([],element,node);
       d=numelem;
   end
end
 end
toc;
time = num2str(toc);
disp(['����ʱ��: ',num2str(toc)]);  
fclose('all');

  


