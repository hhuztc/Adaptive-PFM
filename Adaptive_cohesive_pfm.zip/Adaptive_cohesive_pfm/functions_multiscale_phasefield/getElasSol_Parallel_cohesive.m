function [kuu,ruu] = getElasSol_Parallel_cohesive(phiG,i,hplus,hminus,udisp)
global vari_ele node element fac_sub
% Purpose: solve elasticity equation on polygonal mesh..
% Hirshikesh, IITM Nov,2018
% -
% Sundar modified the following
%   - since the N and dNdx computations at the elemental level are computed
%   in the physical space, the computation of Jacobian is suppressed.
%   - gine variable is not used anywhere. suppressed it.
%   - removed reduntant usage of ke
%
%--------------------------------------------------------------------------

global MatData
global ndof_u ngp
global ldType
global elemType

% material matrix
C = MatData.matmtx;
dens = MatData.dens;
lam = MatData.lambda ;
mu = MatData.mu ;
stressState = MatData.stressState ;
E = MatData.E ;
nu = MatData.nu ;
phi = MatData.phi ;
c = MatData.c ;
Gc = MatData.Gc;
ft = MatData.ft;
lo = MatData.lo;
theck = MatData.theck;
% loading type
ld_type = ldType ;

% number of dofs per node
dofs_per_node = ndof_u ;

% number of gauss points
numgp = ngp;

numnode = length(node);
numelem = length(element);

sdofu = numnode*dofs_per_node;
fu = sparse(sdofu,1);

normal_order = 2;
%create a cell
% element_modified=cell(numelem,1);
% for j = 1 : size(element,1)
% element_modified{j,:} = element(j,:);
% end
% initialize the variable to store the elemental mass and stiffness
% matrices...
Data = struct('kele',{},'eval',{},'ru',{}) ;

% loop in each element 
for iel = 1:numelem%��Ԫ
    sctr = element(iel,:);

    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));%k������
        ginp1 = nonzeros([sctr,vari_ele(k,2:end)]);
        ginp = ginp1';
    else
        ginp = sctr;
    end
     % nodal coordinates
    coord = node(ginp,:);
   
    nodes=node(sctr,:);
    % total number of nodes in the current element
    nn = length(ginp) ;
    % global index
    gin_e = reshape([dofs_per_node*ginp-1;dofs_per_node*ginp],1,[]);%2*n-1,2*n,�ڵ����ɶȱ��룻�����Ǹı��˾��������˳�򣬰ѽڵ�����ɶȱ��붼�ŵ���һ����
    kele = zeros(size(gin_e,2),size(gin_e,2));
    ru = zeros(size(gin_e,2),1);
    % current element phase field values
    phi_ele = phiG(ginp);%ÿ����Ԫ�Ͻڵ���ೡֵ
%     phi_ele = phi_ele';
    % get the history variable...
    hp_ele = hplus(iel,i);
    hn_ele = hminus(iel,i);
    uele = udisp(gin_e,1);
    %compute kele and mele
  [W,Q] = gauss_rule(iel,normal_order,2);
 
    %loop on gauss point   

 if(ismember(iel,vari_ele(:,1))) 
    for kk = 1 : size(W,1)
       B = [];
       pt = Q(kk,:);
       % quadrature point   
        for i=1:size(vari_ele,1)
           if(iel==vari_ele(i,1))
              itmp=i;
            break
           end
        end  
   %����������ֲ�����ת��
        local_shape=[]; nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       %��������;ֲ������ת��
         [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
         nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
         local_shape=[local_shape; exisp,etasp];  
       end
   end 
      [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
      J0 = [nodes; nodes0]'*dNdxi;  % element Jacobian matrix 
%       invJ0 = inv(J0);
      dNdx = dNdxi/J0;
      % the phase field variable
      phi = N'*phi_ele;%����Ԫ��ֵ֪���ĸ��ڵ��ֵ�������һ����ೡ
%       phi = phi_ele';
      % strain-displacement matrix
      B = zeros(3,dofs_per_node*nn) ;%4���ڵ����3��8��
      B(1,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
      B(2,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
      B(3,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
      B(3,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;
      
      % mass factor  
      shpN = zeros(2,dofs_per_node*nn) ;
      shpN(1,1:dofs_per_node:dofs_per_node*nn) = N' ;
      shpN(2,2:dofs_per_node:dofs_per_node*nn) = N' ;
      
      if hp_ele < hn_ele
          phi = 0;
      end     
    % elemental displacement vector
    eps_e = B*uele;
    str_e = C*eps_e;
      %%%%%%%%%%%%%%%%%%%%%%%%%%% �µ��˻����������Ƽ��κ���%%%%%%%%%%%%%%%%%%%%%%
    lch = (E*Gc)/ft^2; %�������Ȳ���
    %����˻���������ϵ��a1,a2,a3
    a1 = 4*lch/(pi*lo);
    a2 = 1.3868;
    a3 = 0.6567;
    %���˻�����
    g = (1-phi)^2;%�˻������ķ���
  
    W22 = g + a1*phi +a1*a2*phi^2 +a1*a2*a3*phi^3; %�˻������ķ�ĸ
    omega = g/W22; %�˻�����
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %compute the stiffness matrix
     kele = kele + ...
         theck*B'*C*omega*B*W(kk)*det(J0) ;
     ru = ru + theck*B'*str_e*omega*W(kk)*det(J0);
%      kele = kele + ...
%          B'*( (1-phi)^2 + 1e-6  )*C*B*W(kk)*det(J0) ;
     % mass matrix
     clear nodes0;
    end
     Data(iel).kele = kele;
     Data(iel).eval = eig(kele); 
     Data(iel).ru = ru;
     %%%%%%%%%%%%%%%�Ȳ��Ľڵ㵥Ԫ%%%%%%%%%%%%%%%%%%%%
else
      cntqq = 0;
      [wq,qq]=quadrature(numgp,'GAUSS',2);
      for iigp = 1:size(W,1)
          cntqq = cntqq + 1;
          ptq = qq(iigp,:);
          [ng,dndxig] = lagrange_basis(elemType,ptq);  % element shape functions
          jacq = dndxig'*coord ;
          W1(cntqq,1) = wq(iigp)*det(jacq);
          temp = ng'*coord;
          Q1(cntqq,1) = temp(1); Q1(cntqq,2)=temp(2);
      end
      for igp = 1:size(W1,1)
          pt1 = Q1(igp,:) ;
          J0 = node(sctr,:)'*dndxig;  % element Jacobian matrix
          [N,dNdx]=meanvalue_shapefunction(coord,pt1);
           % the phase field variable
           phi = N'*phi_ele;%����Ԫ��ֵ֪���ĸ��ڵ��ֵ�������һ����ೡ
       
           % strain-displacement matrix
           B = zeros(3,dofs_per_node*nn) ;%4���ڵ����3��8��
           B(1,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;%����1:2:8�Ǵ�һ��8��2������ȡһ�Σ���1357
           B(2,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
           B(3,1:dofs_per_node:dofs_per_node*nn) = dNdx(:,2)' ;
           B(3,2:dofs_per_node:dofs_per_node*nn) = dNdx(:,1)' ;
        
            % mass factor
            shpN = zeros(2,dofs_per_node*nn) ;
            shpN(1,1:dofs_per_node:dofs_per_node*nn) = N' ;
            shpN(2,2:dofs_per_node:dofs_per_node*nn) = N' ;
            
            if hp_ele < hn_ele
                phi = 0;
            end
              % elemental displacement vector
          eps_e = B*uele;
          str_e = C*eps_e;
        %%%%%%%%%%%%%%%%%%%%%%%%%%% �µ��˻����������Ƽ��κ���%%%%%%%%%%%%%%%%%%%%%%
           lch = (E*Gc)/ft^2; %�������Ȳ���
           %����˻���������ϵ��a1,a2,a3
           a1 = 4*lch/(pi*lo);
           a2 = 1.3868;
           a3 = 0.6567;
           %���˻�����
           g = (1-phi)^2;%�˻������ķ���
           W = g + a1*phi +a1*a2*phi^2 +a1*a2*a3*phi^3; %�˻������ķ�ĸ
           omega = g/W; %�˻�����
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % compute the stiffness matrix
           kele = kele + ...
                  theck*B'*C*omega*B*W1(igp) ;
           ru = ru + theck*B'*str_e*omega*W1(igp);
%            kele = kele + ...
%           B'*( (1-phi)^2 + 1e-6  )*C*B*W1(igp);
   
      end    
           Data(iel).kele = kele;
           Data(iel).eval = eig(kele); 
           Data(iel).ru = ru;
   end
 end
  
 NCOEFF_K = 0;
 NCOEFF_R = 0;
for iel=1:length(element)
    sctr = element(iel,:);
    if (ismember(iel,vari_ele(:,1)))
        [~,k]=ismember(iel,vari_ele(:,1));
        ginp1 = nonzeros([sctr,vari_ele(k,2:end)]);
        ginp = ginp1';
        
    else
        ginp = sctr;
    end
    
    DOF = reshape([dofs_per_node*ginp-1;dofs_per_node*ginp],1,[]);
    %for stiffness
    iStart = NCOEFF_K + 1 ;
    NCOEFF_K = NCOEFF_K + length(DOF)^2 ;
    iEnd = NCOEFF_K ;
    
    %for resdiual
    jStart = NCOEFF_R + 1 ;
    NCOEFF_R = NCOEFF_R + length(DOF) ;
    jEnd = NCOEFF_R ;
    
    
    [X,Y] = meshgrid(DOF,DOF);
    
    % stiffness matrix
    kk = Data(iel).kele;
    
    % mass matrix
    rr = Data(iel).ru;
    rowIdx(iStart:iEnd) = reshape(Y,1,[]);
    colIdx(iStart:iEnd) = reshape(X,1,[]);
    coeffK(iStart:iEnd) = reshape(kk,1,[]);
    
    colJdx(jStart:jEnd) = Y(:,1)';
    coeffR(jStart:jEnd) = reshape(rr,1,[]);


%     rowIdx(iStart:iEnd) = reshape(Y,1,[]);
%     colIdx(iStart:iEnd) = reshape(X,1,[]);
%     
%     coeffK(iStart:iEnd)=reshape(kk,1,[]);
%     coeffM(iStart:iEnd)=reshape(rr,1,[]);
end

kuu = sparse(rowIdx,colIdx,coeffK,sdofu,sdofu,NCOEFF_K);
ruu = sparse(colJdx,1,coeffR,sdofu,1,NCOEFF_R);

end
  
    
    
    
        
        