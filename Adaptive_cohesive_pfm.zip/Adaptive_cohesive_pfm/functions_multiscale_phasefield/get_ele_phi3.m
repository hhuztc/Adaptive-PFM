function [marked_ele3,ele_phi] = get_ele_phi3(phiG,phasefieldseted)
global node element vari_ele 
global MatData
global ndof_u ngp
global ldType
global elemType

% material matrix
C = MatData.matmtx;
dens = MatData.dens;
lam = MatData.lambda ;
mu = MatData.mu ;
stressState = MatData.stressState ;
E = MatData.E ;
nu = MatData.nu ;
phi = MatData.phi ;
c = MatData.c ;

% loading type
ld_type = ldType ;

% number of dofs per node
dofs_per_node = ndof_u ;

% number of gauss points
numgp = ngp;

numnode = length(node);
numelem = length(element);

sdofu = numnode*dofs_per_node;
fu = sparse(sdofu,1);

normal_order = 2;
% initialize the variable to store the elemental mass and stiffness
% matrices...
ele_phi = [];

% loop in each element 
for iel = 1:numelem%��Ԫ
    sctr= element(iel,:);
    % get current element connectivity
    if(ismember(iel,vari_ele(:,1)))
        [~,k] = ismember(iel,vari_ele(:,1));
        ginp1 = nonzeros([sctr,vari_ele(k,2:end)]);
        ginp = ginp1';
    else
       ginp = element(iel,:);
    end
     % nodal coordinates
    coord = node(ginp,:);
   
    nodes=node(sctr,:);
    % total number of nodes in the current element
    nn = length(ginp) ;
    % global index
    gin_e = reshape([dofs_per_node*ginp-1;dofs_per_node*ginp],1,[]);%2*n-1,2*n,�ڵ����ɶȱ��룻�����Ǹı��˾��������˳�򣬰ѽڵ�����ɶȱ��붼�ŵ���һ����

    % current element phase field values
    phi_ele = phiG(ginp);%ÿ����Ԫ�Ͻڵ���ೡֵ
    
    % get the history variable...
 
    
    %compute kele and mele
    [W,Q] = gauss_rule(iel,normal_order,2);
 if(ismember(iel,vari_ele(:,1))) 
    for kk = 1 : size(W,1)
        pt = Q(kk,:);
       % quadrature point   
        for i=1:size(vari_ele,1)
            if(iel==vari_ele(i,1))
               itmp=i;
            break
            end
        end  
   %����������ֲ�����ת��
        local_shape=[]; nodes0=[]; 
   for i=1:size(vari_ele(itmp,:),2)-1 
       if(vari_ele(itmp,i+1)>0)       %��������;ֲ������ת��
         [exisp,etasp]=G_L_coor(node(vari_ele(itmp,i+1),1),node(vari_ele(itmp,i+1),2),nodes); 
         nodes0=[nodes0; node(vari_ele(itmp,i+1),:)];
         local_shape=[local_shape; exisp,etasp];  
       end
   end 
      [N,dNdxi] = shape_function_vari_ele(local_shape,pt) ;
       phi = N'*phi_ele;
       
    end
 else
     cntqq = 0;
      [wq,qq]=quadrature(numgp,'GAUSS',2);
      for iigp = 1:size(W,1)
          cntqq = cntqq + 1;
          ptq = qq(iigp,:);
          [ng,dndxig] = lagrange_basis(elemType,ptq);  % element shape functions
          jacq = dndxig'*coord ;
          W1(cntqq,1) = wq(iigp)*det(jacq);
          temp = ng'*coord;
          Q1(cntqq,1) = temp(1); Q1(cntqq,2)=temp(2);
      end
      for igp = 1:size(W1,1)
          pt1 = Q1(igp,:) ;
          J0 = node(sctr,:)'*dndxig;  % element Jacobian matrix
          [N,dNdx]=meanvalue_shapefunction(coord,pt1) ;
           % the phase field variable
           phi = N'*phi_ele;
         
      end
    end
    ele_phi(iel,1) = phi;
end
%get marked element
marked_ele3 = [];
for iel = 1:numelem
    if ele_phi(iel,1)>= phasefieldseted
        marked_ele3 = [marked_ele3,iel];
    end
end
%[marked_ele,ele_phi]=get_ele_phi(phiG,i,hplus,hminus,phasefieldseted)
end